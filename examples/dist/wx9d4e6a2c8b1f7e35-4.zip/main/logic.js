modDefine("app",function(e,p,o){App({})});
modDefine("pages/index/index",function(e,n,i){globalThis.__extraInfo={path:"pages/index/index",usingComponents:{}},Page({})});
