modDefine("game",function(e,n,o){globalThis.__extraInfo={path:"game",usingComponents:{}},e("/js/bundle")});
modDefine("/js/bundle",function(W0,X0,j0){var Cn=[{r:.7,spin:.9,w:.4},{r:1.1,spin:.7,w:.3},{r:1.6,spin:.5,w:.2},{r:2.1,spin:.35,w:.1}],Ah=.65,Rh=.6,Ch=50,Lh=600,Ph=.2;function Ih(e){let t=e>>>0;return function(){t|=0,t=t+1831565813|0;let r=Math.imul(t^t>>>15,1|t);return r=r+Math.imul(r^r>>>7,61|r)^r,((r^r>>>14)>>>0)/4294967296}}var Er=(e,t,r)=>e+(t-e)*r,Ta=e=>e<0?0:e>1?1:e,Ln=(e,t,r)=>e<t?t:e>r?r:e;function Dh(e={}){let t=e.halfRange!=null?e.halfRange:4;if(!isFinite(t)||t<1)throw new TypeError("halfRange must be a number >= 1");let r=e.startDistance!=null?Math.max(0,e.startDistance):0;if(!isFinite(r))throw new TypeError("startDistance must be a finite number");let i=typeof e.rng=="function"?e.rng:e.seed!=null?Ih(e.seed):Math.random,a=e.deadLockMs==null?Lh:e.deadLockMs,n=t-.5,s=t+.5,o="ready",l=r,u=0,h=0,c=null,d=0,m=0,_=0,g=Er(18,42,Ta(l/3e3)),f=[],p=[],x=-30,v=[{z:-30,x:0}];function E(Y){let W=v;for(let ae=0;ae<W.length-1;ae++){let Z=W[ae],te=W[ae+1];if(Y<=Z.z&&Y>=te.z)return Er(Z.x,te.x,(Z.z-Y)/(Z.z-te.z))}return W[W.length-1].x}function I(){let Y=i()*Cn.reduce((W,ae)=>W+ae.w,0);for(let W of Cn)if(Y-=W.w,Y<0)return W;return Cn[0]}function w(){let Y=x,W=Y-20,ae=E(Y),Z=Ln(ae+(i()*2-1)*2.2,-n,n);v.push({z:W,x:Z});let te=l+(Y-W)/2,de=Er(.1,.4,Ta(te/2600)),Pe=Math.max(1,Math.round(20*de*(.8+.4*i()))),ve=0;for(let $=0;$<Pe*6&&ve<Pe;$++){let oe=I(),ge=Er(W,Y,i()),Ee=Er(-s,s,i());Math.abs(Ee-E(ge))<1.2+oe.r||(f.push({x:Ee,z:ge,r:oe.r,spin:oe.spin*(i()<.5?-1:1)}),ve++)}if(i()<Ah)for(let $=0;$<6;$++){let oe=Er(W,Y,i()),ge=E(oe)+(i()*2-1)*Rh,Ee=!0;for(let he of f){if(he.z<W||he.z>Y)continue;let Ce=he.x-ge,Ke=he.z-oe;if(Ce*Ce+Ke*Ke<(he.r+.6)*(he.r+.6)){Ee=!1;break}}if(Ee){p.push({x:ge,z:oe});break}}x=W}function R(){for(;x>-140;)w()}R();function U(Y){o="dead",c=Y,d=0}function M(Y){if(!isFinite(Y))return;let W=Ln(Y,0,Ph);if(o==="dead"){d+=W*1e3;return}if(o!=="playing")return;g=Er(18,42,Ta(l/3e3)),l+=g*W;let ae=1-Math.exp(-12*W);_+=(m-_)*ae;let Z=g*W;for(let te of f)te.z+=Z;for(let te of p)te.z+=Z;x+=Z;for(let te of v)te.z+=Z;for(let te=f.length-1;te>=0;te--)f[te].z>14&&f.splice(te,1);for(let te=p.length-1;te>=0;te--)p[te].z>14&&p.splice(te,1);for(;v.length>2&&v[1].z>14;)v.shift();R();for(let te=0;te<f.length;te++){let de=f[te],Pe=de.x-_,ve=de.z,$=de.r+.5;if(Pe*Pe+ve*ve<$*$){U("asteroid");break}}if(o==="playing")for(let te=p.length-1;te>=0;te--){let de=p[te],Pe=de.x-_,ve=de.z;Pe*Pe+ve*ve<.8*.8&&(p.splice(te,1),u++)}h=Math.floor(l)+u*Ch}function T(Y){o!=="playing"||!isFinite(Y)||(m=Ln(m+Y/40,-t,t))}function P(){if(o==="ready"){o="playing";return}}function z(){f.length=0,p.length=0,v.length=0,v.push({z:-30,x:0}),x=-30,l=r,u=0,h=0,c=null,d=0,m=0,_=0,g=Er(18,42,Ta(l/3e3)),o="ready",R()}function q(){return{phase:o,score:h,deathReason:c,deadMs:d,deadLockMs:a,best:K.best,player:{x:_,z:0,targetX:m},asteroids:f.map(Y=>({x:Y.x,z:Y.z,r:Y.r,spin:Y.spin})),crystals:p.map(Y=>({x:Y.x,z:Y.z})),speed:g,view:{from:-140,to:14}}}let K={best:0,drag:T,tap:P,tick:M,reset:z,getState:q};return Object.defineProperties(K,{phase:{get:()=>o,enumerable:!0},score:{get:()=>h,enumerable:!0},deathReason:{get:()=>c,enumerable:!0},deadMs:{get:()=>d,enumerable:!0},deadLockMs:{get:()=>a,enumerable:!0},halfRange:{get:()=>t,enumerable:!0},distance:{get:()=>l,enumerable:!0}}),K}var Uh=0,Co=1,Nh=2,Lo=1,Oh=2,ur=3,hr=0,It=1,Ot=2,br=0,ai=1,cr=2,Po=3,Io=4,Fh=5,Vr=100,Bh=101,zh=102,Hh=103,kh=104,Vh=200,Gh=201,Wh=202,Xh=203,Pn=204,In=205,jh=206,Yh=207,qh=208,Kh=209,Zh=210,$h=211,Jh=212,Qh=213,ec=214,Dn=0,Un=1,Nn=2,ni=3,On=4,Fn=5,Bn=6,zn=7,Do=0,tc=1,rc=2,wr=0,ic=1,ac=2,nc=3,Uo=4,sc=5,oc=6,lc=7,No="attached",uc="detached",Oo=300,si=301,oi=302,Ea=303,Hn=304,ba=306,li=1e3,Ar=1001,wa=1002,wt=1003,Fo=1004,qi=1005,_t=1006,Aa=1007,jt=1008,dr=1009,Bo=1010,zo=1011,Ki=1012,kn=1013,Gr=1014,Yt=1015,Zi=1016,Vn=1017,Gn=1018,ui=1020,Ho=35902,ko=1021,Vo=1022,kt=1023,Go=1024,Wo=1025,hi=1026,ci=1027,Wn=1028,Xn=1029,Xo=1030,jn=1031,Yn=1033,Ra=33776,Ca=33777,La=33778,Pa=33779,qn=35840,Kn=35841,Zn=35842,$n=35843,Jn=36196,Qn=37492,es=37496,ts=37808,rs=37809,is=37810,as=37811,ns=37812,ss=37813,os=37814,ls=37815,us=37816,hs=37817,cs=37818,ds=37819,ps=37820,fs=37821,Ia=36492,ms=36494,gs=36495,jo=36283,_s=36284,vs=36285,xs=36286,$i=2300,Ji=2301,ys=2302,Yo=2400,qo=2401,Ko=2402,hc=2500,cc=0,Zo=1,Ms=2,dc=3200,pc=3201,$o=0,fc=1,Rr="",at="srgb",At="srgb-linear",Da="linear",it="srgb",di=7680,Jo=519,mc=512,gc=513,_c=514,Qo=515,vc=516,xc=517,yc=518,Mc=519,Ss=35044,el="300 es",pr=2e3,Ua=2001,pi=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let r=this._listeners;r[e]===void 0&&(r[e]=[]),r[e].indexOf(t)===-1&&r[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;let r=this._listeners;return r[e]!==void 0&&r[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;let r=this._listeners[e];if(r!==void 0){let i=r.indexOf(t);i!==-1&&r.splice(i,1)}}dispatchEvent(e){if(this._listeners===void 0)return;let t=this._listeners[e.type];if(t!==void 0){e.target=this;let r=t.slice(0);for(let i=0,a=r.length;i<a;i++)r[i].call(this,e);e.target=null}}},St=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],tl=1234567,Qi=Math.PI/180,fi=180/Math.PI;function qt(){let e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,r=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(St[e&255]+St[e>>8&255]+St[e>>16&255]+St[e>>24&255]+"-"+St[t&255]+St[t>>8&255]+"-"+St[t>>16&15|64]+St[t>>24&255]+"-"+St[r&63|128]+St[r>>8&255]+"-"+St[r>>16&255]+St[r>>24&255]+St[i&255]+St[i>>8&255]+St[i>>16&255]+St[i>>24&255]).toLowerCase()}function Tt(e,t,r){return Math.max(t,Math.min(r,e))}function Ts(e,t){return(e%t+t)%t}function Sc(e,t,r,i,a){return i+(e-t)*(a-i)/(r-t)}function Tc(e,t,r){return e!==t?(r-e)/(t-e):0}function ea(e,t,r){return(1-r)*e+r*t}function Ec(e,t,r,i){return ea(e,t,1-Math.exp(-r*i))}function bc(e,t=1){return t-Math.abs(Ts(e,t*2)-t)}function wc(e,t,r){return e<=t?0:e>=r?1:(e=(e-t)/(r-t),e*e*(3-2*e))}function Ac(e,t,r){return e<=t?0:e>=r?1:(e=(e-t)/(r-t),e*e*e*(e*(e*6-15)+10))}function Rc(e,t){return e+Math.floor(Math.random()*(t-e+1))}function Cc(e,t){return e+Math.random()*(t-e)}function Lc(e){return e*(.5-Math.random())}function Pc(e){e!==void 0&&(tl=e);let t=tl+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Ic(e){return e*Qi}function Dc(e){return e*fi}function Uc(e){return(e&e-1)===0&&e!==0}function Nc(e){return Math.pow(2,Math.ceil(Math.log(e)/Math.LN2))}function Oc(e){return Math.pow(2,Math.floor(Math.log(e)/Math.LN2))}function Fc(e,t,r,i,a){let n=Math.cos,s=Math.sin,o=n(r/2),l=s(r/2),u=n((t+i)/2),h=s((t+i)/2),c=n((t-i)/2),d=s((t-i)/2),m=n((i-t)/2),_=s((i-t)/2);switch(a){case"XYX":e.set(o*h,l*c,l*d,o*u);break;case"YZY":e.set(l*d,o*h,l*c,o*u);break;case"ZXZ":e.set(l*c,l*d,o*h,o*u);break;case"XZX":e.set(o*h,l*_,l*m,o*u);break;case"YXY":e.set(l*m,o*h,l*_,o*u);break;case"ZYZ":e.set(l*_,l*m,o*h,o*u);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+a)}}function Kt(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return e/4294967295;case Uint16Array:return e/65535;case Uint8Array:return e/255;case Int32Array:return Math.max(e/2147483647,-1);case Int16Array:return Math.max(e/32767,-1);case Int8Array:return Math.max(e/127,-1);default:throw new Error("Invalid component type.")}}function et(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return Math.round(e*4294967295);case Uint16Array:return Math.round(e*65535);case Uint8Array:return Math.round(e*255);case Int32Array:return Math.round(e*2147483647);case Int16Array:return Math.round(e*32767);case Int8Array:return Math.round(e*127);default:throw new Error("Invalid component type.")}}var Es={DEG2RAD:Qi,RAD2DEG:fi,generateUUID:qt,clamp:Tt,euclideanModulo:Ts,mapLinear:Sc,inverseLerp:Tc,lerp:ea,damp:Ec,pingpong:bc,smoothstep:wc,smootherstep:Ac,randInt:Rc,randFloat:Cc,randFloatSpread:Lc,seededRandom:Pc,degToRad:Ic,radToDeg:Dc,isPowerOfTwo:Uc,ceilPowerOfTwo:Nc,floorPowerOfTwo:Oc,setQuaternionFromProperEuler:Fc,normalize:et,denormalize:Kt},Fe=class uh{constructor(t=0,r=0){uh.prototype.isVector2=!0,this.x=t,this.y=r}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,r){return this.x=t,this.y=r,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,r){switch(t){case 0:this.x=r;break;case 1:this.y=r;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,r){return this.x=t.x+r.x,this.y=t.y+r.y,this}addScaledVector(t,r){return this.x+=t.x*r,this.y+=t.y*r,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,r){return this.x=t.x-r.x,this.y=t.y-r.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let r=this.x,i=this.y,a=t.elements;return this.x=a[0]*r+a[3]*i+a[6],this.y=a[1]*r+a[4]*i+a[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,r){return this.x=Math.max(t.x,Math.min(r.x,this.x)),this.y=Math.max(t.y,Math.min(r.y,this.y)),this}clampScalar(t,r){return this.x=Math.max(t,Math.min(r,this.x)),this.y=Math.max(t,Math.min(r,this.y)),this}clampLength(t,r){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(r,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let r=Math.sqrt(this.lengthSq()*t.lengthSq());if(r===0)return Math.PI/2;let i=this.dot(t)/r;return Math.acos(Tt(i,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let r=this.x-t.x,i=this.y-t.y;return r*r+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,r){return this.x+=(t.x-this.x)*r,this.y+=(t.y-this.y)*r,this}lerpVectors(t,r,i){return this.x=t.x+(r.x-t.x)*i,this.y=t.y+(r.y-t.y)*i,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,r=0){return this.x=t[r],this.y=t[r+1],this}toArray(t=[],r=0){return t[r]=this.x,t[r+1]=this.y,t}fromBufferAttribute(t,r){return this.x=t.getX(r),this.y=t.getY(r),this}rotateAround(t,r){let i=Math.cos(r),a=Math.sin(r),n=this.x-t.x,s=this.y-t.y;return this.x=n*i-s*a+t.x,this.y=n*a+s*i+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},Ve=class hh{constructor(t,r,i,a,n,s,o,l,u){hh.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,r,i,a,n,s,o,l,u)}set(t,r,i,a,n,s,o,l,u){let h=this.elements;return h[0]=t,h[1]=a,h[2]=o,h[3]=r,h[4]=n,h[5]=l,h[6]=i,h[7]=s,h[8]=u,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let r=this.elements,i=t.elements;return r[0]=i[0],r[1]=i[1],r[2]=i[2],r[3]=i[3],r[4]=i[4],r[5]=i[5],r[6]=i[6],r[7]=i[7],r[8]=i[8],this}extractBasis(t,r,i){return t.setFromMatrix3Column(this,0),r.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let r=t.elements;return this.set(r[0],r[4],r[8],r[1],r[5],r[9],r[2],r[6],r[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,r){let i=t.elements,a=r.elements,n=this.elements,s=i[0],o=i[3],l=i[6],u=i[1],h=i[4],c=i[7],d=i[2],m=i[5],_=i[8],g=a[0],f=a[3],p=a[6],x=a[1],v=a[4],E=a[7],I=a[2],w=a[5],R=a[8];return n[0]=s*g+o*x+l*I,n[3]=s*f+o*v+l*w,n[6]=s*p+o*E+l*R,n[1]=u*g+h*x+c*I,n[4]=u*f+h*v+c*w,n[7]=u*p+h*E+c*R,n[2]=d*g+m*x+_*I,n[5]=d*f+m*v+_*w,n[8]=d*p+m*E+_*R,this}multiplyScalar(t){let r=this.elements;return r[0]*=t,r[3]*=t,r[6]*=t,r[1]*=t,r[4]*=t,r[7]*=t,r[2]*=t,r[5]*=t,r[8]*=t,this}determinant(){let t=this.elements,r=t[0],i=t[1],a=t[2],n=t[3],s=t[4],o=t[5],l=t[6],u=t[7],h=t[8];return r*s*h-r*o*u-i*n*h+i*o*l+a*n*u-a*s*l}invert(){let t=this.elements,r=t[0],i=t[1],a=t[2],n=t[3],s=t[4],o=t[5],l=t[6],u=t[7],h=t[8],c=h*s-o*u,d=o*l-h*n,m=u*n-s*l,_=r*c+i*d+a*m;if(_===0)return this.set(0,0,0,0,0,0,0,0,0);let g=1/_;return t[0]=c*g,t[1]=(a*u-h*i)*g,t[2]=(o*i-a*s)*g,t[3]=d*g,t[4]=(h*r-a*l)*g,t[5]=(a*n-o*r)*g,t[6]=m*g,t[7]=(i*l-u*r)*g,t[8]=(s*r-i*n)*g,this}transpose(){let t,r=this.elements;return t=r[1],r[1]=r[3],r[3]=t,t=r[2],r[2]=r[6],r[6]=t,t=r[5],r[5]=r[7],r[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let r=this.elements;return t[0]=r[0],t[1]=r[3],t[2]=r[6],t[3]=r[1],t[4]=r[4],t[5]=r[7],t[6]=r[2],t[7]=r[5],t[8]=r[8],this}setUvTransform(t,r,i,a,n,s,o){let l=Math.cos(n),u=Math.sin(n);return this.set(i*l,i*u,-i*(l*s+u*o)+s+t,-a*u,a*l,-a*(-u*s+l*o)+o+r,0,0,1),this}scale(t,r){return this.premultiply(bs.makeScale(t,r)),this}rotate(t){return this.premultiply(bs.makeRotation(-t)),this}translate(t,r){return this.premultiply(bs.makeTranslation(t,r)),this}makeTranslation(t,r){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,r,0,0,1),this}makeRotation(t){let r=Math.cos(t),i=Math.sin(t);return this.set(r,-i,0,i,r,0,0,0,1),this}makeScale(t,r){return this.set(t,0,0,0,r,0,0,0,1),this}equals(t){let r=this.elements,i=t.elements;for(let a=0;a<9;a++)if(r[a]!==i[a])return!1;return!0}fromArray(t,r=0){for(let i=0;i<9;i++)this.elements[i]=t[i+r];return this}toArray(t=[],r=0){let i=this.elements;return t[r]=i[0],t[r+1]=i[1],t[r+2]=i[2],t[r+3]=i[3],t[r+4]=i[4],t[r+5]=i[5],t[r+6]=i[6],t[r+7]=i[7],t[r+8]=i[8],t}clone(){return new this.constructor().fromArray(this.elements)}},bs=new Ve;function rl(e){for(let t=e.length-1;t>=0;--t)if(e[t]>=65535)return!0;return!1}function ta(e){return document.createElementNS("http://www.w3.org/1999/xhtml",e)}function Bc(){let e=ta("canvas");return e.style.display="block",e}var il={};function ra(e){e in il||(il[e]=!0,console.warn(e))}function zc(e,t,r){return new Promise(function(i,a){function n(){switch(e.clientWaitSync(t,e.SYNC_FLUSH_COMMANDS_BIT,0)){case e.WAIT_FAILED:a();break;case e.TIMEOUT_EXPIRED:setTimeout(n,r);break;default:i()}}setTimeout(n,r)})}function Hc(e){let t=e.elements;t[2]=.5*t[2]+.5*t[3],t[6]=.5*t[6]+.5*t[7],t[10]=.5*t[10]+.5*t[11],t[14]=.5*t[14]+.5*t[15]}function kc(e){let t=e.elements;t[11]===-1?(t[10]=-t[10]-1,t[14]=-t[14]):(t[10]=-t[10],t[14]=-t[14]+1)}var Ye={enabled:!0,workingColorSpace:At,spaces:{},convert:function(e,t,r){return this.enabled===!1||t===r||!t||!r||(this.spaces[t].transfer===it&&(e.r=fr(e.r),e.g=fr(e.g),e.b=fr(e.b)),this.spaces[t].primaries!==this.spaces[r].primaries&&(e.applyMatrix3(this.spaces[t].toXYZ),e.applyMatrix3(this.spaces[r].fromXYZ)),this.spaces[r].transfer===it&&(e.r=mi(e.r),e.g=mi(e.g),e.b=mi(e.b))),e},fromWorkingColorSpace:function(e,t){return this.convert(e,this.workingColorSpace,t)},toWorkingColorSpace:function(e,t){return this.convert(e,t,this.workingColorSpace)},getPrimaries:function(e){return this.spaces[e].primaries},getTransfer:function(e){return e===Rr?Da:this.spaces[e].transfer},getLuminanceCoefficients:function(e,t=this.workingColorSpace){return e.fromArray(this.spaces[t].luminanceCoefficients)},define:function(e){Object.assign(this.spaces,e)},_getMatrix:function(e,t,r){return e.copy(this.spaces[t].toXYZ).multiply(this.spaces[r].fromXYZ)},_getDrawingBufferColorSpace:function(e){return this.spaces[e].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(e=this.workingColorSpace){return this.spaces[e].workingColorSpaceConfig.unpackColorSpace}};function fr(e){return e<.04045?e*.0773993808:Math.pow(e*.9478672986+.0521327014,2.4)}function mi(e){return e<.0031308?e*12.92:1.055*Math.pow(e,.41666)-.055}var al=[.64,.33,.3,.6,.15,.06],nl=[.2126,.7152,.0722],sl=[.3127,.329],ol=new Ve().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),ll=new Ve().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);Ye.define({[At]:{primaries:al,whitePoint:sl,transfer:Da,toXYZ:ol,fromXYZ:ll,luminanceCoefficients:nl,workingColorSpaceConfig:{unpackColorSpace:at},outputColorSpaceConfig:{drawingBufferColorSpace:at}},[at]:{primaries:al,whitePoint:sl,transfer:it,toXYZ:ol,fromXYZ:ll,luminanceCoefficients:nl,outputColorSpaceConfig:{drawingBufferColorSpace:at}}});var gi,Vc=class{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{gi===void 0&&(gi=ta("canvas")),gi.width=e.width,gi.height=e.height;let r=gi.getContext("2d");e instanceof ImageData?r.putImageData(e,0,0):r.drawImage(e,0,0,e.width,e.height),t=gi}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){let t=ta("canvas");t.width=e.width,t.height=e.height;let r=t.getContext("2d");r.drawImage(e,0,0,e.width,e.height);let i=r.getImageData(0,0,e.width,e.height),a=i.data;for(let n=0;n<a.length;n++)a[n]=fr(a[n]/255)*255;return r.putImageData(i,0,0),t}else if(e.data){let t=e.data.slice(0);for(let r=0;r<t.length;r++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[r]=Math.floor(fr(t[r]/255)*255):t[r]=fr(t[r]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}},Gc=0,ul=class{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Gc++}),this.uuid=qt(),this.data=e,this.dataReady=!0,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let r={uuid:this.uuid,url:""},i=this.data;if(i!==null){let a;if(Array.isArray(i)){a=[];for(let n=0,s=i.length;n<s;n++)i[n].isDataTexture?a.push(ws(i[n].image)):a.push(ws(i[n]))}else a=ws(i);r.url=a}return t||(e.images[this.uuid]=r),r}};function ws(e){return typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap?Vc.getDataURL(e):e.data?{data:Array.from(e.data),width:e.width,height:e.height,type:e.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Wc=0,Et=class An extends pi{constructor(t=An.DEFAULT_IMAGE,r=An.DEFAULT_MAPPING,i=Ar,a=Ar,n=_t,s=jt,o=kt,l=dr,u=An.DEFAULT_ANISOTROPY,h=Rr){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Wc++}),this.uuid=qt(),this.name="",this.source=new ul(t),this.mipmaps=[],this.mapping=r,this.channel=0,this.wrapS=i,this.wrapT=a,this.magFilter=n,this.minFilter=s,this.anisotropy=u,this.format=o,this.internalFormat=null,this.type=l,this.offset=new Fe(0,0),this.repeat=new Fe(1,1),this.center=new Fe(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Ve,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let r=t===void 0||typeof t=="string";if(!r&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),r||(t.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Oo)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case li:t.x=t.x-Math.floor(t.x);break;case Ar:t.x=t.x<0?0:1;break;case wa:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case li:t.y=t.y-Math.floor(t.y);break;case Ar:t.y=t.y<0?0:1;break;case wa:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}};Et.DEFAULT_IMAGE=null,Et.DEFAULT_MAPPING=Oo,Et.DEFAULT_ANISOTROPY=1;var tt=class ch{constructor(t=0,r=0,i=0,a=1){ch.prototype.isVector4=!0,this.x=t,this.y=r,this.z=i,this.w=a}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,r,i,a){return this.x=t,this.y=r,this.z=i,this.w=a,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,r){switch(t){case 0:this.x=r;break;case 1:this.y=r;break;case 2:this.z=r;break;case 3:this.w=r;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,r){return this.x=t.x+r.x,this.y=t.y+r.y,this.z=t.z+r.z,this.w=t.w+r.w,this}addScaledVector(t,r){return this.x+=t.x*r,this.y+=t.y*r,this.z+=t.z*r,this.w+=t.w*r,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,r){return this.x=t.x-r.x,this.y=t.y-r.y,this.z=t.z-r.z,this.w=t.w-r.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let r=this.x,i=this.y,a=this.z,n=this.w,s=t.elements;return this.x=s[0]*r+s[4]*i+s[8]*a+s[12]*n,this.y=s[1]*r+s[5]*i+s[9]*a+s[13]*n,this.z=s[2]*r+s[6]*i+s[10]*a+s[14]*n,this.w=s[3]*r+s[7]*i+s[11]*a+s[15]*n,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let r=Math.sqrt(1-t.w*t.w);return r<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/r,this.y=t.y/r,this.z=t.z/r),this}setAxisAngleFromRotationMatrix(t){let r,i,a,n,s=t.elements,o=s[0],l=s[4],u=s[8],h=s[1],c=s[5],d=s[9],m=s[2],_=s[6],g=s[10];if(Math.abs(l-h)<.01&&Math.abs(u-m)<.01&&Math.abs(d-_)<.01){if(Math.abs(l+h)<.1&&Math.abs(u+m)<.1&&Math.abs(d+_)<.1&&Math.abs(o+c+g-3)<.1)return this.set(1,0,0,0),this;r=Math.PI;let p=(o+1)/2,x=(c+1)/2,v=(g+1)/2,E=(l+h)/4,I=(u+m)/4,w=(d+_)/4;return p>x&&p>v?p<.01?(i=0,a=.707106781,n=.707106781):(i=Math.sqrt(p),a=E/i,n=I/i):x>v?x<.01?(i=.707106781,a=0,n=.707106781):(a=Math.sqrt(x),i=E/a,n=w/a):v<.01?(i=.707106781,a=.707106781,n=0):(n=Math.sqrt(v),i=I/n,a=w/n),this.set(i,a,n,r),this}let f=Math.sqrt((_-d)*(_-d)+(u-m)*(u-m)+(h-l)*(h-l));return Math.abs(f)<.001&&(f=1),this.x=(_-d)/f,this.y=(u-m)/f,this.z=(h-l)/f,this.w=Math.acos((o+c+g-1)/2),this}setFromMatrixPosition(t){let r=t.elements;return this.x=r[12],this.y=r[13],this.z=r[14],this.w=r[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,r){return this.x=Math.max(t.x,Math.min(r.x,this.x)),this.y=Math.max(t.y,Math.min(r.y,this.y)),this.z=Math.max(t.z,Math.min(r.z,this.z)),this.w=Math.max(t.w,Math.min(r.w,this.w)),this}clampScalar(t,r){return this.x=Math.max(t,Math.min(r,this.x)),this.y=Math.max(t,Math.min(r,this.y)),this.z=Math.max(t,Math.min(r,this.z)),this.w=Math.max(t,Math.min(r,this.w)),this}clampLength(t,r){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(r,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,r){return this.x+=(t.x-this.x)*r,this.y+=(t.y-this.y)*r,this.z+=(t.z-this.z)*r,this.w+=(t.w-this.w)*r,this}lerpVectors(t,r,i){return this.x=t.x+(r.x-t.x)*i,this.y=t.y+(r.y-t.y)*i,this.z=t.z+(r.z-t.z)*i,this.w=t.w+(r.w-t.w)*i,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,r=0){return this.x=t[r],this.y=t[r+1],this.z=t[r+2],this.w=t[r+3],this}toArray(t=[],r=0){return t[r]=this.x,t[r+1]=this.y,t[r+2]=this.z,t[r+3]=this.w,t}fromBufferAttribute(t,r){return this.x=t.getX(r),this.y=t.getY(r),this.z=t.getZ(r),this.w=t.getW(r),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Xc=class extends pi{constructor(e=1,t=1,r={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new tt(0,0,e,t),this.scissorTest=!1,this.viewport=new tt(0,0,e,t);let i={width:e,height:t,depth:1};r=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:_t,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},r);let a=new Et(i,r.mapping,r.wrapS,r.wrapT,r.magFilter,r.minFilter,r.format,r.type,r.anisotropy,r.colorSpace);a.flipY=!1,a.generateMipmaps=r.generateMipmaps,a.internalFormat=r.internalFormat,this.textures=[];let n=r.count;for(let s=0;s<n;s++)this.textures[s]=a.clone(),this.textures[s].isRenderTargetTexture=!0;this.depthBuffer=r.depthBuffer,this.stencilBuffer=r.stencilBuffer,this.resolveDepthBuffer=r.resolveDepthBuffer,this.resolveStencilBuffer=r.resolveStencilBuffer,this.depthTexture=r.depthTexture,this.samples=r.samples}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}setSize(e,t,r=1){if(this.width!==e||this.height!==t||this.depth!==r){this.width=e,this.height=t,this.depth=r;for(let i=0,a=this.textures.length;i<a;i++)this.textures[i].image.width=e,this.textures[i].image.height=t,this.textures[i].image.depth=r;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let r=0,i=e.textures.length;r<i;r++)this.textures[r]=e.textures[r].clone(),this.textures[r].isRenderTargetTexture=!0;let t=Object.assign({},e.texture.image);return this.texture.source=new ul(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},Wr=class extends Xc{constructor(e=1,t=1,r={}){super(e,t,r),this.isWebGLRenderTarget=!0}},hl=class extends Et{constructor(e=null,t=1,r=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:r,depth:i},this.magFilter=wt,this.minFilter=wt,this.wrapR=Ar,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}},jc=class extends Et{constructor(e=null,t=1,r=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:r,depth:i},this.magFilter=wt,this.minFilter=wt,this.wrapR=Ar,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}},Cr=class{constructor(e=0,t=0,r=0,i=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=r,this._w=i}static slerpFlat(e,t,r,i,a,n,s){let o=r[i+0],l=r[i+1],u=r[i+2],h=r[i+3],c=a[n+0],d=a[n+1],m=a[n+2],_=a[n+3];if(s===0){e[t+0]=o,e[t+1]=l,e[t+2]=u,e[t+3]=h;return}if(s===1){e[t+0]=c,e[t+1]=d,e[t+2]=m,e[t+3]=_;return}if(h!==_||o!==c||l!==d||u!==m){let g=1-s,f=o*c+l*d+u*m+h*_,p=f>=0?1:-1,x=1-f*f;if(x>Number.EPSILON){let E=Math.sqrt(x),I=Math.atan2(E,f*p);g=Math.sin(g*I)/E,s=Math.sin(s*I)/E}let v=s*p;if(o=o*g+c*v,l=l*g+d*v,u=u*g+m*v,h=h*g+_*v,g===1-s){let E=1/Math.sqrt(o*o+l*l+u*u+h*h);o*=E,l*=E,u*=E,h*=E}}e[t]=o,e[t+1]=l,e[t+2]=u,e[t+3]=h}static multiplyQuaternionsFlat(e,t,r,i,a,n){let s=r[i],o=r[i+1],l=r[i+2],u=r[i+3],h=a[n],c=a[n+1],d=a[n+2],m=a[n+3];return e[t]=s*m+u*h+o*d-l*c,e[t+1]=o*m+u*c+l*h-s*d,e[t+2]=l*m+u*d+s*c-o*h,e[t+3]=u*m-s*h-o*c-l*d,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,r,i){return this._x=e,this._y=t,this._z=r,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let r=e._x,i=e._y,a=e._z,n=e._order,s=Math.cos,o=Math.sin,l=s(r/2),u=s(i/2),h=s(a/2),c=o(r/2),d=o(i/2),m=o(a/2);switch(n){case"XYZ":this._x=c*u*h+l*d*m,this._y=l*d*h-c*u*m,this._z=l*u*m+c*d*h,this._w=l*u*h-c*d*m;break;case"YXZ":this._x=c*u*h+l*d*m,this._y=l*d*h-c*u*m,this._z=l*u*m-c*d*h,this._w=l*u*h+c*d*m;break;case"ZXY":this._x=c*u*h-l*d*m,this._y=l*d*h+c*u*m,this._z=l*u*m+c*d*h,this._w=l*u*h-c*d*m;break;case"ZYX":this._x=c*u*h-l*d*m,this._y=l*d*h+c*u*m,this._z=l*u*m-c*d*h,this._w=l*u*h+c*d*m;break;case"YZX":this._x=c*u*h+l*d*m,this._y=l*d*h+c*u*m,this._z=l*u*m-c*d*h,this._w=l*u*h-c*d*m;break;case"XZY":this._x=c*u*h-l*d*m,this._y=l*d*h-c*u*m,this._z=l*u*m+c*d*h,this._w=l*u*h+c*d*m;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+n)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let r=t/2,i=Math.sin(r);return this._x=e.x*i,this._y=e.y*i,this._z=e.z*i,this._w=Math.cos(r),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,r=t[0],i=t[4],a=t[8],n=t[1],s=t[5],o=t[9],l=t[2],u=t[6],h=t[10],c=r+s+h;if(c>0){let d=.5/Math.sqrt(c+1);this._w=.25/d,this._x=(u-o)*d,this._y=(a-l)*d,this._z=(n-i)*d}else if(r>s&&r>h){let d=2*Math.sqrt(1+r-s-h);this._w=(u-o)/d,this._x=.25*d,this._y=(i+n)/d,this._z=(a+l)/d}else if(s>h){let d=2*Math.sqrt(1+s-r-h);this._w=(a-l)/d,this._x=(i+n)/d,this._y=.25*d,this._z=(o+u)/d}else{let d=2*Math.sqrt(1+h-r-s);this._w=(n-i)/d,this._x=(a+l)/d,this._y=(o+u)/d,this._z=.25*d}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let r=e.dot(t)+1;return r<Number.EPSILON?(r=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=r):(this._x=0,this._y=-e.z,this._z=e.y,this._w=r)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=r),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Tt(this.dot(e),-1,1)))}rotateTowards(e,t){let r=this.angleTo(e);if(r===0)return this;let i=Math.min(1,t/r);return this.slerp(e,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let r=e._x,i=e._y,a=e._z,n=e._w,s=t._x,o=t._y,l=t._z,u=t._w;return this._x=r*u+n*s+i*l-a*o,this._y=i*u+n*o+a*s-r*l,this._z=a*u+n*l+r*o-i*s,this._w=n*u-r*s-i*o-a*l,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);let r=this._x,i=this._y,a=this._z,n=this._w,s=n*e._w+r*e._x+i*e._y+a*e._z;if(s<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,s=-s):this.copy(e),s>=1)return this._w=n,this._x=r,this._y=i,this._z=a,this;let o=1-s*s;if(o<=Number.EPSILON){let d=1-t;return this._w=d*n+t*this._w,this._x=d*r+t*this._x,this._y=d*i+t*this._y,this._z=d*a+t*this._z,this.normalize(),this}let l=Math.sqrt(o),u=Math.atan2(l,s),h=Math.sin((1-t)*u)/l,c=Math.sin(t*u)/l;return this._w=n*h+this._w*c,this._x=r*h+this._x*c,this._y=i*h+this._y*c,this._z=a*h+this._z*c,this._onChangeCallback(),this}slerpQuaternions(e,t,r){return this.copy(e).slerp(t,r)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),r=Math.random(),i=Math.sqrt(1-r),a=Math.sqrt(r);return this.set(i*Math.sin(e),i*Math.cos(e),a*Math.sin(t),a*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},L=class dh{constructor(t=0,r=0,i=0){dh.prototype.isVector3=!0,this.x=t,this.y=r,this.z=i}set(t,r,i){return i===void 0&&(i=this.z),this.x=t,this.y=r,this.z=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,r){switch(t){case 0:this.x=r;break;case 1:this.y=r;break;case 2:this.z=r;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,r){return this.x=t.x+r.x,this.y=t.y+r.y,this.z=t.z+r.z,this}addScaledVector(t,r){return this.x+=t.x*r,this.y+=t.y*r,this.z+=t.z*r,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,r){return this.x=t.x-r.x,this.y=t.y-r.y,this.z=t.z-r.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,r){return this.x=t.x*r.x,this.y=t.y*r.y,this.z=t.z*r.z,this}applyEuler(t){return this.applyQuaternion(cl.setFromEuler(t))}applyAxisAngle(t,r){return this.applyQuaternion(cl.setFromAxisAngle(t,r))}applyMatrix3(t){let r=this.x,i=this.y,a=this.z,n=t.elements;return this.x=n[0]*r+n[3]*i+n[6]*a,this.y=n[1]*r+n[4]*i+n[7]*a,this.z=n[2]*r+n[5]*i+n[8]*a,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let r=this.x,i=this.y,a=this.z,n=t.elements,s=1/(n[3]*r+n[7]*i+n[11]*a+n[15]);return this.x=(n[0]*r+n[4]*i+n[8]*a+n[12])*s,this.y=(n[1]*r+n[5]*i+n[9]*a+n[13])*s,this.z=(n[2]*r+n[6]*i+n[10]*a+n[14])*s,this}applyQuaternion(t){let r=this.x,i=this.y,a=this.z,n=t.x,s=t.y,o=t.z,l=t.w,u=2*(s*a-o*i),h=2*(o*r-n*a),c=2*(n*i-s*r);return this.x=r+l*u+s*c-o*h,this.y=i+l*h+o*u-n*c,this.z=a+l*c+n*h-s*u,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let r=this.x,i=this.y,a=this.z,n=t.elements;return this.x=n[0]*r+n[4]*i+n[8]*a,this.y=n[1]*r+n[5]*i+n[9]*a,this.z=n[2]*r+n[6]*i+n[10]*a,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,r){return this.x=Math.max(t.x,Math.min(r.x,this.x)),this.y=Math.max(t.y,Math.min(r.y,this.y)),this.z=Math.max(t.z,Math.min(r.z,this.z)),this}clampScalar(t,r){return this.x=Math.max(t,Math.min(r,this.x)),this.y=Math.max(t,Math.min(r,this.y)),this.z=Math.max(t,Math.min(r,this.z)),this}clampLength(t,r){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(r,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,r){return this.x+=(t.x-this.x)*r,this.y+=(t.y-this.y)*r,this.z+=(t.z-this.z)*r,this}lerpVectors(t,r,i){return this.x=t.x+(r.x-t.x)*i,this.y=t.y+(r.y-t.y)*i,this.z=t.z+(r.z-t.z)*i,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,r){let i=t.x,a=t.y,n=t.z,s=r.x,o=r.y,l=r.z;return this.x=a*l-n*o,this.y=n*s-i*l,this.z=i*o-a*s,this}projectOnVector(t){let r=t.lengthSq();if(r===0)return this.set(0,0,0);let i=t.dot(this)/r;return this.copy(t).multiplyScalar(i)}projectOnPlane(t){return As.copy(this).projectOnVector(t),this.sub(As)}reflect(t){return this.sub(As.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let r=Math.sqrt(this.lengthSq()*t.lengthSq());if(r===0)return Math.PI/2;let i=this.dot(t)/r;return Math.acos(Tt(i,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let r=this.x-t.x,i=this.y-t.y,a=this.z-t.z;return r*r+i*i+a*a}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,r,i){let a=Math.sin(r)*t;return this.x=a*Math.sin(i),this.y=Math.cos(r)*t,this.z=a*Math.cos(i),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,r,i){return this.x=t*Math.sin(r),this.y=i,this.z=t*Math.cos(r),this}setFromMatrixPosition(t){let r=t.elements;return this.x=r[12],this.y=r[13],this.z=r[14],this}setFromMatrixScale(t){let r=this.setFromMatrixColumn(t,0).length(),i=this.setFromMatrixColumn(t,1).length(),a=this.setFromMatrixColumn(t,2).length();return this.x=r,this.y=i,this.z=a,this}setFromMatrixColumn(t,r){return this.fromArray(t.elements,r*4)}setFromMatrix3Column(t,r){return this.fromArray(t.elements,r*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,r=0){return this.x=t[r],this.y=t[r+1],this.z=t[r+2],this}toArray(t=[],r=0){return t[r]=this.x,t[r+1]=this.y,t[r+2]=this.z,t}fromBufferAttribute(t,r){return this.x=t.getX(r),this.y=t.getY(r),this.z=t.getZ(r),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=Math.random()*Math.PI*2,r=Math.random()*2-1,i=Math.sqrt(1-r*r);return this.x=i*Math.cos(t),this.y=r,this.z=i*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},As=new L,cl=new Cr,Zt=class{constructor(e=new L(1/0,1/0,1/0),t=new L(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,r=e.length;t<r;t+=3)this.expandByPoint($t.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,r=e.count;t<r;t++)this.expandByPoint($t.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,r=e.length;t<r;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let r=$t.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(r),this.max.copy(e).add(r),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let r=e.geometry;if(r!==void 0){let a=r.getAttribute("position");if(t===!0&&a!==void 0&&e.isInstancedMesh!==!0)for(let n=0,s=a.count;n<s;n++)e.isMesh===!0?e.getVertexPosition(n,$t):$t.fromBufferAttribute(a,n),$t.applyMatrix4(e.matrixWorld),this.expandByPoint($t);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Na.copy(e.boundingBox)):(r.boundingBox===null&&r.computeBoundingBox(),Na.copy(r.boundingBox)),Na.applyMatrix4(e.matrixWorld),this.union(Na)}let i=e.children;for(let a=0,n=i.length;a<n;a++)this.expandByObject(i[a],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,$t),$t.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,r;return e.normal.x>0?(t=e.normal.x*this.min.x,r=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,r=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,r+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,r+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,r+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,r+=e.normal.z*this.min.z),t<=-e.constant&&r>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(ia),Oa.subVectors(this.max,ia),_i.subVectors(e.a,ia),vi.subVectors(e.b,ia),xi.subVectors(e.c,ia),Lr.subVectors(vi,_i),Pr.subVectors(xi,vi),Xr.subVectors(_i,xi);let t=[0,-Lr.z,Lr.y,0,-Pr.z,Pr.y,0,-Xr.z,Xr.y,Lr.z,0,-Lr.x,Pr.z,0,-Pr.x,Xr.z,0,-Xr.x,-Lr.y,Lr.x,0,-Pr.y,Pr.x,0,-Xr.y,Xr.x,0];return!Rs(t,_i,vi,xi,Oa)||(t=[1,0,0,0,1,0,0,0,1],!Rs(t,_i,vi,xi,Oa))?!1:(Fa.crossVectors(Lr,Pr),t=[Fa.x,Fa.y,Fa.z],Rs(t,_i,vi,xi,Oa))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,$t).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize($t).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(mr[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),mr[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),mr[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),mr[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),mr[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),mr[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),mr[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),mr[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(mr),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}},mr=[new L,new L,new L,new L,new L,new L,new L,new L],$t=new L,Na=new Zt,_i=new L,vi=new L,xi=new L,Lr=new L,Pr=new L,Xr=new L,ia=new L,Oa=new L,Fa=new L,jr=new L;function Rs(e,t,r,i,a){for(let n=0,s=e.length-3;n<=s;n+=3){jr.fromArray(e,n);let o=a.x*Math.abs(jr.x)+a.y*Math.abs(jr.y)+a.z*Math.abs(jr.z),l=t.dot(jr),u=r.dot(jr),h=i.dot(jr);if(Math.max(-Math.max(l,u,h),Math.min(l,u,h))>o)return!1}return!0}var Yc=new Zt,aa=new L,Cs=new L,ir=class{constructor(e=new L,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let r=this.center;t!==void 0?r.copy(t):Yc.setFromPoints(e).getCenter(r);let i=0;for(let a=0,n=e.length;a<n;a++)i=Math.max(i,r.distanceToSquared(e[a]));return this.radius=Math.sqrt(i),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let r=this.center.distanceToSquared(e);return t.copy(e),r>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;aa.subVectors(e,this.center);let t=aa.lengthSq();if(t>this.radius*this.radius){let r=Math.sqrt(t),i=(r-this.radius)*.5;this.center.addScaledVector(aa,i/r),this.radius+=i}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Cs.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(aa.copy(e.center).add(Cs)),this.expandByPoint(aa.copy(e.center).sub(Cs))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}},gr=new L,Ls=new L,Ba=new L,Ir=new L,Ps=new L,za=new L,Is=new L,Ha=class{constructor(e=new L,t=new L(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,gr)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let r=t.dot(this.direction);return r<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,r)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=gr.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(gr.copy(this.origin).addScaledVector(this.direction,t),gr.distanceToSquared(e))}distanceSqToSegment(e,t,r,i){Ls.copy(e).add(t).multiplyScalar(.5),Ba.copy(t).sub(e).normalize(),Ir.copy(this.origin).sub(Ls);let a=e.distanceTo(t)*.5,n=-this.direction.dot(Ba),s=Ir.dot(this.direction),o=-Ir.dot(Ba),l=Ir.lengthSq(),u=Math.abs(1-n*n),h,c,d,m;if(u>0)if(h=n*o-s,c=n*s-o,m=a*u,h>=0)if(c>=-m)if(c<=m){let _=1/u;h*=_,c*=_,d=h*(h+n*c+2*s)+c*(n*h+c+2*o)+l}else c=a,h=Math.max(0,-(n*c+s)),d=-h*h+c*(c+2*o)+l;else c=-a,h=Math.max(0,-(n*c+s)),d=-h*h+c*(c+2*o)+l;else c<=-m?(h=Math.max(0,-(-n*a+s)),c=h>0?-a:Math.min(Math.max(-a,-o),a),d=-h*h+c*(c+2*o)+l):c<=m?(h=0,c=Math.min(Math.max(-a,-o),a),d=c*(c+2*o)+l):(h=Math.max(0,-(n*a+s)),c=h>0?a:Math.min(Math.max(-a,-o),a),d=-h*h+c*(c+2*o)+l);else c=n>0?-a:a,h=Math.max(0,-(n*c+s)),d=-h*h+c*(c+2*o)+l;return r&&r.copy(this.origin).addScaledVector(this.direction,h),i&&i.copy(Ls).addScaledVector(Ba,c),d}intersectSphere(e,t){gr.subVectors(e.center,this.origin);let r=gr.dot(this.direction),i=gr.dot(gr)-r*r,a=e.radius*e.radius;if(i>a)return null;let n=Math.sqrt(a-i),s=r-n,o=r+n;return o<0?null:s<0?this.at(o,t):this.at(s,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let r=-(this.origin.dot(e.normal)+e.constant)/t;return r>=0?r:null}intersectPlane(e,t){let r=this.distanceToPlane(e);return r===null?null:this.at(r,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let r,i,a,n,s,o,l=1/this.direction.x,u=1/this.direction.y,h=1/this.direction.z,c=this.origin;return l>=0?(r=(e.min.x-c.x)*l,i=(e.max.x-c.x)*l):(r=(e.max.x-c.x)*l,i=(e.min.x-c.x)*l),u>=0?(a=(e.min.y-c.y)*u,n=(e.max.y-c.y)*u):(a=(e.max.y-c.y)*u,n=(e.min.y-c.y)*u),r>n||a>i||((a>r||isNaN(r))&&(r=a),(n<i||isNaN(i))&&(i=n),h>=0?(s=(e.min.z-c.z)*h,o=(e.max.z-c.z)*h):(s=(e.max.z-c.z)*h,o=(e.min.z-c.z)*h),r>o||s>i)||((s>r||r!==r)&&(r=s),(o<i||i!==i)&&(i=o),i<0)?null:this.at(r>=0?r:i,t)}intersectsBox(e){return this.intersectBox(e,gr)!==null}intersectTriangle(e,t,r,i,a){Ps.subVectors(t,e),za.subVectors(r,e),Is.crossVectors(Ps,za);let n=this.direction.dot(Is),s;if(n>0){if(i)return null;s=1}else if(n<0)s=-1,n=-n;else return null;Ir.subVectors(this.origin,e);let o=s*this.direction.dot(za.crossVectors(Ir,za));if(o<0)return null;let l=s*this.direction.dot(Ps.cross(Ir));if(l<0||o+l>n)return null;let u=-s*Ir.dot(Is);return u<0?null:this.at(u/n,a)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Ge=class Ro{constructor(t,r,i,a,n,s,o,l,u,h,c,d,m,_,g,f){Ro.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,r,i,a,n,s,o,l,u,h,c,d,m,_,g,f)}set(t,r,i,a,n,s,o,l,u,h,c,d,m,_,g,f){let p=this.elements;return p[0]=t,p[4]=r,p[8]=i,p[12]=a,p[1]=n,p[5]=s,p[9]=o,p[13]=l,p[2]=u,p[6]=h,p[10]=c,p[14]=d,p[3]=m,p[7]=_,p[11]=g,p[15]=f,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Ro().fromArray(this.elements)}copy(t){let r=this.elements,i=t.elements;return r[0]=i[0],r[1]=i[1],r[2]=i[2],r[3]=i[3],r[4]=i[4],r[5]=i[5],r[6]=i[6],r[7]=i[7],r[8]=i[8],r[9]=i[9],r[10]=i[10],r[11]=i[11],r[12]=i[12],r[13]=i[13],r[14]=i[14],r[15]=i[15],this}copyPosition(t){let r=this.elements,i=t.elements;return r[12]=i[12],r[13]=i[13],r[14]=i[14],this}setFromMatrix3(t){let r=t.elements;return this.set(r[0],r[3],r[6],0,r[1],r[4],r[7],0,r[2],r[5],r[8],0,0,0,0,1),this}extractBasis(t,r,i){return t.setFromMatrixColumn(this,0),r.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(t,r,i){return this.set(t.x,r.x,i.x,0,t.y,r.y,i.y,0,t.z,r.z,i.z,0,0,0,0,1),this}extractRotation(t){let r=this.elements,i=t.elements,a=1/yi.setFromMatrixColumn(t,0).length(),n=1/yi.setFromMatrixColumn(t,1).length(),s=1/yi.setFromMatrixColumn(t,2).length();return r[0]=i[0]*a,r[1]=i[1]*a,r[2]=i[2]*a,r[3]=0,r[4]=i[4]*n,r[5]=i[5]*n,r[6]=i[6]*n,r[7]=0,r[8]=i[8]*s,r[9]=i[9]*s,r[10]=i[10]*s,r[11]=0,r[12]=0,r[13]=0,r[14]=0,r[15]=1,this}makeRotationFromEuler(t){let r=this.elements,i=t.x,a=t.y,n=t.z,s=Math.cos(i),o=Math.sin(i),l=Math.cos(a),u=Math.sin(a),h=Math.cos(n),c=Math.sin(n);if(t.order==="XYZ"){let d=s*h,m=s*c,_=o*h,g=o*c;r[0]=l*h,r[4]=-l*c,r[8]=u,r[1]=m+_*u,r[5]=d-g*u,r[9]=-o*l,r[2]=g-d*u,r[6]=_+m*u,r[10]=s*l}else if(t.order==="YXZ"){let d=l*h,m=l*c,_=u*h,g=u*c;r[0]=d+g*o,r[4]=_*o-m,r[8]=s*u,r[1]=s*c,r[5]=s*h,r[9]=-o,r[2]=m*o-_,r[6]=g+d*o,r[10]=s*l}else if(t.order==="ZXY"){let d=l*h,m=l*c,_=u*h,g=u*c;r[0]=d-g*o,r[4]=-s*c,r[8]=_+m*o,r[1]=m+_*o,r[5]=s*h,r[9]=g-d*o,r[2]=-s*u,r[6]=o,r[10]=s*l}else if(t.order==="ZYX"){let d=s*h,m=s*c,_=o*h,g=o*c;r[0]=l*h,r[4]=_*u-m,r[8]=d*u+g,r[1]=l*c,r[5]=g*u+d,r[9]=m*u-_,r[2]=-u,r[6]=o*l,r[10]=s*l}else if(t.order==="YZX"){let d=s*l,m=s*u,_=o*l,g=o*u;r[0]=l*h,r[4]=g-d*c,r[8]=_*c+m,r[1]=c,r[5]=s*h,r[9]=-o*h,r[2]=-u*h,r[6]=m*c+_,r[10]=d-g*c}else if(t.order==="XZY"){let d=s*l,m=s*u,_=o*l,g=o*u;r[0]=l*h,r[4]=-c,r[8]=u*h,r[1]=d*c+g,r[5]=s*h,r[9]=m*c-_,r[2]=_*c-m,r[6]=o*h,r[10]=g*c+d}return r[3]=0,r[7]=0,r[11]=0,r[12]=0,r[13]=0,r[14]=0,r[15]=1,this}makeRotationFromQuaternion(t){return this.compose(qc,t,Kc)}lookAt(t,r,i){let a=this.elements;return Ft.subVectors(t,r),Ft.lengthSq()===0&&(Ft.z=1),Ft.normalize(),Dr.crossVectors(i,Ft),Dr.lengthSq()===0&&(Math.abs(i.z)===1?Ft.x+=1e-4:Ft.z+=1e-4,Ft.normalize(),Dr.crossVectors(i,Ft)),Dr.normalize(),ka.crossVectors(Ft,Dr),a[0]=Dr.x,a[4]=ka.x,a[8]=Ft.x,a[1]=Dr.y,a[5]=ka.y,a[9]=Ft.y,a[2]=Dr.z,a[6]=ka.z,a[10]=Ft.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,r){let i=t.elements,a=r.elements,n=this.elements,s=i[0],o=i[4],l=i[8],u=i[12],h=i[1],c=i[5],d=i[9],m=i[13],_=i[2],g=i[6],f=i[10],p=i[14],x=i[3],v=i[7],E=i[11],I=i[15],w=a[0],R=a[4],U=a[8],M=a[12],T=a[1],P=a[5],z=a[9],q=a[13],K=a[2],Y=a[6],W=a[10],ae=a[14],Z=a[3],te=a[7],de=a[11],Pe=a[15];return n[0]=s*w+o*T+l*K+u*Z,n[4]=s*R+o*P+l*Y+u*te,n[8]=s*U+o*z+l*W+u*de,n[12]=s*M+o*q+l*ae+u*Pe,n[1]=h*w+c*T+d*K+m*Z,n[5]=h*R+c*P+d*Y+m*te,n[9]=h*U+c*z+d*W+m*de,n[13]=h*M+c*q+d*ae+m*Pe,n[2]=_*w+g*T+f*K+p*Z,n[6]=_*R+g*P+f*Y+p*te,n[10]=_*U+g*z+f*W+p*de,n[14]=_*M+g*q+f*ae+p*Pe,n[3]=x*w+v*T+E*K+I*Z,n[7]=x*R+v*P+E*Y+I*te,n[11]=x*U+v*z+E*W+I*de,n[15]=x*M+v*q+E*ae+I*Pe,this}multiplyScalar(t){let r=this.elements;return r[0]*=t,r[4]*=t,r[8]*=t,r[12]*=t,r[1]*=t,r[5]*=t,r[9]*=t,r[13]*=t,r[2]*=t,r[6]*=t,r[10]*=t,r[14]*=t,r[3]*=t,r[7]*=t,r[11]*=t,r[15]*=t,this}determinant(){let t=this.elements,r=t[0],i=t[4],a=t[8],n=t[12],s=t[1],o=t[5],l=t[9],u=t[13],h=t[2],c=t[6],d=t[10],m=t[14],_=t[3],g=t[7],f=t[11],p=t[15];return _*(+n*l*c-a*u*c-n*o*d+i*u*d+a*o*m-i*l*m)+g*(+r*l*m-r*u*d+n*s*d-a*s*m+a*u*h-n*l*h)+f*(+r*u*c-r*o*m-n*s*c+i*s*m+n*o*h-i*u*h)+p*(-a*o*h-r*l*c+r*o*d+a*s*c-i*s*d+i*l*h)}transpose(){let t=this.elements,r;return r=t[1],t[1]=t[4],t[4]=r,r=t[2],t[2]=t[8],t[8]=r,r=t[6],t[6]=t[9],t[9]=r,r=t[3],t[3]=t[12],t[12]=r,r=t[7],t[7]=t[13],t[13]=r,r=t[11],t[11]=t[14],t[14]=r,this}setPosition(t,r,i){let a=this.elements;return t.isVector3?(a[12]=t.x,a[13]=t.y,a[14]=t.z):(a[12]=t,a[13]=r,a[14]=i),this}invert(){let t=this.elements,r=t[0],i=t[1],a=t[2],n=t[3],s=t[4],o=t[5],l=t[6],u=t[7],h=t[8],c=t[9],d=t[10],m=t[11],_=t[12],g=t[13],f=t[14],p=t[15],x=c*f*u-g*d*u+g*l*m-o*f*m-c*l*p+o*d*p,v=_*d*u-h*f*u-_*l*m+s*f*m+h*l*p-s*d*p,E=h*g*u-_*c*u+_*o*m-s*g*m-h*o*p+s*c*p,I=_*c*l-h*g*l-_*o*d+s*g*d+h*o*f-s*c*f,w=r*x+i*v+a*E+n*I;if(w===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let R=1/w;return t[0]=x*R,t[1]=(g*d*n-c*f*n-g*a*m+i*f*m+c*a*p-i*d*p)*R,t[2]=(o*f*n-g*l*n+g*a*u-i*f*u-o*a*p+i*l*p)*R,t[3]=(c*l*n-o*d*n-c*a*u+i*d*u+o*a*m-i*l*m)*R,t[4]=v*R,t[5]=(h*f*n-_*d*n+_*a*m-r*f*m-h*a*p+r*d*p)*R,t[6]=(_*l*n-s*f*n-_*a*u+r*f*u+s*a*p-r*l*p)*R,t[7]=(s*d*n-h*l*n+h*a*u-r*d*u-s*a*m+r*l*m)*R,t[8]=E*R,t[9]=(_*c*n-h*g*n-_*i*m+r*g*m+h*i*p-r*c*p)*R,t[10]=(s*g*n-_*o*n+_*i*u-r*g*u-s*i*p+r*o*p)*R,t[11]=(h*o*n-s*c*n-h*i*u+r*c*u+s*i*m-r*o*m)*R,t[12]=I*R,t[13]=(h*g*a-_*c*a+_*i*d-r*g*d-h*i*f+r*c*f)*R,t[14]=(_*o*a-s*g*a-_*i*l+r*g*l+s*i*f-r*o*f)*R,t[15]=(s*c*a-h*o*a+h*i*l-r*c*l-s*i*d+r*o*d)*R,this}scale(t){let r=this.elements,i=t.x,a=t.y,n=t.z;return r[0]*=i,r[4]*=a,r[8]*=n,r[1]*=i,r[5]*=a,r[9]*=n,r[2]*=i,r[6]*=a,r[10]*=n,r[3]*=i,r[7]*=a,r[11]*=n,this}getMaxScaleOnAxis(){let t=this.elements,r=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],i=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],a=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(r,i,a))}makeTranslation(t,r,i){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,r,0,0,1,i,0,0,0,1),this}makeRotationX(t){let r=Math.cos(t),i=Math.sin(t);return this.set(1,0,0,0,0,r,-i,0,0,i,r,0,0,0,0,1),this}makeRotationY(t){let r=Math.cos(t),i=Math.sin(t);return this.set(r,0,i,0,0,1,0,0,-i,0,r,0,0,0,0,1),this}makeRotationZ(t){let r=Math.cos(t),i=Math.sin(t);return this.set(r,-i,0,0,i,r,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,r){let i=Math.cos(r),a=Math.sin(r),n=1-i,s=t.x,o=t.y,l=t.z,u=n*s,h=n*o;return this.set(u*s+i,u*o-a*l,u*l+a*o,0,u*o+a*l,h*o+i,h*l-a*s,0,u*l-a*o,h*l+a*s,n*l*l+i,0,0,0,0,1),this}makeScale(t,r,i){return this.set(t,0,0,0,0,r,0,0,0,0,i,0,0,0,0,1),this}makeShear(t,r,i,a,n,s){return this.set(1,i,n,0,t,1,s,0,r,a,1,0,0,0,0,1),this}compose(t,r,i){let a=this.elements,n=r._x,s=r._y,o=r._z,l=r._w,u=n+n,h=s+s,c=o+o,d=n*u,m=n*h,_=n*c,g=s*h,f=s*c,p=o*c,x=l*u,v=l*h,E=l*c,I=i.x,w=i.y,R=i.z;return a[0]=(1-(g+p))*I,a[1]=(m+E)*I,a[2]=(_-v)*I,a[3]=0,a[4]=(m-E)*w,a[5]=(1-(d+p))*w,a[6]=(f+x)*w,a[7]=0,a[8]=(_+v)*R,a[9]=(f-x)*R,a[10]=(1-(d+g))*R,a[11]=0,a[12]=t.x,a[13]=t.y,a[14]=t.z,a[15]=1,this}decompose(t,r,i){let a=this.elements,n=yi.set(a[0],a[1],a[2]).length(),s=yi.set(a[4],a[5],a[6]).length(),o=yi.set(a[8],a[9],a[10]).length();this.determinant()<0&&(n=-n),t.x=a[12],t.y=a[13],t.z=a[14],Jt.copy(this);let l=1/n,u=1/s,h=1/o;return Jt.elements[0]*=l,Jt.elements[1]*=l,Jt.elements[2]*=l,Jt.elements[4]*=u,Jt.elements[5]*=u,Jt.elements[6]*=u,Jt.elements[8]*=h,Jt.elements[9]*=h,Jt.elements[10]*=h,r.setFromRotationMatrix(Jt),i.x=n,i.y=s,i.z=o,this}makePerspective(t,r,i,a,n,s,o=pr){let l=this.elements,u=2*n/(r-t),h=2*n/(i-a),c=(r+t)/(r-t),d=(i+a)/(i-a),m,_;if(o===pr)m=-(s+n)/(s-n),_=-2*s*n/(s-n);else if(o===Ua)m=-s/(s-n),_=-s*n/(s-n);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return l[0]=u,l[4]=0,l[8]=c,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=m,l[14]=_,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,r,i,a,n,s,o=pr){let l=this.elements,u=1/(r-t),h=1/(i-a),c=1/(s-n),d=(r+t)*u,m=(i+a)*h,_,g;if(o===pr)_=(s+n)*c,g=-2*c;else if(o===Ua)_=n*c,g=-1*c;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return l[0]=2*u,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-m,l[2]=0,l[6]=0,l[10]=g,l[14]=-_,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){let r=this.elements,i=t.elements;for(let a=0;a<16;a++)if(r[a]!==i[a])return!1;return!0}fromArray(t,r=0){for(let i=0;i<16;i++)this.elements[i]=t[i+r];return this}toArray(t=[],r=0){let i=this.elements;return t[r]=i[0],t[r+1]=i[1],t[r+2]=i[2],t[r+3]=i[3],t[r+4]=i[4],t[r+5]=i[5],t[r+6]=i[6],t[r+7]=i[7],t[r+8]=i[8],t[r+9]=i[9],t[r+10]=i[10],t[r+11]=i[11],t[r+12]=i[12],t[r+13]=i[13],t[r+14]=i[14],t[r+15]=i[15],t}},yi=new L,Jt=new Ge,qc=new L(0,0,0),Kc=new L(1,1,1),Dr=new L,ka=new L,Ft=new L,dl=new Ge,pl=new Cr,Ur=class ph{constructor(t=0,r=0,i=0,a=ph.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=r,this._z=i,this._order=a}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,r,i,a=this._order){return this._x=t,this._y=r,this._z=i,this._order=a,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,r=this._order,i=!0){let a=t.elements,n=a[0],s=a[4],o=a[8],l=a[1],u=a[5],h=a[9],c=a[2],d=a[6],m=a[10];switch(r){case"XYZ":this._y=Math.asin(Tt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,m),this._z=Math.atan2(-s,n)):(this._x=Math.atan2(d,u),this._z=0);break;case"YXZ":this._x=Math.asin(-Tt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,m),this._z=Math.atan2(l,u)):(this._y=Math.atan2(-c,n),this._z=0);break;case"ZXY":this._x=Math.asin(Tt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-c,m),this._z=Math.atan2(-s,u)):(this._y=0,this._z=Math.atan2(l,n));break;case"ZYX":this._y=Math.asin(-Tt(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(d,m),this._z=Math.atan2(l,n)):(this._x=0,this._z=Math.atan2(-s,u));break;case"YZX":this._z=Math.asin(Tt(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,u),this._y=Math.atan2(-c,n)):(this._x=0,this._y=Math.atan2(o,m));break;case"XZY":this._z=Math.asin(-Tt(s,-1,1)),Math.abs(s)<.9999999?(this._x=Math.atan2(d,u),this._y=Math.atan2(o,n)):(this._x=Math.atan2(-h,m),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+r)}return this._order=r,i===!0&&this._onChangeCallback(),this}setFromQuaternion(t,r,i){return dl.makeRotationFromQuaternion(t),this.setFromRotationMatrix(dl,r,i)}setFromVector3(t,r=this._order){return this.set(t.x,t.y,t.z,r)}reorder(t){return pl.setFromEuler(this),this.setFromQuaternion(pl,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],r=0){return t[r]=this._x,t[r+1]=this._y,t[r+2]=this._z,t[r+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};Ur.DEFAULT_ORDER="XYZ";var fl=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}},Zc=0,ml=new L,Mi=new Cr,_r=new Ge,Va=new L,na=new L,$c=new L,Jc=new Cr,gl=new L(1,0,0),_l=new L(0,1,0),vl=new L(0,0,1),xl={type:"added"},Qc={type:"removed"},Si={type:"childadded",child:null},Ds={type:"childremoved",child:null},ct=class Rn extends pi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Zc++}),this.uuid=qt(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Rn.DEFAULT_UP.clone();let t=new L,r=new Ur,i=new Cr,a=new L(1,1,1);function n(){i.setFromEuler(r,!1)}function s(){r.setFromQuaternion(i,void 0,!1)}r._onChange(n),i._onChange(s),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:r},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:a},modelViewMatrix:{value:new Ge},normalMatrix:{value:new Ve}}),this.matrix=new Ge,this.matrixWorld=new Ge,this.matrixAutoUpdate=Rn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Rn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new fl,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,r){this.quaternion.setFromAxisAngle(t,r)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,r){return Mi.setFromAxisAngle(t,r),this.quaternion.multiply(Mi),this}rotateOnWorldAxis(t,r){return Mi.setFromAxisAngle(t,r),this.quaternion.premultiply(Mi),this}rotateX(t){return this.rotateOnAxis(gl,t)}rotateY(t){return this.rotateOnAxis(_l,t)}rotateZ(t){return this.rotateOnAxis(vl,t)}translateOnAxis(t,r){return ml.copy(t).applyQuaternion(this.quaternion),this.position.add(ml.multiplyScalar(r)),this}translateX(t){return this.translateOnAxis(gl,t)}translateY(t){return this.translateOnAxis(_l,t)}translateZ(t){return this.translateOnAxis(vl,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(_r.copy(this.matrixWorld).invert())}lookAt(t,r,i){t.isVector3?Va.copy(t):Va.set(t,r,i);let a=this.parent;this.updateWorldMatrix(!0,!1),na.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?_r.lookAt(na,Va,this.up):_r.lookAt(Va,na,this.up),this.quaternion.setFromRotationMatrix(_r),a&&(_r.extractRotation(a.matrixWorld),Mi.setFromRotationMatrix(_r),this.quaternion.premultiply(Mi.invert()))}add(t){if(arguments.length>1){for(let r=0;r<arguments.length;r++)this.add(arguments[r]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(xl),Si.child=t,this.dispatchEvent(Si),Si.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}let r=this.children.indexOf(t);return r!==-1&&(t.parent=null,this.children.splice(r,1),t.dispatchEvent(Qc),Ds.child=t,this.dispatchEvent(Ds),Ds.child=null),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),_r.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),_r.multiply(t.parent.matrixWorld)),t.applyMatrix4(_r),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(xl),Si.child=t,this.dispatchEvent(Si),Si.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,r){if(this[t]===r)return this;for(let i=0,a=this.children.length;i<a;i++){let n=this.children[i].getObjectByProperty(t,r);if(n!==void 0)return n}}getObjectsByProperty(t,r,i=[]){this[t]===r&&i.push(this);let a=this.children;for(let n=0,s=a.length;n<s;n++)a[n].getObjectsByProperty(t,r,i);return i}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(na,t,$c),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(na,Jc,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let r=this.matrixWorld.elements;return t.set(r[8],r[9],r[10]).normalize()}raycast(){}traverse(t){t(this);let r=this.children;for(let i=0,a=r.length;i<a;i++)r[i].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let r=this.children;for(let i=0,a=r.length;i<a;i++)r[i].traverseVisible(t)}traverseAncestors(t){let r=this.parent;r!==null&&(t(r),r.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);let r=this.children;for(let i=0,a=r.length;i<a;i++)r[i].updateMatrixWorld(t)}updateWorldMatrix(t,r){let i=this.parent;if(t===!0&&i!==null&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),r===!0){let a=this.children;for(let n=0,s=a.length;n<s;n++)a[n].updateWorldMatrix(!1,!0)}}toJSON(t){let r=t===void 0||typeof t=="string",i={};r&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let a={};a.uuid=this.uuid,a.type=this.type,this.name!==""&&(a.name=this.name),this.castShadow===!0&&(a.castShadow=!0),this.receiveShadow===!0&&(a.receiveShadow=!0),this.visible===!1&&(a.visible=!1),this.frustumCulled===!1&&(a.frustumCulled=!1),this.renderOrder!==0&&(a.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(a.userData=this.userData),a.layers=this.layers.mask,a.matrix=this.matrix.toArray(),a.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(a.matrixAutoUpdate=!1),this.isInstancedMesh&&(a.type="InstancedMesh",a.count=this.count,a.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(a.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(a.type="BatchedMesh",a.perObjectFrustumCulled=this.perObjectFrustumCulled,a.sortObjects=this.sortObjects,a.drawRanges=this._drawRanges,a.reservedRanges=this._reservedRanges,a.visibility=this._visibility,a.active=this._active,a.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),a.maxInstanceCount=this._maxInstanceCount,a.maxVertexCount=this._maxVertexCount,a.maxIndexCount=this._maxIndexCount,a.geometryInitialized=this._geometryInitialized,a.geometryCount=this._geometryCount,a.matricesTexture=this._matricesTexture.toJSON(t),this._colorsTexture!==null&&(a.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(a.boundingSphere={center:a.boundingSphere.center.toArray(),radius:a.boundingSphere.radius}),this.boundingBox!==null&&(a.boundingBox={min:a.boundingBox.min.toArray(),max:a.boundingBox.max.toArray()}));function n(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?a.background=this.background.toJSON():this.background.isTexture&&(a.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(a.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){a.geometry=n(t.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let l=o.shapes;if(Array.isArray(l))for(let u=0,h=l.length;u<h;u++){let c=l[u];n(t.shapes,c)}else n(t.shapes,l)}}if(this.isSkinnedMesh&&(a.bindMode=this.bindMode,a.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(n(t.skeletons,this.skeleton),a.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let l=0,u=this.material.length;l<u;l++)o.push(n(t.materials,this.material[l]));a.material=o}else a.material=n(t.materials,this.material);if(this.children.length>0){a.children=[];for(let o=0;o<this.children.length;o++)a.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){a.animations=[];for(let o=0;o<this.animations.length;o++){let l=this.animations[o];a.animations.push(n(t.animations,l))}}if(r){let o=s(t.geometries),l=s(t.materials),u=s(t.textures),h=s(t.images),c=s(t.shapes),d=s(t.skeletons),m=s(t.animations),_=s(t.nodes);o.length>0&&(i.geometries=o),l.length>0&&(i.materials=l),u.length>0&&(i.textures=u),h.length>0&&(i.images=h),c.length>0&&(i.shapes=c),d.length>0&&(i.skeletons=d),m.length>0&&(i.animations=m),_.length>0&&(i.nodes=_)}return i.object=a,i;function s(o){let l=[];for(let u in o){let h=o[u];delete h.metadata,l.push(h)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,r=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),r===!0)for(let i=0;i<t.children.length;i++){let a=t.children[i];this.add(a.clone())}return this}};ct.DEFAULT_UP=new L(0,1,0),ct.DEFAULT_MATRIX_AUTO_UPDATE=!0,ct.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Qt=new L,vr=new L,Us=new L,xr=new L,Ti=new L,Ei=new L,yl=new L,Ns=new L,Os=new L,Fs=new L,Bs=new tt,zs=new tt,Hs=new tt,bi=class ji{constructor(t=new L,r=new L,i=new L){this.a=t,this.b=r,this.c=i}static getNormal(t,r,i,a){a.subVectors(i,r),Qt.subVectors(t,r),a.cross(Qt);let n=a.lengthSq();return n>0?a.multiplyScalar(1/Math.sqrt(n)):a.set(0,0,0)}static getBarycoord(t,r,i,a,n){Qt.subVectors(a,r),vr.subVectors(i,r),Us.subVectors(t,r);let s=Qt.dot(Qt),o=Qt.dot(vr),l=Qt.dot(Us),u=vr.dot(vr),h=vr.dot(Us),c=s*u-o*o;if(c===0)return n.set(0,0,0),null;let d=1/c,m=(u*l-o*h)*d,_=(s*h-o*l)*d;return n.set(1-m-_,_,m)}static containsPoint(t,r,i,a){return this.getBarycoord(t,r,i,a,xr)===null?!1:xr.x>=0&&xr.y>=0&&xr.x+xr.y<=1}static getInterpolation(t,r,i,a,n,s,o,l){return this.getBarycoord(t,r,i,a,xr)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(n,xr.x),l.addScaledVector(s,xr.y),l.addScaledVector(o,xr.z),l)}static getInterpolatedAttribute(t,r,i,a,n,s){return Bs.setScalar(0),zs.setScalar(0),Hs.setScalar(0),Bs.fromBufferAttribute(t,r),zs.fromBufferAttribute(t,i),Hs.fromBufferAttribute(t,a),s.setScalar(0),s.addScaledVector(Bs,n.x),s.addScaledVector(zs,n.y),s.addScaledVector(Hs,n.z),s}static isFrontFacing(t,r,i,a){return Qt.subVectors(i,r),vr.subVectors(t,r),Qt.cross(vr).dot(a)<0}set(t,r,i){return this.a.copy(t),this.b.copy(r),this.c.copy(i),this}setFromPointsAndIndices(t,r,i,a){return this.a.copy(t[r]),this.b.copy(t[i]),this.c.copy(t[a]),this}setFromAttributeAndIndices(t,r,i,a){return this.a.fromBufferAttribute(t,r),this.b.fromBufferAttribute(t,i),this.c.fromBufferAttribute(t,a),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Qt.subVectors(this.c,this.b),vr.subVectors(this.a,this.b),Qt.cross(vr).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return ji.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,r){return ji.getBarycoord(t,this.a,this.b,this.c,r)}getInterpolation(t,r,i,a,n){return ji.getInterpolation(t,this.a,this.b,this.c,r,i,a,n)}containsPoint(t){return ji.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return ji.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,r){let i=this.a,a=this.b,n=this.c,s,o;Ti.subVectors(a,i),Ei.subVectors(n,i),Ns.subVectors(t,i);let l=Ti.dot(Ns),u=Ei.dot(Ns);if(l<=0&&u<=0)return r.copy(i);Os.subVectors(t,a);let h=Ti.dot(Os),c=Ei.dot(Os);if(h>=0&&c<=h)return r.copy(a);let d=l*c-h*u;if(d<=0&&l>=0&&h<=0)return s=l/(l-h),r.copy(i).addScaledVector(Ti,s);Fs.subVectors(t,n);let m=Ti.dot(Fs),_=Ei.dot(Fs);if(_>=0&&m<=_)return r.copy(n);let g=m*u-l*_;if(g<=0&&u>=0&&_<=0)return o=u/(u-_),r.copy(i).addScaledVector(Ei,o);let f=h*_-m*c;if(f<=0&&c-h>=0&&m-_>=0)return yl.subVectors(n,a),o=(c-h)/(c-h+(m-_)),r.copy(a).addScaledVector(yl,o);let p=1/(f+g+d);return s=g*p,o=d*p,r.copy(i).addScaledVector(Ti,s).addScaledVector(Ei,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},Ml={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Nr={h:0,s:0,l:0},Ga={h:0,s:0,l:0};function ks(e,t,r){return r<0&&(r+=1),r>1&&(r-=1),r<1/6?e+(t-e)*6*r:r<1/2?t:r<2/3?e+(t-e)*6*(2/3-r):e}var Ne=class{constructor(e,t,r){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,r)}set(e,t,r){if(t===void 0&&r===void 0){let i=e;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(e,t,r);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=at){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Ye.toWorkingColorSpace(this,t),this}setRGB(e,t,r,i=Ye.workingColorSpace){return this.r=e,this.g=t,this.b=r,Ye.toWorkingColorSpace(this,i),this}setHSL(e,t,r,i=Ye.workingColorSpace){if(e=Ts(e,1),t=Tt(t,0,1),r=Tt(r,0,1),t===0)this.r=this.g=this.b=r;else{let a=r<=.5?r*(1+t):r+t-r*t,n=2*r-a;this.r=ks(n,a,e+1/3),this.g=ks(n,a,e),this.b=ks(n,a,e-1/3)}return Ye.toWorkingColorSpace(this,i),this}setStyle(e,t=at){function r(a){a!==void 0&&parseFloat(a)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(e)){let a,n=i[1],s=i[2];switch(n){case"rgb":case"rgba":if(a=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(s))return r(a[4]),this.setRGB(Math.min(255,parseInt(a[1],10))/255,Math.min(255,parseInt(a[2],10))/255,Math.min(255,parseInt(a[3],10))/255,t);if(a=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(s))return r(a[4]),this.setRGB(Math.min(100,parseInt(a[1],10))/100,Math.min(100,parseInt(a[2],10))/100,Math.min(100,parseInt(a[3],10))/100,t);break;case"hsl":case"hsla":if(a=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(s))return r(a[4]),this.setHSL(parseFloat(a[1])/360,parseFloat(a[2])/100,parseFloat(a[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(e)){let a=i[1],n=a.length;if(n===3)return this.setRGB(parseInt(a.charAt(0),16)/15,parseInt(a.charAt(1),16)/15,parseInt(a.charAt(2),16)/15,t);if(n===6)return this.setHex(parseInt(a,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=at){let r=Ml[e.toLowerCase()];return r!==void 0?this.setHex(r,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=fr(e.r),this.g=fr(e.g),this.b=fr(e.b),this}copyLinearToSRGB(e){return this.r=mi(e.r),this.g=mi(e.g),this.b=mi(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=at){return Ye.fromWorkingColorSpace(bt.copy(this),e),Math.round(Tt(bt.r*255,0,255))*65536+Math.round(Tt(bt.g*255,0,255))*256+Math.round(Tt(bt.b*255,0,255))}getHexString(e=at){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Ye.workingColorSpace){Ye.fromWorkingColorSpace(bt.copy(this),t);let r=bt.r,i=bt.g,a=bt.b,n=Math.max(r,i,a),s=Math.min(r,i,a),o,l,u=(s+n)/2;if(s===n)o=0,l=0;else{let h=n-s;switch(l=u<=.5?h/(n+s):h/(2-n-s),n){case r:o=(i-a)/h+(i<a?6:0);break;case i:o=(a-r)/h+2;break;case a:o=(r-i)/h+4;break}o/=6}return e.h=o,e.s=l,e.l=u,e}getRGB(e,t=Ye.workingColorSpace){return Ye.fromWorkingColorSpace(bt.copy(this),t),e.r=bt.r,e.g=bt.g,e.b=bt.b,e}getStyle(e=at){Ye.fromWorkingColorSpace(bt.copy(this),e);let t=bt.r,r=bt.g,i=bt.b;return e!==at?`color(${e} ${t.toFixed(3)} ${r.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(r*255)},${Math.round(i*255)})`}offsetHSL(e,t,r){return this.getHSL(Nr),this.setHSL(Nr.h+e,Nr.s+t,Nr.l+r)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,r){return this.r=e.r+(t.r-e.r)*r,this.g=e.g+(t.g-e.g)*r,this.b=e.b+(t.b-e.b)*r,this}lerpHSL(e,t){this.getHSL(Nr),e.getHSL(Ga);let r=ea(Nr.h,Ga.h,t),i=ea(Nr.s,Ga.s,t),a=ea(Nr.l,Ga.l,t);return this.setHSL(r,i,a),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,r=this.g,i=this.b,a=e.elements;return this.r=a[0]*t+a[3]*r+a[6]*i,this.g=a[1]*t+a[4]*r+a[7]*i,this.b=a[2]*t+a[5]*r+a[8]*i,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},bt=new Ne;Ne.NAMES=Ml;var ed=0,er=class extends pi{static get type(){return"Material"}get type(){return this.constructor.type}set type(e){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:ed++}),this.uuid=qt(),this.name="",this.blending=ai,this.side=hr,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Pn,this.blendDst=In,this.blendEquation=Vr,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Ne(0,0,0),this.blendAlpha=0,this.depthFunc=ni,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Jo,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=di,this.stencilZFail=di,this.stencilZPass=di,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let r=e[t];if(r===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}let i=this[t];if(i===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(r):i&&i.isVector3&&r&&r.isVector3?i.copy(r):this[t]=r}}toJSON(e){let t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});let r={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.color&&this.color.isColor&&(r.color=this.color.getHex()),this.roughness!==void 0&&(r.roughness=this.roughness),this.metalness!==void 0&&(r.metalness=this.metalness),this.sheen!==void 0&&(r.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(r.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(r.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(r.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(r.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(r.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(r.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(r.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(r.shininess=this.shininess),this.clearcoat!==void 0&&(r.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(r.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(r.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(r.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(r.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,r.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(r.dispersion=this.dispersion),this.iridescence!==void 0&&(r.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(r.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(r.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(r.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(r.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(r.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(r.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(r.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(r.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(r.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(r.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(r.lightMap=this.lightMap.toJSON(e).uuid,r.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(r.aoMap=this.aoMap.toJSON(e).uuid,r.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(r.bumpMap=this.bumpMap.toJSON(e).uuid,r.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(r.normalMap=this.normalMap.toJSON(e).uuid,r.normalMapType=this.normalMapType,r.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(r.displacementMap=this.displacementMap.toJSON(e).uuid,r.displacementScale=this.displacementScale,r.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(r.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(r.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(r.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(r.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(r.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(r.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(r.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(r.combine=this.combine)),this.envMapRotation!==void 0&&(r.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(r.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(r.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(r.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(r.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(r.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(r.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(r.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(r.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(r.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(r.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(r.size=this.size),this.shadowSide!==null&&(r.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(r.sizeAttenuation=this.sizeAttenuation),this.blending!==ai&&(r.blending=this.blending),this.side!==hr&&(r.side=this.side),this.vertexColors===!0&&(r.vertexColors=!0),this.opacity<1&&(r.opacity=this.opacity),this.transparent===!0&&(r.transparent=!0),this.blendSrc!==Pn&&(r.blendSrc=this.blendSrc),this.blendDst!==In&&(r.blendDst=this.blendDst),this.blendEquation!==Vr&&(r.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(r.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(r.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(r.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(r.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(r.blendAlpha=this.blendAlpha),this.depthFunc!==ni&&(r.depthFunc=this.depthFunc),this.depthTest===!1&&(r.depthTest=this.depthTest),this.depthWrite===!1&&(r.depthWrite=this.depthWrite),this.colorWrite===!1&&(r.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(r.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Jo&&(r.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(r.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(r.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==di&&(r.stencilFail=this.stencilFail),this.stencilZFail!==di&&(r.stencilZFail=this.stencilZFail),this.stencilZPass!==di&&(r.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(r.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(r.rotation=this.rotation),this.polygonOffset===!0&&(r.polygonOffset=!0),this.polygonOffsetFactor!==0&&(r.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(r.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(r.linewidth=this.linewidth),this.dashSize!==void 0&&(r.dashSize=this.dashSize),this.gapSize!==void 0&&(r.gapSize=this.gapSize),this.scale!==void 0&&(r.scale=this.scale),this.dithering===!0&&(r.dithering=!0),this.alphaTest>0&&(r.alphaTest=this.alphaTest),this.alphaHash===!0&&(r.alphaHash=!0),this.alphaToCoverage===!0&&(r.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(r.premultipliedAlpha=!0),this.forceSinglePass===!0&&(r.forceSinglePass=!0),this.wireframe===!0&&(r.wireframe=!0),this.wireframeLinewidth>1&&(r.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(r.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(r.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(r.flatShading=!0),this.visible===!1&&(r.visible=!1),this.toneMapped===!1&&(r.toneMapped=!1),this.fog===!1&&(r.fog=!1),Object.keys(this.userData).length>0&&(r.userData=this.userData);function i(a){let n=[];for(let s in a){let o=a[s];delete o.metadata,n.push(o)}return n}if(t){let a=i(e.textures),n=i(e.images);a.length>0&&(r.textures=a),n.length>0&&(r.images=n)}return r}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,r=null;if(t!==null){let i=t.length;r=new Array(i);for(let a=0;a!==i;++a)r[a]=t[a].clone()}return this.clippingPlanes=r,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}},Vt=class extends er{static get type(){return"MeshBasicMaterial"}constructor(e){super(),this.isMeshBasicMaterial=!0,this.color=new Ne(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ur,this.combine=Do,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},ft=new L,Wa=new Fe,vt=class{constructor(e,t,r=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=r,this.usage=Ss,this.updateRanges=[],this.gpuType=Yt,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,r){e*=this.itemSize,r*=t.itemSize;for(let i=0,a=this.itemSize;i<a;i++)this.array[e+i]=t.array[r+i];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,r=this.count;t<r;t++)Wa.fromBufferAttribute(this,t),Wa.applyMatrix3(e),this.setXY(t,Wa.x,Wa.y);else if(this.itemSize===3)for(let t=0,r=this.count;t<r;t++)ft.fromBufferAttribute(this,t),ft.applyMatrix3(e),this.setXYZ(t,ft.x,ft.y,ft.z);return this}applyMatrix4(e){for(let t=0,r=this.count;t<r;t++)ft.fromBufferAttribute(this,t),ft.applyMatrix4(e),this.setXYZ(t,ft.x,ft.y,ft.z);return this}applyNormalMatrix(e){for(let t=0,r=this.count;t<r;t++)ft.fromBufferAttribute(this,t),ft.applyNormalMatrix(e),this.setXYZ(t,ft.x,ft.y,ft.z);return this}transformDirection(e){for(let t=0,r=this.count;t<r;t++)ft.fromBufferAttribute(this,t),ft.transformDirection(e),this.setXYZ(t,ft.x,ft.y,ft.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let r=this.array[e*this.itemSize+t];return this.normalized&&(r=Kt(r,this.array)),r}setComponent(e,t,r){return this.normalized&&(r=et(r,this.array)),this.array[e*this.itemSize+t]=r,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Kt(t,this.array)),t}setX(e,t){return this.normalized&&(t=et(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Kt(t,this.array)),t}setY(e,t){return this.normalized&&(t=et(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Kt(t,this.array)),t}setZ(e,t){return this.normalized&&(t=et(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Kt(t,this.array)),t}setW(e,t){return this.normalized&&(t=et(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,r){return e*=this.itemSize,this.normalized&&(t=et(t,this.array),r=et(r,this.array)),this.array[e+0]=t,this.array[e+1]=r,this}setXYZ(e,t,r,i){return e*=this.itemSize,this.normalized&&(t=et(t,this.array),r=et(r,this.array),i=et(i,this.array)),this.array[e+0]=t,this.array[e+1]=r,this.array[e+2]=i,this}setXYZW(e,t,r,i,a){return e*=this.itemSize,this.normalized&&(t=et(t,this.array),r=et(r,this.array),i=et(i,this.array),a=et(a,this.array)),this.array[e+0]=t,this.array[e+1]=r,this.array[e+2]=i,this.array[e+3]=a,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Ss&&(e.usage=this.usage),e}},Sl=class extends vt{constructor(e,t,r){super(new Uint16Array(e),t,r)}},Tl=class extends vt{constructor(e,t,r){super(new Uint32Array(e),t,r)}},dt=class extends vt{constructor(e,t,r){super(new Float32Array(e),t,r)}},td=0,Gt=new Ge,Vs=new ct,wi=new L,Bt=new Zt,sa=new Zt,Mt=new L,Rt=class fh extends pi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:td++}),this.uuid=qt(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(rl(t)?Tl:Sl)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,r){return this.attributes[t]=r,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,r,i=0){this.groups.push({start:t,count:r,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(t,r){this.drawRange.start=t,this.drawRange.count=r}applyMatrix4(t){let r=this.attributes.position;r!==void 0&&(r.applyMatrix4(t),r.needsUpdate=!0);let i=this.attributes.normal;if(i!==void 0){let n=new Ve().getNormalMatrix(t);i.applyNormalMatrix(n),i.needsUpdate=!0}let a=this.attributes.tangent;return a!==void 0&&(a.transformDirection(t),a.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return Gt.makeRotationFromQuaternion(t),this.applyMatrix4(Gt),this}rotateX(t){return Gt.makeRotationX(t),this.applyMatrix4(Gt),this}rotateY(t){return Gt.makeRotationY(t),this.applyMatrix4(Gt),this}rotateZ(t){return Gt.makeRotationZ(t),this.applyMatrix4(Gt),this}translate(t,r,i){return Gt.makeTranslation(t,r,i),this.applyMatrix4(Gt),this}scale(t,r,i){return Gt.makeScale(t,r,i),this.applyMatrix4(Gt),this}lookAt(t){return Vs.lookAt(t),Vs.updateMatrix(),this.applyMatrix4(Vs.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(wi).negate(),this.translate(wi.x,wi.y,wi.z),this}setFromPoints(t){let r=this.getAttribute("position");if(r===void 0){let i=[];for(let a=0,n=t.length;a<n;a++){let s=t[a];i.push(s.x,s.y,s.z||0)}this.setAttribute("position",new dt(i,3))}else{for(let i=0,a=r.count;i<a;i++){let n=t[i];r.setXYZ(i,n.x,n.y,n.z||0)}t.length>r.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),r.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Zt);let t=this.attributes.position,r=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new L(-1/0,-1/0,-1/0),new L(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),r)for(let i=0,a=r.length;i<a;i++){let n=r[i];Bt.setFromBufferAttribute(n),this.morphTargetsRelative?(Mt.addVectors(this.boundingBox.min,Bt.min),this.boundingBox.expandByPoint(Mt),Mt.addVectors(this.boundingBox.max,Bt.max),this.boundingBox.expandByPoint(Mt)):(this.boundingBox.expandByPoint(Bt.min),this.boundingBox.expandByPoint(Bt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new ir);let t=this.attributes.position,r=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new L,1/0);return}if(t){let i=this.boundingSphere.center;if(Bt.setFromBufferAttribute(t),r)for(let n=0,s=r.length;n<s;n++){let o=r[n];sa.setFromBufferAttribute(o),this.morphTargetsRelative?(Mt.addVectors(Bt.min,sa.min),Bt.expandByPoint(Mt),Mt.addVectors(Bt.max,sa.max),Bt.expandByPoint(Mt)):(Bt.expandByPoint(sa.min),Bt.expandByPoint(sa.max))}Bt.getCenter(i);let a=0;for(let n=0,s=t.count;n<s;n++)Mt.fromBufferAttribute(t,n),a=Math.max(a,i.distanceToSquared(Mt));if(r)for(let n=0,s=r.length;n<s;n++){let o=r[n],l=this.morphTargetsRelative;for(let u=0,h=o.count;u<h;u++)Mt.fromBufferAttribute(o,u),l&&(wi.fromBufferAttribute(t,u),Mt.add(wi)),a=Math.max(a,i.distanceToSquared(Mt))}this.boundingSphere.radius=Math.sqrt(a),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,r=this.attributes;if(t===null||r.position===void 0||r.normal===void 0||r.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let i=r.position,a=r.normal,n=r.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new vt(new Float32Array(4*i.count),4));let s=this.getAttribute("tangent"),o=[],l=[];for(let U=0;U<i.count;U++)o[U]=new L,l[U]=new L;let u=new L,h=new L,c=new L,d=new Fe,m=new Fe,_=new Fe,g=new L,f=new L;function p(U,M,T){u.fromBufferAttribute(i,U),h.fromBufferAttribute(i,M),c.fromBufferAttribute(i,T),d.fromBufferAttribute(n,U),m.fromBufferAttribute(n,M),_.fromBufferAttribute(n,T),h.sub(u),c.sub(u),m.sub(d),_.sub(d);let P=1/(m.x*_.y-_.x*m.y);isFinite(P)&&(g.copy(h).multiplyScalar(_.y).addScaledVector(c,-m.y).multiplyScalar(P),f.copy(c).multiplyScalar(m.x).addScaledVector(h,-_.x).multiplyScalar(P),o[U].add(g),o[M].add(g),o[T].add(g),l[U].add(f),l[M].add(f),l[T].add(f))}let x=this.groups;x.length===0&&(x=[{start:0,count:t.count}]);for(let U=0,M=x.length;U<M;++U){let T=x[U],P=T.start,z=T.count;for(let q=P,K=P+z;q<K;q+=3)p(t.getX(q+0),t.getX(q+1),t.getX(q+2))}let v=new L,E=new L,I=new L,w=new L;function R(U){I.fromBufferAttribute(a,U),w.copy(I);let M=o[U];v.copy(M),v.sub(I.multiplyScalar(I.dot(M))).normalize(),E.crossVectors(w,M);let T=E.dot(l[U])<0?-1:1;s.setXYZW(U,v.x,v.y,v.z,T)}for(let U=0,M=x.length;U<M;++U){let T=x[U],P=T.start,z=T.count;for(let q=P,K=P+z;q<K;q+=3)R(t.getX(q+0)),R(t.getX(q+1)),R(t.getX(q+2))}}computeVertexNormals(){let t=this.index,r=this.getAttribute("position");if(r!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new vt(new Float32Array(r.count*3),3),this.setAttribute("normal",i);else for(let d=0,m=i.count;d<m;d++)i.setXYZ(d,0,0,0);let a=new L,n=new L,s=new L,o=new L,l=new L,u=new L,h=new L,c=new L;if(t)for(let d=0,m=t.count;d<m;d+=3){let _=t.getX(d+0),g=t.getX(d+1),f=t.getX(d+2);a.fromBufferAttribute(r,_),n.fromBufferAttribute(r,g),s.fromBufferAttribute(r,f),h.subVectors(s,n),c.subVectors(a,n),h.cross(c),o.fromBufferAttribute(i,_),l.fromBufferAttribute(i,g),u.fromBufferAttribute(i,f),o.add(h),l.add(h),u.add(h),i.setXYZ(_,o.x,o.y,o.z),i.setXYZ(g,l.x,l.y,l.z),i.setXYZ(f,u.x,u.y,u.z)}else for(let d=0,m=r.count;d<m;d+=3)a.fromBufferAttribute(r,d+0),n.fromBufferAttribute(r,d+1),s.fromBufferAttribute(r,d+2),h.subVectors(s,n),c.subVectors(a,n),h.cross(c),i.setXYZ(d+0,h.x,h.y,h.z),i.setXYZ(d+1,h.x,h.y,h.z),i.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let r=0,i=t.count;r<i;r++)Mt.fromBufferAttribute(t,r),Mt.normalize(),t.setXYZ(r,Mt.x,Mt.y,Mt.z)}toNonIndexed(){function t(o,l){let u=o.array,h=o.itemSize,c=o.normalized,d=new u.constructor(l.length*h),m=0,_=0;for(let g=0,f=l.length;g<f;g++){o.isInterleavedBufferAttribute?m=l[g]*o.data.stride+o.offset:m=l[g]*h;for(let p=0;p<h;p++)d[_++]=u[m++]}return new vt(d,h,c)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let r=new fh,i=this.index.array,a=this.attributes;for(let o in a){let l=a[o],u=t(l,i);r.setAttribute(o,u)}let n=this.morphAttributes;for(let o in n){let l=[],u=n[o];for(let h=0,c=u.length;h<c;h++){let d=u[h],m=t(d,i);l.push(m)}r.morphAttributes[o]=l}r.morphTargetsRelative=this.morphTargetsRelative;let s=this.groups;for(let o=0,l=s.length;o<l;o++){let u=s[o];r.addGroup(u.start,u.count,u.materialIndex)}return r}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let u in l)l[u]!==void 0&&(t[u]=l[u]);return t}t.data={attributes:{}};let r=this.index;r!==null&&(t.data.index={type:r.array.constructor.name,array:Array.prototype.slice.call(r.array)});let i=this.attributes;for(let l in i){let u=i[l];t.data.attributes[l]=u.toJSON(t.data)}let a={},n=!1;for(let l in this.morphAttributes){let u=this.morphAttributes[l],h=[];for(let c=0,d=u.length;c<d;c++){let m=u[c];h.push(m.toJSON(t.data))}h.length>0&&(a[l]=h,n=!0)}n&&(t.data.morphAttributes=a,t.data.morphTargetsRelative=this.morphTargetsRelative);let s=this.groups;s.length>0&&(t.data.groups=JSON.parse(JSON.stringify(s)));let o=this.boundingSphere;return o!==null&&(t.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let r={};this.name=t.name;let i=t.index;i!==null&&this.setIndex(i.clone(r));let a=t.attributes;for(let u in a){let h=a[u];this.setAttribute(u,h.clone(r))}let n=t.morphAttributes;for(let u in n){let h=[],c=n[u];for(let d=0,m=c.length;d<m;d++)h.push(c[d].clone(r));this.morphAttributes[u]=h}this.morphTargetsRelative=t.morphTargetsRelative;let s=t.groups;for(let u=0,h=s.length;u<h;u++){let c=s[u];this.addGroup(c.start,c.count,c.materialIndex)}let o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());let l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},El=new Ge,Yr=new Ha,Xa=new ir,bl=new L,ja=new L,Ya=new L,qa=new L,Gs=new L,Ka=new L,wl=new L,Za=new L,ut=class extends ct{constructor(e=new Rt,t=new Vt){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let r=e[t[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let i=0,a=r.length;i<a;i++){let n=r[i].name||String(i);this.morphTargetInfluences.push(0),this.morphTargetDictionary[n]=i}}}}getVertexPosition(e,t){let r=this.geometry,i=r.attributes.position,a=r.morphAttributes.position,n=r.morphTargetsRelative;t.fromBufferAttribute(i,e);let s=this.morphTargetInfluences;if(a&&s){Ka.set(0,0,0);for(let o=0,l=a.length;o<l;o++){let u=s[o],h=a[o];u!==0&&(Gs.fromBufferAttribute(h,e),n?Ka.addScaledVector(Gs,u):Ka.addScaledVector(Gs.sub(t),u))}t.add(Ka)}return t}raycast(e,t){let r=this.geometry,i=this.material,a=this.matrixWorld;i!==void 0&&(r.boundingSphere===null&&r.computeBoundingSphere(),Xa.copy(r.boundingSphere),Xa.applyMatrix4(a),Yr.copy(e.ray).recast(e.near),!(Xa.containsPoint(Yr.origin)===!1&&(Yr.intersectSphere(Xa,bl)===null||Yr.origin.distanceToSquared(bl)>(e.far-e.near)**2))&&(El.copy(a).invert(),Yr.copy(e.ray).applyMatrix4(El),!(r.boundingBox!==null&&Yr.intersectsBox(r.boundingBox)===!1)&&this._computeIntersections(e,t,Yr)))}_computeIntersections(e,t,r){let i,a=this.geometry,n=this.material,s=a.index,o=a.attributes.position,l=a.attributes.uv,u=a.attributes.uv1,h=a.attributes.normal,c=a.groups,d=a.drawRange;if(s!==null)if(Array.isArray(n))for(let m=0,_=c.length;m<_;m++){let g=c[m],f=n[g.materialIndex],p=Math.max(g.start,d.start),x=Math.min(s.count,Math.min(g.start+g.count,d.start+d.count));for(let v=p,E=x;v<E;v+=3){let I=s.getX(v),w=s.getX(v+1),R=s.getX(v+2);i=$a(this,f,e,r,l,u,h,I,w,R),i&&(i.faceIndex=Math.floor(v/3),i.face.materialIndex=g.materialIndex,t.push(i))}}else{let m=Math.max(0,d.start),_=Math.min(s.count,d.start+d.count);for(let g=m,f=_;g<f;g+=3){let p=s.getX(g),x=s.getX(g+1),v=s.getX(g+2);i=$a(this,n,e,r,l,u,h,p,x,v),i&&(i.faceIndex=Math.floor(g/3),t.push(i))}}else if(o!==void 0)if(Array.isArray(n))for(let m=0,_=c.length;m<_;m++){let g=c[m],f=n[g.materialIndex],p=Math.max(g.start,d.start),x=Math.min(o.count,Math.min(g.start+g.count,d.start+d.count));for(let v=p,E=x;v<E;v+=3){let I=v,w=v+1,R=v+2;i=$a(this,f,e,r,l,u,h,I,w,R),i&&(i.faceIndex=Math.floor(v/3),i.face.materialIndex=g.materialIndex,t.push(i))}}else{let m=Math.max(0,d.start),_=Math.min(o.count,d.start+d.count);for(let g=m,f=_;g<f;g+=3){let p=g,x=g+1,v=g+2;i=$a(this,n,e,r,l,u,h,p,x,v),i&&(i.faceIndex=Math.floor(g/3),t.push(i))}}}};function rd(e,t,r,i,a,n,s,o){let l;if(t.side===It?l=i.intersectTriangle(s,n,a,!0,o):l=i.intersectTriangle(a,n,s,t.side===hr,o),l===null)return null;Za.copy(o),Za.applyMatrix4(e.matrixWorld);let u=r.ray.origin.distanceTo(Za);return u<r.near||u>r.far?null:{distance:u,point:Za.clone(),object:e}}function $a(e,t,r,i,a,n,s,o,l,u){e.getVertexPosition(o,ja),e.getVertexPosition(l,Ya),e.getVertexPosition(u,qa);let h=rd(e,t,r,i,ja,Ya,qa,wl);if(h){let c=new L;bi.getBarycoord(wl,ja,Ya,qa,c),a&&(h.uv=bi.getInterpolatedAttribute(a,o,l,u,c,new Fe)),n&&(h.uv1=bi.getInterpolatedAttribute(n,o,l,u,c,new Fe)),s&&(h.normal=bi.getInterpolatedAttribute(s,o,l,u,c,new L),h.normal.dot(i.direction)>0&&h.normal.multiplyScalar(-1));let d={a:o,b:l,c:u,normal:new L,materialIndex:0};bi.getNormal(ja,Ya,qa,d.normal),h.face=d,h.barycoord=c}return h}var Ja=class mh extends Rt{constructor(t=1,r=1,i=1,a=1,n=1,s=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:r,depth:i,widthSegments:a,heightSegments:n,depthSegments:s};let o=this;a=Math.floor(a),n=Math.floor(n),s=Math.floor(s);let l=[],u=[],h=[],c=[],d=0,m=0;_("z","y","x",-1,-1,i,r,t,s,n,0),_("z","y","x",1,-1,i,r,-t,s,n,1),_("x","z","y",1,1,t,i,r,a,s,2),_("x","z","y",1,-1,t,i,-r,a,s,3),_("x","y","z",1,-1,t,r,i,a,n,4),_("x","y","z",-1,-1,t,r,-i,a,n,5),this.setIndex(l),this.setAttribute("position",new dt(u,3)),this.setAttribute("normal",new dt(h,3)),this.setAttribute("uv",new dt(c,2));function _(g,f,p,x,v,E,I,w,R,U,M){let T=E/R,P=I/U,z=E/2,q=I/2,K=w/2,Y=R+1,W=U+1,ae=0,Z=0,te=new L;for(let de=0;de<W;de++){let Pe=de*P-q;for(let ve=0;ve<Y;ve++){let $=ve*T-z;te[g]=$*x,te[f]=Pe*v,te[p]=K,u.push(te.x,te.y,te.z),te[g]=0,te[f]=0,te[p]=w>0?1:-1,h.push(te.x,te.y,te.z),c.push(ve/R),c.push(1-de/U),ae+=1}}for(let de=0;de<U;de++)for(let Pe=0;Pe<R;Pe++){let ve=d+Pe+Y*de,$=d+Pe+Y*(de+1),oe=d+(Pe+1)+Y*(de+1),ge=d+(Pe+1)+Y*de;l.push(ve,$,ge),l.push($,oe,ge),Z+=6}o.addGroup(m,Z,M),m+=Z,d+=ae}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new mh(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function Ai(e){let t={};for(let r in e){t[r]={};for(let i in e[r]){let a=e[r][i];a&&(a.isColor||a.isMatrix3||a.isMatrix4||a.isVector2||a.isVector3||a.isVector4||a.isTexture||a.isQuaternion)?a.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[r][i]=null):t[r][i]=a.clone():Array.isArray(a)?t[r][i]=a.slice():t[r][i]=a}}return t}function Ct(e){let t={};for(let r=0;r<e.length;r++){let i=Ai(e[r]);for(let a in i)t[a]=i[a]}return t}function id(e){let t=[];for(let r=0;r<e.length;r++)t.push(e[r].clone());return t}function Al(e){let t=e.getRenderTarget();return t===null?e.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Ye.workingColorSpace}var ad={clone:Ai,merge:Ct},nd=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,sd=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Or=class extends er{static get type(){return"ShaderMaterial"}constructor(e){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=nd,this.fragmentShader=sd,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Ai(e.uniforms),this.uniformsGroups=id(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let i in this.uniforms){let a=this.uniforms[i].value;a&&a.isTexture?t.uniforms[i]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[i]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[i]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[i]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[i]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[i]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[i]={type:"m4",value:a.toArray()}:t.uniforms[i]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let r={};for(let i in this.extensions)this.extensions[i]===!0&&(r[i]=!0);return Object.keys(r).length>0&&(t.extensions=r),t}},Rl=class extends ct{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Ge,this.projectionMatrix=new Ge,this.projectionMatrixInverse=new Ge,this.coordinateSystem=pr}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},Fr=new L,Cl=new Fe,Ll=new Fe,Lt=class extends Rl{constructor(e=50,t=1,r=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=r,this.far=i,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=fi*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(Qi*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return fi*2*Math.atan(Math.tan(Qi*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,r){Fr.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Fr.x,Fr.y).multiplyScalar(-e/Fr.z),Fr.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),r.set(Fr.x,Fr.y).multiplyScalar(-e/Fr.z)}getViewSize(e,t){return this.getViewBounds(e,Cl,Ll),t.subVectors(Ll,Cl)}setViewOffset(e,t,r,i,a,n){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=r,this.view.offsetY=i,this.view.width=a,this.view.height=n,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(Qi*.5*this.fov)/this.zoom,r=2*t,i=this.aspect*r,a=-.5*i,n=this.view;if(this.view!==null&&this.view.enabled){let o=n.fullWidth,l=n.fullHeight;a+=n.offsetX*i/o,t-=n.offsetY*r/l,i*=n.width/o,r*=n.height/l}let s=this.filmOffset;s!==0&&(a+=e*s/this.getFilmWidth()),this.projectionMatrix.makePerspective(a,a+i,t,t-r,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},Ri=-90,Ci=1,od=class extends ct{constructor(e,t,r){super(),this.type="CubeCamera",this.renderTarget=r,this.coordinateSystem=null,this.activeMipmapLevel=0;let i=new Lt(Ri,Ci,e,t);i.layers=this.layers,this.add(i);let a=new Lt(Ri,Ci,e,t);a.layers=this.layers,this.add(a);let n=new Lt(Ri,Ci,e,t);n.layers=this.layers,this.add(n);let s=new Lt(Ri,Ci,e,t);s.layers=this.layers,this.add(s);let o=new Lt(Ri,Ci,e,t);o.layers=this.layers,this.add(o);let l=new Lt(Ri,Ci,e,t);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[r,i,a,n,s,o]=t;for(let l of t)this.remove(l);if(e===pr)r.up.set(0,1,0),r.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),a.up.set(0,0,-1),a.lookAt(0,1,0),n.up.set(0,0,1),n.lookAt(0,-1,0),s.up.set(0,1,0),s.lookAt(0,0,1),o.up.set(0,1,0),o.lookAt(0,0,-1);else if(e===Ua)r.up.set(0,-1,0),r.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),a.up.set(0,0,1),a.lookAt(0,1,0),n.up.set(0,0,-1),n.lookAt(0,-1,0),s.up.set(0,-1,0),s.lookAt(0,0,1),o.up.set(0,-1,0),o.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(let l of t)this.add(l),l.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:r,activeMipmapLevel:i}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[a,n,s,o,l,u]=this.children,h=e.getRenderTarget(),c=e.getActiveCubeFace(),d=e.getActiveMipmapLevel(),m=e.xr.enabled;e.xr.enabled=!1;let _=r.texture.generateMipmaps;r.texture.generateMipmaps=!1,e.setRenderTarget(r,0,i),e.render(t,a),e.setRenderTarget(r,1,i),e.render(t,n),e.setRenderTarget(r,2,i),e.render(t,s),e.setRenderTarget(r,3,i),e.render(t,o),e.setRenderTarget(r,4,i),e.render(t,l),r.texture.generateMipmaps=_,e.setRenderTarget(r,5,i),e.render(t,u),e.setRenderTarget(h,c,d),e.xr.enabled=m,r.texture.needsPMREMUpdate=!0}},Pl=class extends Et{constructor(e,t,r,i,a,n,s,o,l,u){e=e!==void 0?e:[],t=t!==void 0?t:si,super(e,t,r,i,a,n,s,o,l,u),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},ld=class extends Wr{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let r={width:e,height:e,depth:1},i=[r,r,r,r,r,r];this.texture=new Pl(i,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:_t}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let r={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new Ja(5,5,5),a=new Or({name:"CubemapFromEquirect",uniforms:Ai(r.uniforms),vertexShader:r.vertexShader,fragmentShader:r.fragmentShader,side:It,blending:br});a.uniforms.tEquirect.value=t;let n=new ut(i,a),s=t.minFilter;return t.minFilter===jt&&(t.minFilter=_t),new od(1,10,this).update(e,n),t.minFilter=s,n.geometry.dispose(),n.material.dispose(),this}clear(e,t,r,i){let a=e.getRenderTarget();for(let n=0;n<6;n++)e.setRenderTarget(this,n),e.clear(t,r,i);e.setRenderTarget(a)}},Ws=new L,ud=new L,hd=new Ve,qr=class{constructor(e=new L(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,r,i){return this.normal.set(e,t,r),this.constant=i,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,r){let i=Ws.subVectors(r,t).cross(ud.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(i,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){let r=e.delta(Ws),i=this.normal.dot(r);if(i===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let a=-(e.start.dot(this.normal)+this.constant)/i;return a<0||a>1?null:t.copy(e.start).addScaledVector(r,a)}intersectsLine(e){let t=this.distanceToPoint(e.start),r=this.distanceToPoint(e.end);return t<0&&r>0||r<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let r=t||hd.getNormalMatrix(e),i=this.coplanarPoint(Ws).applyMatrix4(e),a=this.normal.applyMatrix3(r).normalize();return this.constant=-i.dot(a),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}},Kr=new ir,Qa=new L,Xs=class{constructor(e=new qr,t=new qr,r=new qr,i=new qr,a=new qr,n=new qr){this.planes=[e,t,r,i,a,n]}set(e,t,r,i,a,n){let s=this.planes;return s[0].copy(e),s[1].copy(t),s[2].copy(r),s[3].copy(i),s[4].copy(a),s[5].copy(n),this}copy(e){let t=this.planes;for(let r=0;r<6;r++)t[r].copy(e.planes[r]);return this}setFromProjectionMatrix(e,t=pr){let r=this.planes,i=e.elements,a=i[0],n=i[1],s=i[2],o=i[3],l=i[4],u=i[5],h=i[6],c=i[7],d=i[8],m=i[9],_=i[10],g=i[11],f=i[12],p=i[13],x=i[14],v=i[15];if(r[0].setComponents(o-a,c-l,g-d,v-f).normalize(),r[1].setComponents(o+a,c+l,g+d,v+f).normalize(),r[2].setComponents(o+n,c+u,g+m,v+p).normalize(),r[3].setComponents(o-n,c-u,g-m,v-p).normalize(),r[4].setComponents(o-s,c-h,g-_,v-x).normalize(),t===pr)r[5].setComponents(o+s,c+h,g+_,v+x).normalize();else if(t===Ua)r[5].setComponents(s,h,_,x).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Kr.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Kr.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Kr)}intersectsSprite(e){return Kr.center.set(0,0,0),Kr.radius=.7071067811865476,Kr.applyMatrix4(e.matrixWorld),this.intersectsSphere(Kr)}intersectsSphere(e){let t=this.planes,r=e.center,i=-e.radius;for(let a=0;a<6;a++)if(t[a].distanceToPoint(r)<i)return!1;return!0}intersectsBox(e){let t=this.planes;for(let r=0;r<6;r++){let i=t[r];if(Qa.x=i.normal.x>0?e.max.x:e.min.x,Qa.y=i.normal.y>0?e.max.y:e.min.y,Qa.z=i.normal.z>0?e.max.z:e.min.z,i.distanceToPoint(Qa)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let r=0;r<6;r++)if(t[r].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function Il(){let e=null,t=!1,r=null,i=null;function a(n,s){r(n,s),i=e.requestAnimationFrame(a)}return{start:function(){t!==!0&&r!==null&&(i=e.requestAnimationFrame(a),t=!0)},stop:function(){e.cancelAnimationFrame(i),t=!1},setAnimationLoop:function(n){r=n},setContext:function(n){e=n}}}function cd(e){let t=new WeakMap;function r(o,l){let u=o.array,h=o.usage,c=u.byteLength,d=e.createBuffer();e.bindBuffer(l,d),e.bufferData(l,u,h),o.onUploadCallback();let m;if(u instanceof Float32Array)m=e.FLOAT;else if(u instanceof Uint16Array)o.isFloat16BufferAttribute?m=e.HALF_FLOAT:m=e.UNSIGNED_SHORT;else if(u instanceof Int16Array)m=e.SHORT;else if(u instanceof Uint32Array)m=e.UNSIGNED_INT;else if(u instanceof Int32Array)m=e.INT;else if(u instanceof Int8Array)m=e.BYTE;else if(u instanceof Uint8Array)m=e.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)m=e.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:d,type:m,bytesPerElement:u.BYTES_PER_ELEMENT,version:o.version,size:c}}function i(o,l,u){let h=l.array,c=l.updateRanges;if(e.bindBuffer(u,o),c.length===0)e.bufferSubData(u,0,h);else{c.sort((m,_)=>m.start-_.start);let d=0;for(let m=1;m<c.length;m++){let _=c[d],g=c[m];g.start<=_.start+_.count+1?_.count=Math.max(_.count,g.start+g.count-_.start):(++d,c[d]=g)}c.length=d+1;for(let m=0,_=c.length;m<_;m++){let g=c[m];e.bufferSubData(u,g.start*h.BYTES_PER_ELEMENT,h,g.start,g.count)}l.clearUpdateRanges()}l.onUploadCallback()}function a(o){return o.isInterleavedBufferAttribute&&(o=o.data),t.get(o)}function n(o){o.isInterleavedBufferAttribute&&(o=o.data);let l=t.get(o);l&&(e.deleteBuffer(l.buffer),t.delete(o))}function s(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){let h=t.get(o);(!h||h.version<o.version)&&t.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}let u=t.get(o);if(u===void 0)t.set(o,r(o,l));else if(u.version<o.version){if(u.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");i(u.buffer,o,l),u.version=o.version}}return{get:a,remove:n,update:s}}var js=class gh extends Rt{constructor(t=1,r=1,i=1,a=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:r,widthSegments:i,heightSegments:a};let n=t/2,s=r/2,o=Math.floor(i),l=Math.floor(a),u=o+1,h=l+1,c=t/o,d=r/l,m=[],_=[],g=[],f=[];for(let p=0;p<h;p++){let x=p*d-s;for(let v=0;v<u;v++){let E=v*c-n;_.push(E,-x,0),g.push(0,0,1),f.push(v/o),f.push(1-p/l)}}for(let p=0;p<l;p++)for(let x=0;x<o;x++){let v=x+u*p,E=x+u*(p+1),I=x+1+u*(p+1),w=x+1+u*p;m.push(v,E,w),m.push(E,I,w)}this.setIndex(m),this.setAttribute("position",new dt(_,3)),this.setAttribute("normal",new dt(g,3)),this.setAttribute("uv",new dt(f,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new gh(t.width,t.height,t.widthSegments,t.heightSegments)}},dd=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,pd=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,fd=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,md=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,gd=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,_d=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,vd=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,xd=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,yd=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Md=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Sd=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Td=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Ed=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,bd=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,wd=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Ad=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Rd=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Cd=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Ld=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Pd=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Id=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Dd=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Ud=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Nd=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Od=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Fd=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Bd=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,zd=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Hd=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,kd=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Vd="gl_FragColor = linearToOutputTexel( gl_FragColor );",Gd=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Wd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Xd=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,jd=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Yd=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,qd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Kd=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Zd=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,$d=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Jd=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Qd=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,ep=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,tp=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,rp=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,ip=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,ap=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,np=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,sp=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,op=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lp=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,up=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,hp=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,cp=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,dp=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,pp=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,fp=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,mp=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,gp=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,_p=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,vp=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,xp=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,yp=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Mp=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Sp=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Tp=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Ep=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,bp=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,wp=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Ap=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Rp=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Cp=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Lp=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Pp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Ip=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Dp=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Up=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Np=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Op=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Fp=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Bp=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,zp=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Hp=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,kp=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Vp=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Gp=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Wp=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Xp=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,jp=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Yp=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,qp=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Kp=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Zp=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,$p=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Jp=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Qp=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,ef=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,tf=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,rf=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,af=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,nf=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,sf=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,of=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,lf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,hf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,cf=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,df=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,pf=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,ff=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,mf=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,gf=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,_f=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,vf=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,xf=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,yf=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Mf=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Sf=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Tf=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ef=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,bf=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,wf=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Af=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Rf=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Cf=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Lf=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Pf=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,If=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Df=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Uf=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Nf=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Of=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Ff=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Bf=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,zf=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Hf=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,kf=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Vf=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Gf=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Wf=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Xf=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ke={alphahash_fragment:dd,alphahash_pars_fragment:pd,alphamap_fragment:fd,alphamap_pars_fragment:md,alphatest_fragment:gd,alphatest_pars_fragment:_d,aomap_fragment:vd,aomap_pars_fragment:xd,batching_pars_vertex:yd,batching_vertex:Md,begin_vertex:Sd,beginnormal_vertex:Td,bsdfs:Ed,iridescence_fragment:bd,bumpmap_pars_fragment:wd,clipping_planes_fragment:Ad,clipping_planes_pars_fragment:Rd,clipping_planes_pars_vertex:Cd,clipping_planes_vertex:Ld,color_fragment:Pd,color_pars_fragment:Id,color_pars_vertex:Dd,color_vertex:Ud,common:Nd,cube_uv_reflection_fragment:Od,defaultnormal_vertex:Fd,displacementmap_pars_vertex:Bd,displacementmap_vertex:zd,emissivemap_fragment:Hd,emissivemap_pars_fragment:kd,colorspace_fragment:Vd,colorspace_pars_fragment:Gd,envmap_fragment:Wd,envmap_common_pars_fragment:Xd,envmap_pars_fragment:jd,envmap_pars_vertex:Yd,envmap_physical_pars_fragment:ap,envmap_vertex:qd,fog_vertex:Kd,fog_pars_vertex:Zd,fog_fragment:$d,fog_pars_fragment:Jd,gradientmap_pars_fragment:Qd,lightmap_pars_fragment:ep,lights_lambert_fragment:tp,lights_lambert_pars_fragment:rp,lights_pars_begin:ip,lights_toon_fragment:np,lights_toon_pars_fragment:sp,lights_phong_fragment:op,lights_phong_pars_fragment:lp,lights_physical_fragment:up,lights_physical_pars_fragment:hp,lights_fragment_begin:cp,lights_fragment_maps:dp,lights_fragment_end:pp,logdepthbuf_fragment:fp,logdepthbuf_pars_fragment:mp,logdepthbuf_pars_vertex:gp,logdepthbuf_vertex:_p,map_fragment:vp,map_pars_fragment:xp,map_particle_fragment:yp,map_particle_pars_fragment:Mp,metalnessmap_fragment:Sp,metalnessmap_pars_fragment:Tp,morphinstance_vertex:Ep,morphcolor_vertex:bp,morphnormal_vertex:wp,morphtarget_pars_vertex:Ap,morphtarget_vertex:Rp,normal_fragment_begin:Cp,normal_fragment_maps:Lp,normal_pars_fragment:Pp,normal_pars_vertex:Ip,normal_vertex:Dp,normalmap_pars_fragment:Up,clearcoat_normal_fragment_begin:Np,clearcoat_normal_fragment_maps:Op,clearcoat_pars_fragment:Fp,iridescence_pars_fragment:Bp,opaque_fragment:zp,packing:Hp,premultiplied_alpha_fragment:kp,project_vertex:Vp,dithering_fragment:Gp,dithering_pars_fragment:Wp,roughnessmap_fragment:Xp,roughnessmap_pars_fragment:jp,shadowmap_pars_fragment:Yp,shadowmap_pars_vertex:qp,shadowmap_vertex:Kp,shadowmask_pars_fragment:Zp,skinbase_vertex:$p,skinning_pars_vertex:Jp,skinning_vertex:Qp,skinnormal_vertex:ef,specularmap_fragment:tf,specularmap_pars_fragment:rf,tonemapping_fragment:af,tonemapping_pars_fragment:nf,transmission_fragment:sf,transmission_pars_fragment:of,uv_pars_fragment:lf,uv_pars_vertex:uf,uv_vertex:hf,worldpos_vertex:cf,background_vert:df,background_frag:pf,backgroundCube_vert:ff,backgroundCube_frag:mf,cube_vert:gf,cube_frag:_f,depth_vert:vf,depth_frag:xf,distanceRGBA_vert:yf,distanceRGBA_frag:Mf,equirect_vert:Sf,equirect_frag:Tf,linedashed_vert:Ef,linedashed_frag:bf,meshbasic_vert:wf,meshbasic_frag:Af,meshlambert_vert:Rf,meshlambert_frag:Cf,meshmatcap_vert:Lf,meshmatcap_frag:Pf,meshnormal_vert:If,meshnormal_frag:Df,meshphong_vert:Uf,meshphong_frag:Nf,meshphysical_vert:Of,meshphysical_frag:Ff,meshtoon_vert:Bf,meshtoon_frag:zf,points_vert:Hf,points_frag:kf,shadow_vert:Vf,shadow_frag:Gf,sprite_vert:Wf,sprite_frag:Xf},ce={common:{diffuse:{value:new Ne(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ve},alphaMap:{value:null},alphaMapTransform:{value:new Ve},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ve}},envmap:{envMap:{value:null},envMapRotation:{value:new Ve},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ve}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ve}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ve},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ve},normalScale:{value:new Fe(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ve},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ve}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ve}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ve}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ne(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Ne(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ve},alphaTest:{value:0},uvTransform:{value:new Ve}},sprite:{diffuse:{value:new Ne(16777215)},opacity:{value:1},center:{value:new Fe(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ve},alphaMap:{value:null},alphaMapTransform:{value:new Ve},alphaTest:{value:0}}},ar={basic:{uniforms:Ct([ce.common,ce.specularmap,ce.envmap,ce.aomap,ce.lightmap,ce.fog]),vertexShader:ke.meshbasic_vert,fragmentShader:ke.meshbasic_frag},lambert:{uniforms:Ct([ce.common,ce.specularmap,ce.envmap,ce.aomap,ce.lightmap,ce.emissivemap,ce.bumpmap,ce.normalmap,ce.displacementmap,ce.fog,ce.lights,{emissive:{value:new Ne(0)}}]),vertexShader:ke.meshlambert_vert,fragmentShader:ke.meshlambert_frag},phong:{uniforms:Ct([ce.common,ce.specularmap,ce.envmap,ce.aomap,ce.lightmap,ce.emissivemap,ce.bumpmap,ce.normalmap,ce.displacementmap,ce.fog,ce.lights,{emissive:{value:new Ne(0)},specular:{value:new Ne(1118481)},shininess:{value:30}}]),vertexShader:ke.meshphong_vert,fragmentShader:ke.meshphong_frag},standard:{uniforms:Ct([ce.common,ce.envmap,ce.aomap,ce.lightmap,ce.emissivemap,ce.bumpmap,ce.normalmap,ce.displacementmap,ce.roughnessmap,ce.metalnessmap,ce.fog,ce.lights,{emissive:{value:new Ne(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ke.meshphysical_vert,fragmentShader:ke.meshphysical_frag},toon:{uniforms:Ct([ce.common,ce.aomap,ce.lightmap,ce.emissivemap,ce.bumpmap,ce.normalmap,ce.displacementmap,ce.gradientmap,ce.fog,ce.lights,{emissive:{value:new Ne(0)}}]),vertexShader:ke.meshtoon_vert,fragmentShader:ke.meshtoon_frag},matcap:{uniforms:Ct([ce.common,ce.bumpmap,ce.normalmap,ce.displacementmap,ce.fog,{matcap:{value:null}}]),vertexShader:ke.meshmatcap_vert,fragmentShader:ke.meshmatcap_frag},points:{uniforms:Ct([ce.points,ce.fog]),vertexShader:ke.points_vert,fragmentShader:ke.points_frag},dashed:{uniforms:Ct([ce.common,ce.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ke.linedashed_vert,fragmentShader:ke.linedashed_frag},depth:{uniforms:Ct([ce.common,ce.displacementmap]),vertexShader:ke.depth_vert,fragmentShader:ke.depth_frag},normal:{uniforms:Ct([ce.common,ce.bumpmap,ce.normalmap,ce.displacementmap,{opacity:{value:1}}]),vertexShader:ke.meshnormal_vert,fragmentShader:ke.meshnormal_frag},sprite:{uniforms:Ct([ce.sprite,ce.fog]),vertexShader:ke.sprite_vert,fragmentShader:ke.sprite_frag},background:{uniforms:{uvTransform:{value:new Ve},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ke.background_vert,fragmentShader:ke.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Ve}},vertexShader:ke.backgroundCube_vert,fragmentShader:ke.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ke.cube_vert,fragmentShader:ke.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ke.equirect_vert,fragmentShader:ke.equirect_frag},distanceRGBA:{uniforms:Ct([ce.common,ce.displacementmap,{referencePosition:{value:new L},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:ke.distanceRGBA_vert,fragmentShader:ke.distanceRGBA_frag},shadow:{uniforms:Ct([ce.lights,ce.fog,{color:{value:new Ne(0)},opacity:{value:1}}]),vertexShader:ke.shadow_vert,fragmentShader:ke.shadow_frag}};ar.physical={uniforms:Ct([ar.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ve},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ve},clearcoatNormalScale:{value:new Fe(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ve},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ve},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ve},sheen:{value:0},sheenColor:{value:new Ne(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ve},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ve},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ve},transmissionSamplerSize:{value:new Fe},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ve},attenuationDistance:{value:0},attenuationColor:{value:new Ne(0)},specularColor:{value:new Ne(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ve},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ve},anisotropyVector:{value:new Fe},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ve}}]),vertexShader:ke.meshphysical_vert,fragmentShader:ke.meshphysical_frag};var en={r:0,b:0,g:0},Zr=new Ur,jf=new Ge;function Yf(e,t,r,i,a,n,s){let o=new Ne(0),l=n===!0?0:1,u,h,c=null,d=0,m=null;function _(x){let v=x.isScene===!0?x.background:null;return v&&v.isTexture&&(v=(x.backgroundBlurriness>0?r:t).get(v)),v}function g(x){let v=!1,E=_(x);E===null?p(o,l):E&&E.isColor&&(p(E,1),v=!0);let I=e.xr.getEnvironmentBlendMode();I==="additive"?i.buffers.color.setClear(0,0,0,1,s):I==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,s),(e.autoClear||v)&&(i.buffers.depth.setTest(!0),i.buffers.depth.setMask(!0),i.buffers.color.setMask(!0),e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil))}function f(x,v){let E=_(v);E&&(E.isCubeTexture||E.mapping===ba)?(h===void 0&&(h=new ut(new Ja(1,1,1),new Or({name:"BackgroundCubeMaterial",uniforms:Ai(ar.backgroundCube.uniforms),vertexShader:ar.backgroundCube.vertexShader,fragmentShader:ar.backgroundCube.fragmentShader,side:It,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(I,w,R){this.matrixWorld.copyPosition(R.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),a.update(h)),Zr.copy(v.backgroundRotation),Zr.x*=-1,Zr.y*=-1,Zr.z*=-1,E.isCubeTexture&&E.isRenderTargetTexture===!1&&(Zr.y*=-1,Zr.z*=-1),h.material.uniforms.envMap.value=E,h.material.uniforms.flipEnvMap.value=E.isCubeTexture&&E.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=v.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(jf.makeRotationFromEuler(Zr)),h.material.toneMapped=Ye.getTransfer(E.colorSpace)!==it,(c!==E||d!==E.version||m!==e.toneMapping)&&(h.material.needsUpdate=!0,c=E,d=E.version,m=e.toneMapping),h.layers.enableAll(),x.unshift(h,h.geometry,h.material,0,0,null)):E&&E.isTexture&&(u===void 0&&(u=new ut(new js(2,2),new Or({name:"BackgroundMaterial",uniforms:Ai(ar.background.uniforms),vertexShader:ar.background.vertexShader,fragmentShader:ar.background.fragmentShader,side:hr,depthTest:!1,depthWrite:!1,fog:!1})),u.geometry.deleteAttribute("normal"),Object.defineProperty(u.material,"map",{get:function(){return this.uniforms.t2D.value}}),a.update(u)),u.material.uniforms.t2D.value=E,u.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,u.material.toneMapped=Ye.getTransfer(E.colorSpace)!==it,E.matrixAutoUpdate===!0&&E.updateMatrix(),u.material.uniforms.uvTransform.value.copy(E.matrix),(c!==E||d!==E.version||m!==e.toneMapping)&&(u.material.needsUpdate=!0,c=E,d=E.version,m=e.toneMapping),u.layers.enableAll(),x.unshift(u,u.geometry,u.material,0,0,null))}function p(x,v){x.getRGB(en,Al(e)),i.buffers.color.setClear(en.r,en.g,en.b,v,s)}return{getClearColor:function(){return o},setClearColor:function(x,v=1){o.set(x),l=v,p(o,l)},getClearAlpha:function(){return l},setClearAlpha:function(x){l=x,p(o,l)},render:g,addToRenderList:f}}function qf(e,t){let r=e.getParameter(e.MAX_VERTEX_ATTRIBS),i={},a=d(null),n=a,s=!1;function o(T,P,z,q,K){let Y=!1,W=c(q,z,P);n!==W&&(n=W,u(n.object)),Y=m(T,q,z,K),Y&&_(T,q,z,K),K!==null&&t.update(K,e.ELEMENT_ARRAY_BUFFER),(Y||s)&&(s=!1,E(T,P,z,q),K!==null&&e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,t.get(K).buffer))}function l(){return e.createVertexArray()}function u(T){return e.bindVertexArray(T)}function h(T){return e.deleteVertexArray(T)}function c(T,P,z){let q=z.wireframe===!0,K=i[T.id];K===void 0&&(K={},i[T.id]=K);let Y=K[P.id];Y===void 0&&(Y={},K[P.id]=Y);let W=Y[q];return W===void 0&&(W=d(l()),Y[q]=W),W}function d(T){let P=[],z=[],q=[];for(let K=0;K<r;K++)P[K]=0,z[K]=0,q[K]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:P,enabledAttributes:z,attributeDivisors:q,object:T,attributes:{},index:null}}function m(T,P,z,q){let K=n.attributes,Y=P.attributes,W=0,ae=z.getAttributes();for(let Z in ae)if(ae[Z].location>=0){let te=K[Z],de=Y[Z];if(de===void 0&&(Z==="instanceMatrix"&&T.instanceMatrix&&(de=T.instanceMatrix),Z==="instanceColor"&&T.instanceColor&&(de=T.instanceColor)),te===void 0||te.attribute!==de||de&&te.data!==de.data)return!0;W++}return n.attributesNum!==W||n.index!==q}function _(T,P,z,q){let K={},Y=P.attributes,W=0,ae=z.getAttributes();for(let Z in ae)if(ae[Z].location>=0){let te=Y[Z];te===void 0&&(Z==="instanceMatrix"&&T.instanceMatrix&&(te=T.instanceMatrix),Z==="instanceColor"&&T.instanceColor&&(te=T.instanceColor));let de={};de.attribute=te,te&&te.data&&(de.data=te.data),K[Z]=de,W++}n.attributes=K,n.attributesNum=W,n.index=q}function g(){let T=n.newAttributes;for(let P=0,z=T.length;P<z;P++)T[P]=0}function f(T){p(T,0)}function p(T,P){let z=n.newAttributes,q=n.enabledAttributes,K=n.attributeDivisors;z[T]=1,q[T]===0&&(e.enableVertexAttribArray(T),q[T]=1),K[T]!==P&&(e.vertexAttribDivisor(T,P),K[T]=P)}function x(){let T=n.newAttributes,P=n.enabledAttributes;for(let z=0,q=P.length;z<q;z++)P[z]!==T[z]&&(e.disableVertexAttribArray(z),P[z]=0)}function v(T,P,z,q,K,Y,W){W===!0?e.vertexAttribIPointer(T,P,z,K,Y):e.vertexAttribPointer(T,P,z,q,K,Y)}function E(T,P,z,q){g();let K=q.attributes,Y=z.getAttributes(),W=P.defaultAttributeValues;for(let ae in Y){let Z=Y[ae];if(Z.location>=0){let te=K[ae];if(te===void 0&&(ae==="instanceMatrix"&&T.instanceMatrix&&(te=T.instanceMatrix),ae==="instanceColor"&&T.instanceColor&&(te=T.instanceColor)),te!==void 0){let de=te.normalized,Pe=te.itemSize,ve=t.get(te);if(ve===void 0)continue;let $=ve.buffer,oe=ve.type,ge=ve.bytesPerElement,Ee=oe===e.INT||oe===e.UNSIGNED_INT||te.gpuType===kn;if(te.isInterleavedBufferAttribute){let he=te.data,Ce=he.stride,Ke=te.offset;if(he.isInstancedInterleavedBuffer){for(let Xe=0;Xe<Z.locationSize;Xe++)p(Z.location+Xe,he.meshPerAttribute);T.isInstancedMesh!==!0&&q._maxInstanceCount===void 0&&(q._maxInstanceCount=he.meshPerAttribute*he.count)}else for(let Xe=0;Xe<Z.locationSize;Xe++)f(Z.location+Xe);e.bindBuffer(e.ARRAY_BUFFER,$);for(let Xe=0;Xe<Z.locationSize;Xe++)v(Z.location+Xe,Pe/Z.locationSize,oe,de,Ce*ge,(Ke+Pe/Z.locationSize*Xe)*ge,Ee)}else{if(te.isInstancedBufferAttribute){for(let he=0;he<Z.locationSize;he++)p(Z.location+he,te.meshPerAttribute);T.isInstancedMesh!==!0&&q._maxInstanceCount===void 0&&(q._maxInstanceCount=te.meshPerAttribute*te.count)}else for(let he=0;he<Z.locationSize;he++)f(Z.location+he);e.bindBuffer(e.ARRAY_BUFFER,$);for(let he=0;he<Z.locationSize;he++)v(Z.location+he,Pe/Z.locationSize,oe,de,Pe*ge,Pe/Z.locationSize*he*ge,Ee)}}else if(W!==void 0){let de=W[ae];if(de!==void 0)switch(de.length){case 2:e.vertexAttrib2fv(Z.location,de);break;case 3:e.vertexAttrib3fv(Z.location,de);break;case 4:e.vertexAttrib4fv(Z.location,de);break;default:e.vertexAttrib1fv(Z.location,de)}}}}x()}function I(){U();for(let T in i){let P=i[T];for(let z in P){let q=P[z];for(let K in q)h(q[K].object),delete q[K];delete P[z]}delete i[T]}}function w(T){if(i[T.id]===void 0)return;let P=i[T.id];for(let z in P){let q=P[z];for(let K in q)h(q[K].object),delete q[K];delete P[z]}delete i[T.id]}function R(T){for(let P in i){let z=i[P];if(z[T.id]===void 0)continue;let q=z[T.id];for(let K in q)h(q[K].object),delete q[K];delete z[T.id]}}function U(){M(),s=!0,n!==a&&(n=a,u(n.object))}function M(){a.geometry=null,a.program=null,a.wireframe=!1}return{setup:o,reset:U,resetDefaultState:M,dispose:I,releaseStatesOfGeometry:w,releaseStatesOfProgram:R,initAttributes:g,enableAttribute:f,disableUnusedAttributes:x}}function Kf(e,t,r){let i;function a(u){i=u}function n(u,h){e.drawArrays(i,u,h),r.update(h,i,1)}function s(u,h,c){c!==0&&(e.drawArraysInstanced(i,u,h,c),r.update(h,i,c))}function o(u,h,c){if(c===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i,u,0,h,0,c);let d=0;for(let m=0;m<c;m++)d+=h[m];r.update(d,i,1)}function l(u,h,c,d){if(c===0)return;let m=t.get("WEBGL_multi_draw");if(m===null)for(let _=0;_<u.length;_++)s(u[_],h[_],d[_]);else{m.multiDrawArraysInstancedWEBGL(i,u,0,h,0,d,0,c);let _=0;for(let g=0;g<c;g++)_+=h[g]*d[g];r.update(_,i,1)}}this.setMode=a,this.render=n,this.renderInstances=s,this.renderMultiDraw=o,this.renderMultiDrawInstances=l}function Zf(e,t,r,i){let a;function n(){if(a!==void 0)return a;if(t.has("EXT_texture_filter_anisotropic")===!0){let R=t.get("EXT_texture_filter_anisotropic");a=e.getParameter(R.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else a=0;return a}function s(R){return!(R!==kt&&i.convert(R)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(R){let U=R===Zi&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(R!==dr&&i.convert(R)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_TYPE)&&R!==Yt&&!U)}function l(R){if(R==="highp"){if(e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).precision>0)return"highp";R="mediump"}return R==="mediump"&&e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let u=r.precision!==void 0?r.precision:"highp",h=l(u);h!==u&&(console.warn("THREE.WebGLRenderer:",u,"not supported, using",h,"instead."),u=h);let c=r.logarithmicDepthBuffer===!0,d=r.reverseDepthBuffer===!0&&t.has("EXT_clip_control"),m=e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),_=e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS),g=e.getParameter(e.MAX_TEXTURE_SIZE),f=e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE),p=e.getParameter(e.MAX_VERTEX_ATTRIBS),x=e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS),v=e.getParameter(e.MAX_VARYING_VECTORS),E=e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS),I=_>0,w=e.getParameter(e.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:n,getMaxPrecision:l,textureFormatReadable:s,textureTypeReadable:o,precision:u,logarithmicDepthBuffer:c,reverseDepthBuffer:d,maxTextures:m,maxVertexTextures:_,maxTextureSize:g,maxCubemapSize:f,maxAttributes:p,maxVertexUniforms:x,maxVaryings:v,maxFragmentUniforms:E,vertexTextures:I,maxSamples:w}}function $f(e){let t=this,r=null,i=0,a=!1,n=!1,s=new qr,o=new Ve,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(c,d){let m=c.length!==0||d||i!==0||a;return a=d,i=c.length,m},this.beginShadows=function(){n=!0,h(null)},this.endShadows=function(){n=!1},this.setGlobalState=function(c,d){r=h(c,d,0)},this.setState=function(c,d,m){let _=c.clippingPlanes,g=c.clipIntersection,f=c.clipShadows,p=e.get(c);if(!a||_===null||_.length===0||n&&!f)n?h(null):u();else{let x=n?0:i,v=x*4,E=p.clippingState||null;l.value=E,E=h(_,d,v,m);for(let I=0;I!==v;++I)E[I]=r[I];p.clippingState=E,this.numIntersection=g?this.numPlanes:0,this.numPlanes+=x}};function u(){l.value!==r&&(l.value=r,l.needsUpdate=i>0),t.numPlanes=i,t.numIntersection=0}function h(c,d,m,_){let g=c!==null?c.length:0,f=null;if(g!==0){if(f=l.value,_!==!0||f===null){let p=m+g*4,x=d.matrixWorldInverse;o.getNormalMatrix(x),(f===null||f.length<p)&&(f=new Float32Array(p));for(let v=0,E=m;v!==g;++v,E+=4)s.copy(c[v]).applyMatrix4(x,o),s.normal.toArray(f,E),f[E+3]=s.constant}l.value=f,l.needsUpdate=!0}return t.numPlanes=g,t.numIntersection=0,f}}function Jf(e){let t=new WeakMap;function r(s,o){return o===Ea?s.mapping=si:o===Hn&&(s.mapping=oi),s}function i(s){if(s&&s.isTexture){let o=s.mapping;if(o===Ea||o===Hn)if(t.has(s)){let l=t.get(s).texture;return r(l,s.mapping)}else{let l=s.image;if(l&&l.height>0){let u=new ld(l.height);return u.fromEquirectangularTexture(e,s),t.set(s,u),s.addEventListener("dispose",a),r(u.texture,s.mapping)}else return null}}return s}function a(s){let o=s.target;o.removeEventListener("dispose",a);let l=t.get(o);l!==void 0&&(t.delete(o),l.dispose())}function n(){t=new WeakMap}return{get:i,dispose:n}}var tn=class extends Rl{constructor(e=-1,t=1,r=1,i=-1,a=.1,n=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=r,this.bottom=i,this.near=a,this.far=n,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,r,i,a,n){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=r,this.view.offsetY=i,this.view.width=a,this.view.height=n,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),r=(this.right+this.left)/2,i=(this.top+this.bottom)/2,a=r-e,n=r+e,s=i+t,o=i-t;if(this.view!==null&&this.view.enabled){let l=(this.right-this.left)/this.view.fullWidth/this.zoom,u=(this.top-this.bottom)/this.view.fullHeight/this.zoom;a+=l*this.view.offsetX,n=a+l*this.view.width,s-=u*this.view.offsetY,o=s-u*this.view.height}this.projectionMatrix.makeOrthographic(a,n,s,o,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},Li=4,Dl=[.125,.215,.35,.446,.526,.582],$r=20,Ys=new tn,Ul=new Ne,qs=null,Ks=0,Zs=0,$s=!1,Jr=(1+Math.sqrt(5))/2,Pi=1/Jr,Nl=[new L(-Jr,Pi,0),new L(Jr,Pi,0),new L(-Pi,0,Jr),new L(Pi,0,Jr),new L(0,Jr,-Pi),new L(0,Jr,Pi),new L(-1,1,-1),new L(1,1,-1),new L(-1,1,1),new L(1,1,1)],Ol=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,r=.1,i=100){qs=this._renderer.getRenderTarget(),Ks=this._renderer.getActiveCubeFace(),Zs=this._renderer.getActiveMipmapLevel(),$s=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);let a=this._allocateTargets();return a.depthBuffer=!0,this._sceneToCubeUV(e,r,i,a),t>0&&this._blur(a,0,0,t),this._applyPMREM(a),this._cleanup(a),a}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=zl(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Bl(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(qs,Ks,Zs),this._renderer.xr.enabled=$s,e.scissorTest=!1,rn(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===si||e.mapping===oi?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),qs=this._renderer.getRenderTarget(),Ks=this._renderer.getActiveCubeFace(),Zs=this._renderer.getActiveMipmapLevel(),$s=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let r=t||this._allocateTargets();return this._textureToCubeUV(e,r),this._applyPMREM(r),this._cleanup(r),r}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,r={magFilter:_t,minFilter:_t,generateMipmaps:!1,type:Zi,format:kt,colorSpace:At,depthBuffer:!1},i=Fl(e,t,r);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Fl(e,t,r);let{_lodMax:a}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Qf(a)),this._blurMaterial=em(a,e,t)}return i}_compileMaterial(e){let t=new ut(this._lodPlanes[0],e);this._renderer.compile(t,Ys)}_sceneToCubeUV(e,t,r,i){let a=new Lt(90,1,t,r),n=[1,-1,1,1,1,1],s=[1,1,1,-1,-1,-1],o=this._renderer,l=o.autoClear,u=o.toneMapping;o.getClearColor(Ul),o.toneMapping=wr,o.autoClear=!1;let h=new Vt({name:"PMREM.Background",side:It,depthWrite:!1,depthTest:!1}),c=new ut(new Ja,h),d=!1,m=e.background;m?m.isColor&&(h.color.copy(m),e.background=null,d=!0):(h.color.copy(Ul),d=!0);for(let _=0;_<6;_++){let g=_%3;g===0?(a.up.set(0,n[_],0),a.lookAt(s[_],0,0)):g===1?(a.up.set(0,0,n[_]),a.lookAt(0,s[_],0)):(a.up.set(0,n[_],0),a.lookAt(0,0,s[_]));let f=this._cubeSize;rn(i,g*f,_>2?f:0,f,f),o.setRenderTarget(i),d&&o.render(c,a),o.render(e,a)}c.geometry.dispose(),c.material.dispose(),o.toneMapping=u,o.autoClear=l,e.background=m}_textureToCubeUV(e,t){let r=this._renderer,i=e.mapping===si||e.mapping===oi;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=zl()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Bl());let a=i?this._cubemapMaterial:this._equirectMaterial,n=new ut(this._lodPlanes[0],a),s=a.uniforms;s.envMap.value=e;let o=this._cubeSize;rn(t,0,0,3*o,2*o),r.setRenderTarget(t),r.render(n,Ys)}_applyPMREM(e){let t=this._renderer,r=t.autoClear;t.autoClear=!1;let i=this._lodPlanes.length;for(let a=1;a<i;a++){let n=Math.sqrt(this._sigmas[a]*this._sigmas[a]-this._sigmas[a-1]*this._sigmas[a-1]),s=Nl[(i-a-1)%Nl.length];this._blur(e,a-1,a,n,s)}t.autoClear=r}_blur(e,t,r,i,a){let n=this._pingPongRenderTarget;this._halfBlur(e,n,t,r,i,"latitudinal",a),this._halfBlur(n,e,r,r,i,"longitudinal",a)}_halfBlur(e,t,r,i,a,n,s){let o=this._renderer,l=this._blurMaterial;n!=="latitudinal"&&n!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let u=3,h=new ut(this._lodPlanes[i],l),c=l.uniforms,d=this._sizeLods[r]-1,m=isFinite(a)?Math.PI/(2*d):2*Math.PI/(2*$r-1),_=a/m,g=isFinite(a)?1+Math.floor(u*_):$r;g>$r&&console.warn(`sigmaRadians, ${a}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${$r}`);let f=[],p=0;for(let w=0;w<$r;++w){let R=w/_,U=Math.exp(-R*R/2);f.push(U),w===0?p+=U:w<g&&(p+=2*U)}for(let w=0;w<f.length;w++)f[w]=f[w]/p;c.envMap.value=e.texture,c.samples.value=g,c.weights.value=f,c.latitudinal.value=n==="latitudinal",s&&(c.poleAxis.value=s);let{_lodMax:x}=this;c.dTheta.value=m,c.mipInt.value=x-r;let v=this._sizeLods[i],E=3*v*(i>x-Li?i-x+Li:0),I=4*(this._cubeSize-v);rn(t,E,I,3*v,2*v),o.setRenderTarget(t),o.render(h,Ys)}};function Qf(e){let t=[],r=[],i=[],a=e,n=e-Li+1+Dl.length;for(let s=0;s<n;s++){let o=Math.pow(2,a);r.push(o);let l=1/o;s>e-Li?l=Dl[s-e+Li-1]:s===0&&(l=0),i.push(l);let u=1/(o-2),h=-u,c=1+u,d=[h,h,c,h,c,c,h,h,c,c,h,c],m=6,_=6,g=3,f=2,p=1,x=new Float32Array(g*_*m),v=new Float32Array(f*_*m),E=new Float32Array(p*_*m);for(let w=0;w<m;w++){let R=w%3*2/3-1,U=w>2?0:-1,M=[R,U,0,R+2/3,U,0,R+2/3,U+1,0,R,U,0,R+2/3,U+1,0,R,U+1,0];x.set(M,g*_*w),v.set(d,f*_*w);let T=[w,w,w,w,w,w];E.set(T,p*_*w)}let I=new Rt;I.setAttribute("position",new vt(x,g)),I.setAttribute("uv",new vt(v,f)),I.setAttribute("faceIndex",new vt(E,p)),t.push(I),a>Li&&a--}return{lodPlanes:t,sizeLods:r,sigmas:i}}function Fl(e,t,r){let i=new Wr(e,t,r);return i.texture.mapping=ba,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function rn(e,t,r,i,a){e.viewport.set(t,r,i,a),e.scissor.set(t,r,i,a)}function em(e,t,r){let i=new Float32Array($r),a=new L(0,1,0);return new Or({name:"SphericalGaussianBlur",defines:{n:$r,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/r,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:a}},vertexShader:Js(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:br,depthTest:!1,depthWrite:!1})}function Bl(){return new Or({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Js(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:br,depthTest:!1,depthWrite:!1})}function zl(){return new Or({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Js(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:br,depthTest:!1,depthWrite:!1})}function Js(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function tm(e){let t=new WeakMap,r=null;function i(o){if(o&&o.isTexture){let l=o.mapping,u=l===Ea||l===Hn,h=l===si||l===oi;if(u||h){let c=t.get(o),d=c!==void 0?c.texture.pmremVersion:0;if(o.isRenderTargetTexture&&o.pmremVersion!==d)return r===null&&(r=new Ol(e)),c=u?r.fromEquirectangular(o,c):r.fromCubemap(o,c),c.texture.pmremVersion=o.pmremVersion,t.set(o,c),c.texture;if(c!==void 0)return c.texture;{let m=o.image;return u&&m&&m.height>0||h&&m&&a(m)?(r===null&&(r=new Ol(e)),c=u?r.fromEquirectangular(o):r.fromCubemap(o),c.texture.pmremVersion=o.pmremVersion,t.set(o,c),o.addEventListener("dispose",n),c.texture):null}}}return o}function a(o){let l=0,u=6;for(let h=0;h<u;h++)o[h]!==void 0&&l++;return l===u}function n(o){let l=o.target;l.removeEventListener("dispose",n);let u=t.get(l);u!==void 0&&(t.delete(l),u.dispose())}function s(){t=new WeakMap,r!==null&&(r.dispose(),r=null)}return{get:i,dispose:s}}function rm(e){let t={};function r(i){if(t[i]!==void 0)return t[i];let a;switch(i){case"WEBGL_depth_texture":a=e.getExtension("WEBGL_depth_texture")||e.getExtension("MOZ_WEBGL_depth_texture")||e.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":a=e.getExtension("EXT_texture_filter_anisotropic")||e.getExtension("MOZ_EXT_texture_filter_anisotropic")||e.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":a=e.getExtension("WEBGL_compressed_texture_s3tc")||e.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||e.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":a=e.getExtension("WEBGL_compressed_texture_pvrtc")||e.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:a=e.getExtension(i)}return t[i]=a,a}return{has:function(i){return r(i)!==null},init:function(){r("EXT_color_buffer_float"),r("WEBGL_clip_cull_distance"),r("OES_texture_float_linear"),r("EXT_color_buffer_half_float"),r("WEBGL_multisampled_render_to_texture"),r("WEBGL_render_shared_exponent")},get:function(i){let a=r(i);return a===null&&ra("THREE.WebGLRenderer: "+i+" extension not supported."),a}}}function im(e,t,r,i){let a={},n=new WeakMap;function s(c){let d=c.target;d.index!==null&&t.remove(d.index);for(let _ in d.attributes)t.remove(d.attributes[_]);for(let _ in d.morphAttributes){let g=d.morphAttributes[_];for(let f=0,p=g.length;f<p;f++)t.remove(g[f])}d.removeEventListener("dispose",s),delete a[d.id];let m=n.get(d);m&&(t.remove(m),n.delete(d)),i.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,r.memory.geometries--}function o(c,d){return a[d.id]===!0||(d.addEventListener("dispose",s),a[d.id]=!0,r.memory.geometries++),d}function l(c){let d=c.attributes;for(let _ in d)t.update(d[_],e.ARRAY_BUFFER);let m=c.morphAttributes;for(let _ in m){let g=m[_];for(let f=0,p=g.length;f<p;f++)t.update(g[f],e.ARRAY_BUFFER)}}function u(c){let d=[],m=c.index,_=c.attributes.position,g=0;if(m!==null){let x=m.array;g=m.version;for(let v=0,E=x.length;v<E;v+=3){let I=x[v+0],w=x[v+1],R=x[v+2];d.push(I,w,w,R,R,I)}}else if(_!==void 0){let x=_.array;g=_.version;for(let v=0,E=x.length/3-1;v<E;v+=3){let I=v+0,w=v+1,R=v+2;d.push(I,w,w,R,R,I)}}else return;let f=new(rl(d)?Tl:Sl)(d,1);f.version=g;let p=n.get(c);p&&t.remove(p),n.set(c,f)}function h(c){let d=n.get(c);if(d){let m=c.index;m!==null&&d.version<m.version&&u(c)}else u(c);return n.get(c)}return{get:o,update:l,getWireframeAttribute:h}}function am(e,t,r){let i;function a(d){i=d}let n,s;function o(d){n=d.type,s=d.bytesPerElement}function l(d,m){e.drawElements(i,m,n,d*s),r.update(m,i,1)}function u(d,m,_){_!==0&&(e.drawElementsInstanced(i,m,n,d*s,_),r.update(m,i,_))}function h(d,m,_){if(_===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i,m,0,n,d,0,_);let g=0;for(let f=0;f<_;f++)g+=m[f];r.update(g,i,1)}function c(d,m,_,g){if(_===0)return;let f=t.get("WEBGL_multi_draw");if(f===null)for(let p=0;p<d.length;p++)u(d[p]/s,m[p],g[p]);else{f.multiDrawElementsInstancedWEBGL(i,m,0,n,d,0,g,0,_);let p=0;for(let x=0;x<_;x++)p+=m[x]*g[x];r.update(p,i,1)}}this.setMode=a,this.setIndex=o,this.render=l,this.renderInstances=u,this.renderMultiDraw=h,this.renderMultiDrawInstances=c}function nm(e){let t={geometries:0,textures:0},r={frame:0,calls:0,triangles:0,points:0,lines:0};function i(n,s,o){switch(r.calls++,s){case e.TRIANGLES:r.triangles+=o*(n/3);break;case e.LINES:r.lines+=o*(n/2);break;case e.LINE_STRIP:r.lines+=o*(n-1);break;case e.LINE_LOOP:r.lines+=o*n;break;case e.POINTS:r.points+=o*n;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",s);break}}function a(){r.calls=0,r.triangles=0,r.points=0,r.lines=0}return{memory:t,render:r,programs:null,autoReset:!0,reset:a,update:i}}function sm(e,t,r){let i=new WeakMap,a=new tt;function n(s,o,l){let u=s.morphTargetInfluences,h=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,c=h!==void 0?h.length:0,d=i.get(o);if(d===void 0||d.count!==c){let m=function(){U.dispose(),i.delete(o),o.removeEventListener("dispose",m)};d!==void 0&&d.texture.dispose();let _=o.morphAttributes.position!==void 0,g=o.morphAttributes.normal!==void 0,f=o.morphAttributes.color!==void 0,p=o.morphAttributes.position||[],x=o.morphAttributes.normal||[],v=o.morphAttributes.color||[],E=0;_===!0&&(E=1),g===!0&&(E=2),f===!0&&(E=3);let I=o.attributes.position.count*E,w=1;I>t.maxTextureSize&&(w=Math.ceil(I/t.maxTextureSize),I=t.maxTextureSize);let R=new Float32Array(I*w*4*c),U=new hl(R,I,w,c);U.type=Yt,U.needsUpdate=!0;let M=E*4;for(let T=0;T<c;T++){let P=p[T],z=x[T],q=v[T],K=I*w*4*T;for(let Y=0;Y<P.count;Y++){let W=Y*M;_===!0&&(a.fromBufferAttribute(P,Y),R[K+W+0]=a.x,R[K+W+1]=a.y,R[K+W+2]=a.z,R[K+W+3]=0),g===!0&&(a.fromBufferAttribute(z,Y),R[K+W+4]=a.x,R[K+W+5]=a.y,R[K+W+6]=a.z,R[K+W+7]=0),f===!0&&(a.fromBufferAttribute(q,Y),R[K+W+8]=a.x,R[K+W+9]=a.y,R[K+W+10]=a.z,R[K+W+11]=q.itemSize===4?a.w:1)}}d={count:c,texture:U,size:new Fe(I,w)},i.set(o,d),o.addEventListener("dispose",m)}if(s.isInstancedMesh===!0&&s.morphTexture!==null)l.getUniforms().setValue(e,"morphTexture",s.morphTexture,r);else{let m=0;for(let g=0;g<u.length;g++)m+=u[g];let _=o.morphTargetsRelative?1:1-m;l.getUniforms().setValue(e,"morphTargetBaseInfluence",_),l.getUniforms().setValue(e,"morphTargetInfluences",u)}l.getUniforms().setValue(e,"morphTargetsTexture",d.texture,r),l.getUniforms().setValue(e,"morphTargetsTextureSize",d.size)}return{update:n}}function om(e,t,r,i){let a=new WeakMap;function n(l){let u=i.render.frame,h=l.geometry,c=t.get(l,h);if(a.get(c)!==u&&(t.update(c),a.set(c,u)),l.isInstancedMesh&&(l.hasEventListener("dispose",o)===!1&&l.addEventListener("dispose",o),a.get(l)!==u&&(r.update(l.instanceMatrix,e.ARRAY_BUFFER),l.instanceColor!==null&&r.update(l.instanceColor,e.ARRAY_BUFFER),a.set(l,u))),l.isSkinnedMesh){let d=l.skeleton;a.get(d)!==u&&(d.update(),a.set(d,u))}return c}function s(){a=new WeakMap}function o(l){let u=l.target;u.removeEventListener("dispose",o),r.remove(u.instanceMatrix),u.instanceColor!==null&&r.remove(u.instanceColor)}return{update:n,dispose:s}}var Hl=class extends Et{constructor(e,t,r,i,a,n,s,o,l,u=hi){if(u!==hi&&u!==ci)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");r===void 0&&u===hi&&(r=Gr),r===void 0&&u===ci&&(r=ui),super(null,i,a,n,s,o,u,r,l),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=s!==void 0?s:wt,this.minFilter=o!==void 0?o:wt,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}},kl=new Et,Vl=new Hl(1,1),Gl=new hl,Wl=new jc,Xl=new Pl,jl=[],Yl=[],ql=new Float32Array(16),Kl=new Float32Array(9),Zl=new Float32Array(4);function Ii(e,t,r){let i=e[0];if(i<=0||i>0)return e;let a=t*r,n=jl[a];if(n===void 0&&(n=new Float32Array(a),jl[a]=n),t!==0){i.toArray(n,0);for(let s=1,o=0;s!==t;++s)o+=r,e[s].toArray(n,o)}return n}function xt(e,t){if(e.length!==t.length)return!1;for(let r=0,i=e.length;r<i;r++)if(e[r]!==t[r])return!1;return!0}function yt(e,t){for(let r=0,i=t.length;r<i;r++)e[r]=t[r]}function an(e,t){let r=Yl[t];r===void 0&&(r=new Int32Array(t),Yl[t]=r);for(let i=0;i!==t;++i)r[i]=e.allocateTextureUnit();return r}function lm(e,t){let r=this.cache;r[0]!==t&&(e.uniform1f(this.addr,t),r[0]=t)}function um(e,t){let r=this.cache;if(t.x!==void 0)(r[0]!==t.x||r[1]!==t.y)&&(e.uniform2f(this.addr,t.x,t.y),r[0]=t.x,r[1]=t.y);else{if(xt(r,t))return;e.uniform2fv(this.addr,t),yt(r,t)}}function hm(e,t){let r=this.cache;if(t.x!==void 0)(r[0]!==t.x||r[1]!==t.y||r[2]!==t.z)&&(e.uniform3f(this.addr,t.x,t.y,t.z),r[0]=t.x,r[1]=t.y,r[2]=t.z);else if(t.r!==void 0)(r[0]!==t.r||r[1]!==t.g||r[2]!==t.b)&&(e.uniform3f(this.addr,t.r,t.g,t.b),r[0]=t.r,r[1]=t.g,r[2]=t.b);else{if(xt(r,t))return;e.uniform3fv(this.addr,t),yt(r,t)}}function cm(e,t){let r=this.cache;if(t.x!==void 0)(r[0]!==t.x||r[1]!==t.y||r[2]!==t.z||r[3]!==t.w)&&(e.uniform4f(this.addr,t.x,t.y,t.z,t.w),r[0]=t.x,r[1]=t.y,r[2]=t.z,r[3]=t.w);else{if(xt(r,t))return;e.uniform4fv(this.addr,t),yt(r,t)}}function dm(e,t){let r=this.cache,i=t.elements;if(i===void 0){if(xt(r,t))return;e.uniformMatrix2fv(this.addr,!1,t),yt(r,t)}else{if(xt(r,i))return;Zl.set(i),e.uniformMatrix2fv(this.addr,!1,Zl),yt(r,i)}}function pm(e,t){let r=this.cache,i=t.elements;if(i===void 0){if(xt(r,t))return;e.uniformMatrix3fv(this.addr,!1,t),yt(r,t)}else{if(xt(r,i))return;Kl.set(i),e.uniformMatrix3fv(this.addr,!1,Kl),yt(r,i)}}function fm(e,t){let r=this.cache,i=t.elements;if(i===void 0){if(xt(r,t))return;e.uniformMatrix4fv(this.addr,!1,t),yt(r,t)}else{if(xt(r,i))return;ql.set(i),e.uniformMatrix4fv(this.addr,!1,ql),yt(r,i)}}function mm(e,t){let r=this.cache;r[0]!==t&&(e.uniform1i(this.addr,t),r[0]=t)}function gm(e,t){let r=this.cache;if(t.x!==void 0)(r[0]!==t.x||r[1]!==t.y)&&(e.uniform2i(this.addr,t.x,t.y),r[0]=t.x,r[1]=t.y);else{if(xt(r,t))return;e.uniform2iv(this.addr,t),yt(r,t)}}function _m(e,t){let r=this.cache;if(t.x!==void 0)(r[0]!==t.x||r[1]!==t.y||r[2]!==t.z)&&(e.uniform3i(this.addr,t.x,t.y,t.z),r[0]=t.x,r[1]=t.y,r[2]=t.z);else{if(xt(r,t))return;e.uniform3iv(this.addr,t),yt(r,t)}}function vm(e,t){let r=this.cache;if(t.x!==void 0)(r[0]!==t.x||r[1]!==t.y||r[2]!==t.z||r[3]!==t.w)&&(e.uniform4i(this.addr,t.x,t.y,t.z,t.w),r[0]=t.x,r[1]=t.y,r[2]=t.z,r[3]=t.w);else{if(xt(r,t))return;e.uniform4iv(this.addr,t),yt(r,t)}}function xm(e,t){let r=this.cache;r[0]!==t&&(e.uniform1ui(this.addr,t),r[0]=t)}function ym(e,t){let r=this.cache;if(t.x!==void 0)(r[0]!==t.x||r[1]!==t.y)&&(e.uniform2ui(this.addr,t.x,t.y),r[0]=t.x,r[1]=t.y);else{if(xt(r,t))return;e.uniform2uiv(this.addr,t),yt(r,t)}}function Mm(e,t){let r=this.cache;if(t.x!==void 0)(r[0]!==t.x||r[1]!==t.y||r[2]!==t.z)&&(e.uniform3ui(this.addr,t.x,t.y,t.z),r[0]=t.x,r[1]=t.y,r[2]=t.z);else{if(xt(r,t))return;e.uniform3uiv(this.addr,t),yt(r,t)}}function Sm(e,t){let r=this.cache;if(t.x!==void 0)(r[0]!==t.x||r[1]!==t.y||r[2]!==t.z||r[3]!==t.w)&&(e.uniform4ui(this.addr,t.x,t.y,t.z,t.w),r[0]=t.x,r[1]=t.y,r[2]=t.z,r[3]=t.w);else{if(xt(r,t))return;e.uniform4uiv(this.addr,t),yt(r,t)}}function Tm(e,t,r){let i=this.cache,a=r.allocateTextureUnit();i[0]!==a&&(e.uniform1i(this.addr,a),i[0]=a);let n;this.type===e.SAMPLER_2D_SHADOW?(Vl.compareFunction=Qo,n=Vl):n=kl,r.setTexture2D(t||n,a)}function Em(e,t,r){let i=this.cache,a=r.allocateTextureUnit();i[0]!==a&&(e.uniform1i(this.addr,a),i[0]=a),r.setTexture3D(t||Wl,a)}function bm(e,t,r){let i=this.cache,a=r.allocateTextureUnit();i[0]!==a&&(e.uniform1i(this.addr,a),i[0]=a),r.setTextureCube(t||Xl,a)}function wm(e,t,r){let i=this.cache,a=r.allocateTextureUnit();i[0]!==a&&(e.uniform1i(this.addr,a),i[0]=a),r.setTexture2DArray(t||Gl,a)}function Am(e){switch(e){case 5126:return lm;case 35664:return um;case 35665:return hm;case 35666:return cm;case 35674:return dm;case 35675:return pm;case 35676:return fm;case 5124:case 35670:return mm;case 35667:case 35671:return gm;case 35668:case 35672:return _m;case 35669:case 35673:return vm;case 5125:return xm;case 36294:return ym;case 36295:return Mm;case 36296:return Sm;case 35678:case 36198:case 36298:case 36306:case 35682:return Tm;case 35679:case 36299:case 36307:return Em;case 35680:case 36300:case 36308:case 36293:return bm;case 36289:case 36303:case 36311:case 36292:return wm}}function Rm(e,t){e.uniform1fv(this.addr,t)}function Cm(e,t){let r=Ii(t,this.size,2);e.uniform2fv(this.addr,r)}function Lm(e,t){let r=Ii(t,this.size,3);e.uniform3fv(this.addr,r)}function Pm(e,t){let r=Ii(t,this.size,4);e.uniform4fv(this.addr,r)}function Im(e,t){let r=Ii(t,this.size,4);e.uniformMatrix2fv(this.addr,!1,r)}function Dm(e,t){let r=Ii(t,this.size,9);e.uniformMatrix3fv(this.addr,!1,r)}function Um(e,t){let r=Ii(t,this.size,16);e.uniformMatrix4fv(this.addr,!1,r)}function Nm(e,t){e.uniform1iv(this.addr,t)}function Om(e,t){e.uniform2iv(this.addr,t)}function Fm(e,t){e.uniform3iv(this.addr,t)}function Bm(e,t){e.uniform4iv(this.addr,t)}function zm(e,t){e.uniform1uiv(this.addr,t)}function Hm(e,t){e.uniform2uiv(this.addr,t)}function km(e,t){e.uniform3uiv(this.addr,t)}function Vm(e,t){e.uniform4uiv(this.addr,t)}function Gm(e,t,r){let i=this.cache,a=t.length,n=an(r,a);xt(i,n)||(e.uniform1iv(this.addr,n),yt(i,n));for(let s=0;s!==a;++s)r.setTexture2D(t[s]||kl,n[s])}function Wm(e,t,r){let i=this.cache,a=t.length,n=an(r,a);xt(i,n)||(e.uniform1iv(this.addr,n),yt(i,n));for(let s=0;s!==a;++s)r.setTexture3D(t[s]||Wl,n[s])}function Xm(e,t,r){let i=this.cache,a=t.length,n=an(r,a);xt(i,n)||(e.uniform1iv(this.addr,n),yt(i,n));for(let s=0;s!==a;++s)r.setTextureCube(t[s]||Xl,n[s])}function jm(e,t,r){let i=this.cache,a=t.length,n=an(r,a);xt(i,n)||(e.uniform1iv(this.addr,n),yt(i,n));for(let s=0;s!==a;++s)r.setTexture2DArray(t[s]||Gl,n[s])}function Ym(e){switch(e){case 5126:return Rm;case 35664:return Cm;case 35665:return Lm;case 35666:return Pm;case 35674:return Im;case 35675:return Dm;case 35676:return Um;case 5124:case 35670:return Nm;case 35667:case 35671:return Om;case 35668:case 35672:return Fm;case 35669:case 35673:return Bm;case 5125:return zm;case 36294:return Hm;case 36295:return km;case 36296:return Vm;case 35678:case 36198:case 36298:case 36306:case 35682:return Gm;case 35679:case 36299:case 36307:return Wm;case 35680:case 36300:case 36308:case 36293:return Xm;case 36289:case 36303:case 36311:case 36292:return jm}}var qm=class{constructor(e,t,r){this.id=e,this.addr=r,this.cache=[],this.type=t.type,this.setValue=Am(t.type)}},Km=class{constructor(e,t,r){this.id=e,this.addr=r,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Ym(t.type)}},Zm=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,r){let i=this.seq;for(let a=0,n=i.length;a!==n;++a){let s=i[a];s.setValue(e,t[s.id],r)}}},Qs=/(\w+)(\])?(\[|\.)?/g;function $l(e,t){e.seq.push(t),e.map[t.id]=t}function $m(e,t,r){let i=e.name,a=i.length;for(Qs.lastIndex=0;;){let n=Qs.exec(i),s=Qs.lastIndex,o=n[1],l=n[2]==="]",u=n[3];if(l&&(o=o|0),u===void 0||u==="["&&s+2===a){$l(r,u===void 0?new qm(o,e,t):new Km(o,e,t));break}else{let h=r.map[o];h===void 0&&(h=new Zm(o),$l(r,h)),r=h}}}var nn=class{constructor(e,t){this.seq=[],this.map={};let r=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let i=0;i<r;++i){let a=e.getActiveUniform(t,i),n=e.getUniformLocation(t,a.name);$m(a,n,this)}}setValue(e,t,r,i){let a=this.map[t];a!==void 0&&a.setValue(e,r,i)}setOptional(e,t,r){let i=t[r];i!==void 0&&this.setValue(e,r,i)}static upload(e,t,r,i){for(let a=0,n=t.length;a!==n;++a){let s=t[a],o=r[s.id];o.needsUpdate!==!1&&s.setValue(e,o.value,i)}}static seqWithValue(e,t){let r=[];for(let i=0,a=e.length;i!==a;++i){let n=e[i];n.id in t&&r.push(n)}return r}};function Jl(e,t,r){let i=e.createShader(t);return e.shaderSource(i,r),e.compileShader(i),i}var Jm=37297,Qm=0;function eg(e,t){let r=e.split(`
`),i=[],a=Math.max(t-6,0),n=Math.min(t+6,r.length);for(let s=a;s<n;s++){let o=s+1;i.push(`${o===t?">":" "} ${o}: ${r[s]}`)}return i.join(`
`)}var Ql=new Ve;function tg(e){Ye._getMatrix(Ql,Ye.workingColorSpace,e);let t=`mat3( ${Ql.elements.map(r=>r.toFixed(4))} )`;switch(Ye.getTransfer(e)){case Da:return[t,"LinearTransferOETF"];case it:return[t,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",e),[t,"LinearTransferOETF"]}}function eu(e,t,r){let i=e.getShaderParameter(t,e.COMPILE_STATUS),a=e.getShaderInfoLog(t).trim();if(i&&a==="")return"";let n=/ERROR: 0:(\d+)/.exec(a);if(n){let s=parseInt(n[1]);return r.toUpperCase()+`

`+a+`

`+eg(e.getShaderSource(t),s)}else return a}function rg(e,t){let r=tg(t);return[`vec4 ${e}( vec4 value ) {`,`	return ${r[1]}( vec4( value.rgb * ${r[0]}, value.a ) );`,"}"].join(`
`)}function ig(e,t){let r;switch(t){case ic:r="Linear";break;case ac:r="Reinhard";break;case nc:r="Cineon";break;case Uo:r="ACESFilmic";break;case oc:r="AgX";break;case lc:r="Neutral";break;case sc:r="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),r="Linear"}return"vec3 "+e+"( vec3 color ) { return "+r+"ToneMapping( color ); }"}var sn=new L;function ag(){Ye.getLuminanceCoefficients(sn);let e=sn.x.toFixed(4),t=sn.y.toFixed(4),r=sn.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${e}, ${t}, ${r} );`,"	return dot( weights, rgb );","}"].join(`
`)}function ng(e){return[e.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",e.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(oa).join(`
`)}function sg(e){let t=[];for(let r in e){let i=e[r];i!==!1&&t.push("#define "+r+" "+i)}return t.join(`
`)}function og(e,t){let r={},i=e.getProgramParameter(t,e.ACTIVE_ATTRIBUTES);for(let a=0;a<i;a++){let n=e.getActiveAttrib(t,a),s=n.name,o=1;n.type===e.FLOAT_MAT2&&(o=2),n.type===e.FLOAT_MAT3&&(o=3),n.type===e.FLOAT_MAT4&&(o=4),r[s]={type:n.type,location:e.getAttribLocation(t,s),locationSize:o}}return r}function oa(e){return e!==""}function tu(e,t){let r=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return e.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,r).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function ru(e,t){return e.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var lg=/^[ \t]*#include +<([\w\d./]+)>/gm;function eo(e){return e.replace(lg,hg)}var ug=new Map;function hg(e,t){let r=ke[t];if(r===void 0){let i=ug.get(t);if(i!==void 0)r=ke[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,i);else throw new Error("Can not resolve #include <"+t+">")}return eo(r)}var cg=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function iu(e){return e.replace(cg,dg)}function dg(e,t,r,i){let a="";for(let n=parseInt(t);n<parseInt(r);n++)a+=i.replace(/\[\s*i\s*\]/g,"[ "+n+" ]").replace(/UNROLLED_LOOP_INDEX/g,n);return a}function au(e){let t=`precision ${e.precision} float;
	precision ${e.precision} int;
	precision ${e.precision} sampler2D;
	precision ${e.precision} samplerCube;
	precision ${e.precision} sampler3D;
	precision ${e.precision} sampler2DArray;
	precision ${e.precision} sampler2DShadow;
	precision ${e.precision} samplerCubeShadow;
	precision ${e.precision} sampler2DArrayShadow;
	precision ${e.precision} isampler2D;
	precision ${e.precision} isampler3D;
	precision ${e.precision} isamplerCube;
	precision ${e.precision} isampler2DArray;
	precision ${e.precision} usampler2D;
	precision ${e.precision} usampler3D;
	precision ${e.precision} usamplerCube;
	precision ${e.precision} usampler2DArray;
	`;return e.precision==="highp"?t+=`
#define HIGH_PRECISION`:e.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:e.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function pg(e){let t="SHADOWMAP_TYPE_BASIC";return e.shadowMapType===Lo?t="SHADOWMAP_TYPE_PCF":e.shadowMapType===Oh?t="SHADOWMAP_TYPE_PCF_SOFT":e.shadowMapType===ur&&(t="SHADOWMAP_TYPE_VSM"),t}function fg(e){let t="ENVMAP_TYPE_CUBE";if(e.envMap)switch(e.envMapMode){case si:case oi:t="ENVMAP_TYPE_CUBE";break;case ba:t="ENVMAP_TYPE_CUBE_UV";break}return t}function mg(e){let t="ENVMAP_MODE_REFLECTION";return e.envMap&&e.envMapMode===oi&&(t="ENVMAP_MODE_REFRACTION"),t}function gg(e){let t="ENVMAP_BLENDING_NONE";if(e.envMap)switch(e.combine){case Do:t="ENVMAP_BLENDING_MULTIPLY";break;case tc:t="ENVMAP_BLENDING_MIX";break;case rc:t="ENVMAP_BLENDING_ADD";break}return t}function _g(e){let t=e.envMapCubeUVHeight;if(t===null)return null;let r=Math.log2(t)-2,i=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,r),112)),texelHeight:i,maxMip:r}}function vg(e,t,r,i){let a=e.getContext(),n=r.defines,s=r.vertexShader,o=r.fragmentShader,l=pg(r),u=fg(r),h=mg(r),c=gg(r),d=_g(r),m=ng(r),_=sg(n),g=a.createProgram(),f,p,x=r.glslVersion?"#version "+r.glslVersion+`
`:"";r.isRawShaderMaterial?(f=["#define SHADER_TYPE "+r.shaderType,"#define SHADER_NAME "+r.shaderName,_].filter(oa).join(`
`),f.length>0&&(f+=`
`),p=["#define SHADER_TYPE "+r.shaderType,"#define SHADER_NAME "+r.shaderName,_].filter(oa).join(`
`),p.length>0&&(p+=`
`)):(f=[au(r),"#define SHADER_TYPE "+r.shaderType,"#define SHADER_NAME "+r.shaderName,_,r.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",r.batching?"#define USE_BATCHING":"",r.batchingColor?"#define USE_BATCHING_COLOR":"",r.instancing?"#define USE_INSTANCING":"",r.instancingColor?"#define USE_INSTANCING_COLOR":"",r.instancingMorph?"#define USE_INSTANCING_MORPH":"",r.useFog&&r.fog?"#define USE_FOG":"",r.useFog&&r.fogExp2?"#define FOG_EXP2":"",r.map?"#define USE_MAP":"",r.envMap?"#define USE_ENVMAP":"",r.envMap?"#define "+h:"",r.lightMap?"#define USE_LIGHTMAP":"",r.aoMap?"#define USE_AOMAP":"",r.bumpMap?"#define USE_BUMPMAP":"",r.normalMap?"#define USE_NORMALMAP":"",r.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",r.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",r.displacementMap?"#define USE_DISPLACEMENTMAP":"",r.emissiveMap?"#define USE_EMISSIVEMAP":"",r.anisotropy?"#define USE_ANISOTROPY":"",r.anisotropyMap?"#define USE_ANISOTROPYMAP":"",r.clearcoatMap?"#define USE_CLEARCOATMAP":"",r.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",r.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",r.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",r.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",r.specularMap?"#define USE_SPECULARMAP":"",r.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",r.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",r.roughnessMap?"#define USE_ROUGHNESSMAP":"",r.metalnessMap?"#define USE_METALNESSMAP":"",r.alphaMap?"#define USE_ALPHAMAP":"",r.alphaHash?"#define USE_ALPHAHASH":"",r.transmission?"#define USE_TRANSMISSION":"",r.transmissionMap?"#define USE_TRANSMISSIONMAP":"",r.thicknessMap?"#define USE_THICKNESSMAP":"",r.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",r.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",r.mapUv?"#define MAP_UV "+r.mapUv:"",r.alphaMapUv?"#define ALPHAMAP_UV "+r.alphaMapUv:"",r.lightMapUv?"#define LIGHTMAP_UV "+r.lightMapUv:"",r.aoMapUv?"#define AOMAP_UV "+r.aoMapUv:"",r.emissiveMapUv?"#define EMISSIVEMAP_UV "+r.emissiveMapUv:"",r.bumpMapUv?"#define BUMPMAP_UV "+r.bumpMapUv:"",r.normalMapUv?"#define NORMALMAP_UV "+r.normalMapUv:"",r.displacementMapUv?"#define DISPLACEMENTMAP_UV "+r.displacementMapUv:"",r.metalnessMapUv?"#define METALNESSMAP_UV "+r.metalnessMapUv:"",r.roughnessMapUv?"#define ROUGHNESSMAP_UV "+r.roughnessMapUv:"",r.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+r.anisotropyMapUv:"",r.clearcoatMapUv?"#define CLEARCOATMAP_UV "+r.clearcoatMapUv:"",r.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+r.clearcoatNormalMapUv:"",r.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+r.clearcoatRoughnessMapUv:"",r.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+r.iridescenceMapUv:"",r.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+r.iridescenceThicknessMapUv:"",r.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+r.sheenColorMapUv:"",r.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+r.sheenRoughnessMapUv:"",r.specularMapUv?"#define SPECULARMAP_UV "+r.specularMapUv:"",r.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+r.specularColorMapUv:"",r.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+r.specularIntensityMapUv:"",r.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+r.transmissionMapUv:"",r.thicknessMapUv?"#define THICKNESSMAP_UV "+r.thicknessMapUv:"",r.vertexTangents&&r.flatShading===!1?"#define USE_TANGENT":"",r.vertexColors?"#define USE_COLOR":"",r.vertexAlphas?"#define USE_COLOR_ALPHA":"",r.vertexUv1s?"#define USE_UV1":"",r.vertexUv2s?"#define USE_UV2":"",r.vertexUv3s?"#define USE_UV3":"",r.pointsUvs?"#define USE_POINTS_UV":"",r.flatShading?"#define FLAT_SHADED":"",r.skinning?"#define USE_SKINNING":"",r.morphTargets?"#define USE_MORPHTARGETS":"",r.morphNormals&&r.flatShading===!1?"#define USE_MORPHNORMALS":"",r.morphColors?"#define USE_MORPHCOLORS":"",r.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+r.morphTextureStride:"",r.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+r.morphTargetsCount:"",r.doubleSided?"#define DOUBLE_SIDED":"",r.flipSided?"#define FLIP_SIDED":"",r.shadowMapEnabled?"#define USE_SHADOWMAP":"",r.shadowMapEnabled?"#define "+l:"",r.sizeAttenuation?"#define USE_SIZEATTENUATION":"",r.numLightProbes>0?"#define USE_LIGHT_PROBES":"",r.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",r.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(oa).join(`
`),p=[au(r),"#define SHADER_TYPE "+r.shaderType,"#define SHADER_NAME "+r.shaderName,_,r.useFog&&r.fog?"#define USE_FOG":"",r.useFog&&r.fogExp2?"#define FOG_EXP2":"",r.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",r.map?"#define USE_MAP":"",r.matcap?"#define USE_MATCAP":"",r.envMap?"#define USE_ENVMAP":"",r.envMap?"#define "+u:"",r.envMap?"#define "+h:"",r.envMap?"#define "+c:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",r.lightMap?"#define USE_LIGHTMAP":"",r.aoMap?"#define USE_AOMAP":"",r.bumpMap?"#define USE_BUMPMAP":"",r.normalMap?"#define USE_NORMALMAP":"",r.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",r.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",r.emissiveMap?"#define USE_EMISSIVEMAP":"",r.anisotropy?"#define USE_ANISOTROPY":"",r.anisotropyMap?"#define USE_ANISOTROPYMAP":"",r.clearcoat?"#define USE_CLEARCOAT":"",r.clearcoatMap?"#define USE_CLEARCOATMAP":"",r.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",r.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",r.dispersion?"#define USE_DISPERSION":"",r.iridescence?"#define USE_IRIDESCENCE":"",r.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",r.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",r.specularMap?"#define USE_SPECULARMAP":"",r.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",r.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",r.roughnessMap?"#define USE_ROUGHNESSMAP":"",r.metalnessMap?"#define USE_METALNESSMAP":"",r.alphaMap?"#define USE_ALPHAMAP":"",r.alphaTest?"#define USE_ALPHATEST":"",r.alphaHash?"#define USE_ALPHAHASH":"",r.sheen?"#define USE_SHEEN":"",r.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",r.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",r.transmission?"#define USE_TRANSMISSION":"",r.transmissionMap?"#define USE_TRANSMISSIONMAP":"",r.thicknessMap?"#define USE_THICKNESSMAP":"",r.vertexTangents&&r.flatShading===!1?"#define USE_TANGENT":"",r.vertexColors||r.instancingColor||r.batchingColor?"#define USE_COLOR":"",r.vertexAlphas?"#define USE_COLOR_ALPHA":"",r.vertexUv1s?"#define USE_UV1":"",r.vertexUv2s?"#define USE_UV2":"",r.vertexUv3s?"#define USE_UV3":"",r.pointsUvs?"#define USE_POINTS_UV":"",r.gradientMap?"#define USE_GRADIENTMAP":"",r.flatShading?"#define FLAT_SHADED":"",r.doubleSided?"#define DOUBLE_SIDED":"",r.flipSided?"#define FLIP_SIDED":"",r.shadowMapEnabled?"#define USE_SHADOWMAP":"",r.shadowMapEnabled?"#define "+l:"",r.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",r.numLightProbes>0?"#define USE_LIGHT_PROBES":"",r.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",r.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",r.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",r.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",r.toneMapping!==wr?"#define TONE_MAPPING":"",r.toneMapping!==wr?ke.tonemapping_pars_fragment:"",r.toneMapping!==wr?ig("toneMapping",r.toneMapping):"",r.dithering?"#define DITHERING":"",r.opaque?"#define OPAQUE":"",ke.colorspace_pars_fragment,rg("linearToOutputTexel",r.outputColorSpace),ag(),r.useDepthPacking?"#define DEPTH_PACKING "+r.depthPacking:"",`
`].filter(oa).join(`
`)),s=eo(s),s=tu(s,r),s=ru(s,r),o=eo(o),o=tu(o,r),o=ru(o,r),s=iu(s),o=iu(o),r.isRawShaderMaterial!==!0&&(x=`#version 300 es
`,f=[m,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+f,p=["#define varying in",r.glslVersion===el?"":"layout(location = 0) out highp vec4 pc_fragColor;",r.glslVersion===el?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);let v=x+f+s,E=x+p+o,I=Jl(a,a.VERTEX_SHADER,v),w=Jl(a,a.FRAGMENT_SHADER,E);a.attachShader(g,I),a.attachShader(g,w),r.index0AttributeName!==void 0?a.bindAttribLocation(g,0,r.index0AttributeName):r.morphTargets===!0&&a.bindAttribLocation(g,0,"position"),a.linkProgram(g);function R(P){if(e.debug.checkShaderErrors){let z=a.getProgramInfoLog(g).trim(),q=a.getShaderInfoLog(I).trim(),K=a.getShaderInfoLog(w).trim(),Y=!0,W=!0;if(a.getProgramParameter(g,a.LINK_STATUS)===!1)if(Y=!1,typeof e.debug.onShaderError=="function")e.debug.onShaderError(a,g,I,w);else{let ae=eu(a,I,"vertex"),Z=eu(a,w,"fragment");console.error("THREE.WebGLProgram: Shader Error "+a.getError()+" - VALIDATE_STATUS "+a.getProgramParameter(g,a.VALIDATE_STATUS)+`

Material Name: `+P.name+`
Material Type: `+P.type+`

Program Info Log: `+z+`
`+ae+`
`+Z)}else z!==""?console.warn("THREE.WebGLProgram: Program Info Log:",z):(q===""||K==="")&&(W=!1);W&&(P.diagnostics={runnable:Y,programLog:z,vertexShader:{log:q,prefix:f},fragmentShader:{log:K,prefix:p}})}a.deleteShader(I),a.deleteShader(w),U=new nn(a,g),M=og(a,g)}let U;this.getUniforms=function(){return U===void 0&&R(this),U};let M;this.getAttributes=function(){return M===void 0&&R(this),M};let T=r.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return T===!1&&(T=a.getProgramParameter(g,Jm)),T},this.destroy=function(){i.releaseStatesOfProgram(this),a.deleteProgram(g),this.program=void 0},this.type=r.shaderType,this.name=r.shaderName,this.id=Qm++,this.cacheKey=t,this.usedTimes=1,this.program=g,this.vertexShader=I,this.fragmentShader=w,this}var xg=0,yg=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){let t=e.vertexShader,r=e.fragmentShader,i=this._getShaderStage(t),a=this._getShaderStage(r),n=this._getShaderCacheForMaterial(e);return n.has(i)===!1&&(n.add(i),i.usedTimes++),n.has(a)===!1&&(n.add(a),a.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let r of t)r.usedTimes--,r.usedTimes===0&&this.shaderCache.delete(r.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,r=t.get(e);return r===void 0&&(r=new Set,t.set(e,r)),r}_getShaderStage(e){let t=this.shaderCache,r=t.get(e);return r===void 0&&(r=new Mg(e),t.set(e,r)),r}},Mg=class{constructor(e){this.id=xg++,this.code=e,this.usedTimes=0}};function Sg(e,t,r,i,a,n,s){let o=new fl,l=new yg,u=new Set,h=[],c=a.logarithmicDepthBuffer,d=a.vertexTextures,m=a.precision,_={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function g(M){return u.add(M),M===0?"uv":`uv${M}`}function f(M,T,P,z,q){let K=z.fog,Y=q.geometry,W=M.isMeshStandardMaterial?z.environment:null,ae=(M.isMeshStandardMaterial?r:t).get(M.envMap||W),Z=ae&&ae.mapping===ba?ae.image.height:null,te=_[M.type];M.precision!==null&&(m=a.getMaxPrecision(M.precision),m!==M.precision&&console.warn("THREE.WebGLProgram.getParameters:",M.precision,"not supported, using",m,"instead."));let de=Y.morphAttributes.position||Y.morphAttributes.normal||Y.morphAttributes.color,Pe=de!==void 0?de.length:0,ve=0;Y.morphAttributes.position!==void 0&&(ve=1),Y.morphAttributes.normal!==void 0&&(ve=2),Y.morphAttributes.color!==void 0&&(ve=3);let $,oe,ge,Ee;if(te){let Te=ar[te];$=Te.vertexShader,oe=Te.fragmentShader}else $=M.vertexShader,oe=M.fragmentShader,l.update(M),ge=l.getVertexShaderID(M),Ee=l.getFragmentShaderID(M);let he=e.getRenderTarget(),Ce=e.state.buffers.depth.getReversed(),Ke=q.isInstancedMesh===!0,Xe=q.isBatchedMesh===!0,qe=!!M.map,mt=!!M.matcap,O=!!ae,pt=!!M.aoMap,Je=!!M.lightMap,Qe=!!M.bumpMap,ye=!!M.normalMap,Ze=!!M.displacementMap,we=!!M.emissiveMap,Ie=!!M.metalnessMap,A=!!M.roughnessMap,y=M.anisotropy>0,H=M.clearcoat>0,re=M.dispersion>0,ne=M.iridescence>0,ee=M.sheen>0,Le=M.transmission>0,pe=y&&!!M.anisotropyMap,xe=H&&!!M.clearcoatMap,Be=H&&!!M.clearcoatNormalMap,ue=H&&!!M.clearcoatRoughnessMap,me=ne&&!!M.iridescenceMap,N=ne&&!!M.iridescenceThicknessMap,j=ee&&!!M.sheenColorMap,B=ee&&!!M.sheenRoughnessMap,Q=!!M.specularMap,se=!!M.specularColorMap,Me=!!M.specularIntensityMap,C=Le&&!!M.transmissionMap,k=Le&&!!M.thicknessMap,b=!!M.gradientMap,V=!!M.alphaMap,J=M.alphaTest>0,ie=!!M.alphaHash,Se=!!M.extensions,fe=wr;M.toneMapped&&(he===null||he.isXRRenderTarget===!0)&&(fe=e.toneMapping);let De={shaderID:te,shaderType:M.type,shaderName:M.name,vertexShader:$,fragmentShader:oe,defines:M.defines,customVertexShaderID:ge,customFragmentShaderID:Ee,isRawShaderMaterial:M.isRawShaderMaterial===!0,glslVersion:M.glslVersion,precision:m,batching:Xe,batchingColor:Xe&&q._colorsTexture!==null,instancing:Ke,instancingColor:Ke&&q.instanceColor!==null,instancingMorph:Ke&&q.morphTexture!==null,supportsVertexTextures:d,outputColorSpace:he===null?e.outputColorSpace:he.isXRRenderTarget===!0?he.texture.colorSpace:At,alphaToCoverage:!!M.alphaToCoverage,map:qe,matcap:mt,envMap:O,envMapMode:O&&ae.mapping,envMapCubeUVHeight:Z,aoMap:pt,lightMap:Je,bumpMap:Qe,normalMap:ye,displacementMap:d&&Ze,emissiveMap:we,normalMapObjectSpace:ye&&M.normalMapType===fc,normalMapTangentSpace:ye&&M.normalMapType===$o,metalnessMap:Ie,roughnessMap:A,anisotropy:y,anisotropyMap:pe,clearcoat:H,clearcoatMap:xe,clearcoatNormalMap:Be,clearcoatRoughnessMap:ue,dispersion:re,iridescence:ne,iridescenceMap:me,iridescenceThicknessMap:N,sheen:ee,sheenColorMap:j,sheenRoughnessMap:B,specularMap:Q,specularColorMap:se,specularIntensityMap:Me,transmission:Le,transmissionMap:C,thicknessMap:k,gradientMap:b,opaque:M.transparent===!1&&M.blending===ai&&M.alphaToCoverage===!1,alphaMap:V,alphaTest:J,alphaHash:ie,combine:M.combine,mapUv:qe&&g(M.map.channel),aoMapUv:pt&&g(M.aoMap.channel),lightMapUv:Je&&g(M.lightMap.channel),bumpMapUv:Qe&&g(M.bumpMap.channel),normalMapUv:ye&&g(M.normalMap.channel),displacementMapUv:Ze&&g(M.displacementMap.channel),emissiveMapUv:we&&g(M.emissiveMap.channel),metalnessMapUv:Ie&&g(M.metalnessMap.channel),roughnessMapUv:A&&g(M.roughnessMap.channel),anisotropyMapUv:pe&&g(M.anisotropyMap.channel),clearcoatMapUv:xe&&g(M.clearcoatMap.channel),clearcoatNormalMapUv:Be&&g(M.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:ue&&g(M.clearcoatRoughnessMap.channel),iridescenceMapUv:me&&g(M.iridescenceMap.channel),iridescenceThicknessMapUv:N&&g(M.iridescenceThicknessMap.channel),sheenColorMapUv:j&&g(M.sheenColorMap.channel),sheenRoughnessMapUv:B&&g(M.sheenRoughnessMap.channel),specularMapUv:Q&&g(M.specularMap.channel),specularColorMapUv:se&&g(M.specularColorMap.channel),specularIntensityMapUv:Me&&g(M.specularIntensityMap.channel),transmissionMapUv:C&&g(M.transmissionMap.channel),thicknessMapUv:k&&g(M.thicknessMap.channel),alphaMapUv:V&&g(M.alphaMap.channel),vertexTangents:!!Y.attributes.tangent&&(ye||y),vertexColors:M.vertexColors,vertexAlphas:M.vertexColors===!0&&!!Y.attributes.color&&Y.attributes.color.itemSize===4,pointsUvs:q.isPoints===!0&&!!Y.attributes.uv&&(qe||V),fog:!!K,useFog:M.fog===!0,fogExp2:!!K&&K.isFogExp2,flatShading:M.flatShading===!0,sizeAttenuation:M.sizeAttenuation===!0,logarithmicDepthBuffer:c,reverseDepthBuffer:Ce,skinning:q.isSkinnedMesh===!0,morphTargets:Y.morphAttributes.position!==void 0,morphNormals:Y.morphAttributes.normal!==void 0,morphColors:Y.morphAttributes.color!==void 0,morphTargetsCount:Pe,morphTextureStride:ve,numDirLights:T.directional.length,numPointLights:T.point.length,numSpotLights:T.spot.length,numSpotLightMaps:T.spotLightMap.length,numRectAreaLights:T.rectArea.length,numHemiLights:T.hemi.length,numDirLightShadows:T.directionalShadowMap.length,numPointLightShadows:T.pointShadowMap.length,numSpotLightShadows:T.spotShadowMap.length,numSpotLightShadowsWithMaps:T.numSpotLightShadowsWithMaps,numLightProbes:T.numLightProbes,numClippingPlanes:s.numPlanes,numClipIntersection:s.numIntersection,dithering:M.dithering,shadowMapEnabled:e.shadowMap.enabled&&P.length>0,shadowMapType:e.shadowMap.type,toneMapping:fe,decodeVideoTexture:qe&&M.map.isVideoTexture===!0&&Ye.getTransfer(M.map.colorSpace)===it,decodeVideoTextureEmissive:we&&M.emissiveMap.isVideoTexture===!0&&Ye.getTransfer(M.emissiveMap.colorSpace)===it,premultipliedAlpha:M.premultipliedAlpha,doubleSided:M.side===Ot,flipSided:M.side===It,useDepthPacking:M.depthPacking>=0,depthPacking:M.depthPacking||0,index0AttributeName:M.index0AttributeName,extensionClipCullDistance:Se&&M.extensions.clipCullDistance===!0&&i.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Se&&M.extensions.multiDraw===!0||Xe)&&i.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:M.customProgramCacheKey()};return De.vertexUv1s=u.has(1),De.vertexUv2s=u.has(2),De.vertexUv3s=u.has(3),u.clear(),De}function p(M){let T=[];if(M.shaderID?T.push(M.shaderID):(T.push(M.customVertexShaderID),T.push(M.customFragmentShaderID)),M.defines!==void 0)for(let P in M.defines)T.push(P),T.push(M.defines[P]);return M.isRawShaderMaterial===!1&&(x(T,M),v(T,M),T.push(e.outputColorSpace)),T.push(M.customProgramCacheKey),T.join()}function x(M,T){M.push(T.precision),M.push(T.outputColorSpace),M.push(T.envMapMode),M.push(T.envMapCubeUVHeight),M.push(T.mapUv),M.push(T.alphaMapUv),M.push(T.lightMapUv),M.push(T.aoMapUv),M.push(T.bumpMapUv),M.push(T.normalMapUv),M.push(T.displacementMapUv),M.push(T.emissiveMapUv),M.push(T.metalnessMapUv),M.push(T.roughnessMapUv),M.push(T.anisotropyMapUv),M.push(T.clearcoatMapUv),M.push(T.clearcoatNormalMapUv),M.push(T.clearcoatRoughnessMapUv),M.push(T.iridescenceMapUv),M.push(T.iridescenceThicknessMapUv),M.push(T.sheenColorMapUv),M.push(T.sheenRoughnessMapUv),M.push(T.specularMapUv),M.push(T.specularColorMapUv),M.push(T.specularIntensityMapUv),M.push(T.transmissionMapUv),M.push(T.thicknessMapUv),M.push(T.combine),M.push(T.fogExp2),M.push(T.sizeAttenuation),M.push(T.morphTargetsCount),M.push(T.morphAttributeCount),M.push(T.numDirLights),M.push(T.numPointLights),M.push(T.numSpotLights),M.push(T.numSpotLightMaps),M.push(T.numHemiLights),M.push(T.numRectAreaLights),M.push(T.numDirLightShadows),M.push(T.numPointLightShadows),M.push(T.numSpotLightShadows),M.push(T.numSpotLightShadowsWithMaps),M.push(T.numLightProbes),M.push(T.shadowMapType),M.push(T.toneMapping),M.push(T.numClippingPlanes),M.push(T.numClipIntersection),M.push(T.depthPacking)}function v(M,T){o.disableAll(),T.supportsVertexTextures&&o.enable(0),T.instancing&&o.enable(1),T.instancingColor&&o.enable(2),T.instancingMorph&&o.enable(3),T.matcap&&o.enable(4),T.envMap&&o.enable(5),T.normalMapObjectSpace&&o.enable(6),T.normalMapTangentSpace&&o.enable(7),T.clearcoat&&o.enable(8),T.iridescence&&o.enable(9),T.alphaTest&&o.enable(10),T.vertexColors&&o.enable(11),T.vertexAlphas&&o.enable(12),T.vertexUv1s&&o.enable(13),T.vertexUv2s&&o.enable(14),T.vertexUv3s&&o.enable(15),T.vertexTangents&&o.enable(16),T.anisotropy&&o.enable(17),T.alphaHash&&o.enable(18),T.batching&&o.enable(19),T.dispersion&&o.enable(20),T.batchingColor&&o.enable(21),M.push(o.mask),o.disableAll(),T.fog&&o.enable(0),T.useFog&&o.enable(1),T.flatShading&&o.enable(2),T.logarithmicDepthBuffer&&o.enable(3),T.reverseDepthBuffer&&o.enable(4),T.skinning&&o.enable(5),T.morphTargets&&o.enable(6),T.morphNormals&&o.enable(7),T.morphColors&&o.enable(8),T.premultipliedAlpha&&o.enable(9),T.shadowMapEnabled&&o.enable(10),T.doubleSided&&o.enable(11),T.flipSided&&o.enable(12),T.useDepthPacking&&o.enable(13),T.dithering&&o.enable(14),T.transmission&&o.enable(15),T.sheen&&o.enable(16),T.opaque&&o.enable(17),T.pointsUvs&&o.enable(18),T.decodeVideoTexture&&o.enable(19),T.decodeVideoTextureEmissive&&o.enable(20),T.alphaToCoverage&&o.enable(21),M.push(o.mask)}function E(M){let T=_[M.type],P;if(T){let z=ar[T];P=ad.clone(z.uniforms)}else P=M.uniforms;return P}function I(M,T){let P;for(let z=0,q=h.length;z<q;z++){let K=h[z];if(K.cacheKey===T){P=K,++P.usedTimes;break}}return P===void 0&&(P=new vg(e,T,M,n),h.push(P)),P}function w(M){if(--M.usedTimes===0){let T=h.indexOf(M);h[T]=h[h.length-1],h.pop(),M.destroy()}}function R(M){l.remove(M)}function U(){l.dispose()}return{getParameters:f,getProgramCacheKey:p,getUniforms:E,acquireProgram:I,releaseProgram:w,releaseShaderCache:R,programs:h,dispose:U}}function Tg(){let e=new WeakMap;function t(s){return e.has(s)}function r(s){let o=e.get(s);return o===void 0&&(o={},e.set(s,o)),o}function i(s){e.delete(s)}function a(s,o,l){e.get(s)[o]=l}function n(){e=new WeakMap}return{has:t,get:r,remove:i,update:a,dispose:n}}function Eg(e,t){return e.groupOrder!==t.groupOrder?e.groupOrder-t.groupOrder:e.renderOrder!==t.renderOrder?e.renderOrder-t.renderOrder:e.material.id!==t.material.id?e.material.id-t.material.id:e.z!==t.z?e.z-t.z:e.id-t.id}function nu(e,t){return e.groupOrder!==t.groupOrder?e.groupOrder-t.groupOrder:e.renderOrder!==t.renderOrder?e.renderOrder-t.renderOrder:e.z!==t.z?t.z-e.z:e.id-t.id}function su(){let e=[],t=0,r=[],i=[],a=[];function n(){t=0,r.length=0,i.length=0,a.length=0}function s(c,d,m,_,g,f){let p=e[t];return p===void 0?(p={id:c.id,object:c,geometry:d,material:m,groupOrder:_,renderOrder:c.renderOrder,z:g,group:f},e[t]=p):(p.id=c.id,p.object=c,p.geometry=d,p.material=m,p.groupOrder=_,p.renderOrder=c.renderOrder,p.z=g,p.group=f),t++,p}function o(c,d,m,_,g,f){let p=s(c,d,m,_,g,f);m.transmission>0?i.push(p):m.transparent===!0?a.push(p):r.push(p)}function l(c,d,m,_,g,f){let p=s(c,d,m,_,g,f);m.transmission>0?i.unshift(p):m.transparent===!0?a.unshift(p):r.unshift(p)}function u(c,d){r.length>1&&r.sort(c||Eg),i.length>1&&i.sort(d||nu),a.length>1&&a.sort(d||nu)}function h(){for(let c=t,d=e.length;c<d;c++){let m=e[c];if(m.id===null)break;m.id=null,m.object=null,m.geometry=null,m.material=null,m.group=null}}return{opaque:r,transmissive:i,transparent:a,init:n,push:o,unshift:l,finish:h,sort:u}}function bg(){let e=new WeakMap;function t(i,a){let n=e.get(i),s;return n===void 0?(s=new su,e.set(i,[s])):a>=n.length?(s=new su,n.push(s)):s=n[a],s}function r(){e=new WeakMap}return{get:t,dispose:r}}function wg(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let r;switch(t.type){case"DirectionalLight":r={direction:new L,color:new Ne};break;case"SpotLight":r={position:new L,direction:new L,color:new Ne,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":r={position:new L,color:new Ne,distance:0,decay:0};break;case"HemisphereLight":r={direction:new L,skyColor:new Ne,groundColor:new Ne};break;case"RectAreaLight":r={color:new Ne,position:new L,halfWidth:new L,halfHeight:new L};break}return e[t.id]=r,r}}}function Ag(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let r;switch(t.type){case"DirectionalLight":r={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Fe};break;case"SpotLight":r={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Fe};break;case"PointLight":r={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Fe,shadowCameraNear:1,shadowCameraFar:1e3};break}return e[t.id]=r,r}}}var Rg=0;function Cg(e,t){return(t.castShadow?2:0)-(e.castShadow?2:0)+(t.map?1:0)-(e.map?1:0)}function Lg(e){let t=new wg,r=Ag(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let u=0;u<9;u++)i.probe.push(new L);let a=new L,n=new Ge,s=new Ge;function o(u){let h=0,c=0,d=0;for(let M=0;M<9;M++)i.probe[M].set(0,0,0);let m=0,_=0,g=0,f=0,p=0,x=0,v=0,E=0,I=0,w=0,R=0;u.sort(Cg);for(let M=0,T=u.length;M<T;M++){let P=u[M],z=P.color,q=P.intensity,K=P.distance,Y=P.shadow&&P.shadow.map?P.shadow.map.texture:null;if(P.isAmbientLight)h+=z.r*q,c+=z.g*q,d+=z.b*q;else if(P.isLightProbe){for(let W=0;W<9;W++)i.probe[W].addScaledVector(P.sh.coefficients[W],q);R++}else if(P.isDirectionalLight){let W=t.get(P);if(W.color.copy(P.color).multiplyScalar(P.intensity),P.castShadow){let ae=P.shadow,Z=r.get(P);Z.shadowIntensity=ae.intensity,Z.shadowBias=ae.bias,Z.shadowNormalBias=ae.normalBias,Z.shadowRadius=ae.radius,Z.shadowMapSize=ae.mapSize,i.directionalShadow[m]=Z,i.directionalShadowMap[m]=Y,i.directionalShadowMatrix[m]=P.shadow.matrix,x++}i.directional[m]=W,m++}else if(P.isSpotLight){let W=t.get(P);W.position.setFromMatrixPosition(P.matrixWorld),W.color.copy(z).multiplyScalar(q),W.distance=K,W.coneCos=Math.cos(P.angle),W.penumbraCos=Math.cos(P.angle*(1-P.penumbra)),W.decay=P.decay,i.spot[g]=W;let ae=P.shadow;if(P.map&&(i.spotLightMap[I]=P.map,I++,ae.updateMatrices(P),P.castShadow&&w++),i.spotLightMatrix[g]=ae.matrix,P.castShadow){let Z=r.get(P);Z.shadowIntensity=ae.intensity,Z.shadowBias=ae.bias,Z.shadowNormalBias=ae.normalBias,Z.shadowRadius=ae.radius,Z.shadowMapSize=ae.mapSize,i.spotShadow[g]=Z,i.spotShadowMap[g]=Y,E++}g++}else if(P.isRectAreaLight){let W=t.get(P);W.color.copy(z).multiplyScalar(q),W.halfWidth.set(P.width*.5,0,0),W.halfHeight.set(0,P.height*.5,0),i.rectArea[f]=W,f++}else if(P.isPointLight){let W=t.get(P);if(W.color.copy(P.color).multiplyScalar(P.intensity),W.distance=P.distance,W.decay=P.decay,P.castShadow){let ae=P.shadow,Z=r.get(P);Z.shadowIntensity=ae.intensity,Z.shadowBias=ae.bias,Z.shadowNormalBias=ae.normalBias,Z.shadowRadius=ae.radius,Z.shadowMapSize=ae.mapSize,Z.shadowCameraNear=ae.camera.near,Z.shadowCameraFar=ae.camera.far,i.pointShadow[_]=Z,i.pointShadowMap[_]=Y,i.pointShadowMatrix[_]=P.shadow.matrix,v++}i.point[_]=W,_++}else if(P.isHemisphereLight){let W=t.get(P);W.skyColor.copy(P.color).multiplyScalar(q),W.groundColor.copy(P.groundColor).multiplyScalar(q),i.hemi[p]=W,p++}}f>0&&(e.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=ce.LTC_FLOAT_1,i.rectAreaLTC2=ce.LTC_FLOAT_2):(i.rectAreaLTC1=ce.LTC_HALF_1,i.rectAreaLTC2=ce.LTC_HALF_2)),i.ambient[0]=h,i.ambient[1]=c,i.ambient[2]=d;let U=i.hash;(U.directionalLength!==m||U.pointLength!==_||U.spotLength!==g||U.rectAreaLength!==f||U.hemiLength!==p||U.numDirectionalShadows!==x||U.numPointShadows!==v||U.numSpotShadows!==E||U.numSpotMaps!==I||U.numLightProbes!==R)&&(i.directional.length=m,i.spot.length=g,i.rectArea.length=f,i.point.length=_,i.hemi.length=p,i.directionalShadow.length=x,i.directionalShadowMap.length=x,i.pointShadow.length=v,i.pointShadowMap.length=v,i.spotShadow.length=E,i.spotShadowMap.length=E,i.directionalShadowMatrix.length=x,i.pointShadowMatrix.length=v,i.spotLightMatrix.length=E+I-w,i.spotLightMap.length=I,i.numSpotLightShadowsWithMaps=w,i.numLightProbes=R,U.directionalLength=m,U.pointLength=_,U.spotLength=g,U.rectAreaLength=f,U.hemiLength=p,U.numDirectionalShadows=x,U.numPointShadows=v,U.numSpotShadows=E,U.numSpotMaps=I,U.numLightProbes=R,i.version=Rg++)}function l(u,h){let c=0,d=0,m=0,_=0,g=0,f=h.matrixWorldInverse;for(let p=0,x=u.length;p<x;p++){let v=u[p];if(v.isDirectionalLight){let E=i.directional[c];E.direction.setFromMatrixPosition(v.matrixWorld),a.setFromMatrixPosition(v.target.matrixWorld),E.direction.sub(a),E.direction.transformDirection(f),c++}else if(v.isSpotLight){let E=i.spot[m];E.position.setFromMatrixPosition(v.matrixWorld),E.position.applyMatrix4(f),E.direction.setFromMatrixPosition(v.matrixWorld),a.setFromMatrixPosition(v.target.matrixWorld),E.direction.sub(a),E.direction.transformDirection(f),m++}else if(v.isRectAreaLight){let E=i.rectArea[_];E.position.setFromMatrixPosition(v.matrixWorld),E.position.applyMatrix4(f),s.identity(),n.copy(v.matrixWorld),n.premultiply(f),s.extractRotation(n),E.halfWidth.set(v.width*.5,0,0),E.halfHeight.set(0,v.height*.5,0),E.halfWidth.applyMatrix4(s),E.halfHeight.applyMatrix4(s),_++}else if(v.isPointLight){let E=i.point[d];E.position.setFromMatrixPosition(v.matrixWorld),E.position.applyMatrix4(f),d++}else if(v.isHemisphereLight){let E=i.hemi[g];E.direction.setFromMatrixPosition(v.matrixWorld),E.direction.transformDirection(f),g++}}}return{setup:o,setupView:l,state:i}}function ou(e){let t=new Lg(e),r=[],i=[];function a(h){u.camera=h,r.length=0,i.length=0}function n(h){r.push(h)}function s(h){i.push(h)}function o(){t.setup(r)}function l(h){t.setupView(r,h)}let u={lightsArray:r,shadowsArray:i,camera:null,lights:t,transmissionRenderTarget:{}};return{init:a,state:u,setupLights:o,setupLightsView:l,pushLight:n,pushShadow:s}}function Pg(e){let t=new WeakMap;function r(a,n=0){let s=t.get(a),o;return s===void 0?(o=new ou(e),t.set(a,[o])):n>=s.length?(o=new ou(e),s.push(o)):o=s[n],o}function i(){t=new WeakMap}return{get:r,dispose:i}}var Ig=class extends er{static get type(){return"MeshDepthMaterial"}constructor(e){super(),this.isMeshDepthMaterial=!0,this.depthPacking=dc,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},Dg=class extends er{static get type(){return"MeshDistanceMaterial"}constructor(e){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}},Ug=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Ng=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function Og(e,t,r){let i=new Xs,a=new Fe,n=new Fe,s=new tt,o=new Ig({depthPacking:pc}),l=new Dg,u={},h=r.maxTextureSize,c={[hr]:It,[It]:hr,[Ot]:Ot},d=new Or({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Fe},radius:{value:4}},vertexShader:Ug,fragmentShader:Ng}),m=d.clone();m.defines.HORIZONTAL_PASS=1;let _=new Rt;_.setAttribute("position",new vt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let g=new ut(_,d),f=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Lo;let p=this.type;this.render=function(w,R,U){if(f.enabled===!1||f.autoUpdate===!1&&f.needsUpdate===!1||w.length===0)return;let M=e.getRenderTarget(),T=e.getActiveCubeFace(),P=e.getActiveMipmapLevel(),z=e.state;z.setBlending(br),z.buffers.color.setClear(1,1,1,1),z.buffers.depth.setTest(!0),z.setScissorTest(!1);let q=p!==ur&&this.type===ur,K=p===ur&&this.type!==ur;for(let Y=0,W=w.length;Y<W;Y++){let ae=w[Y],Z=ae.shadow;if(Z===void 0){console.warn("THREE.WebGLShadowMap:",ae,"has no shadow.");continue}if(Z.autoUpdate===!1&&Z.needsUpdate===!1)continue;a.copy(Z.mapSize);let te=Z.getFrameExtents();if(a.multiply(te),n.copy(Z.mapSize),(a.x>h||a.y>h)&&(a.x>h&&(n.x=Math.floor(h/te.x),a.x=n.x*te.x,Z.mapSize.x=n.x),a.y>h&&(n.y=Math.floor(h/te.y),a.y=n.y*te.y,Z.mapSize.y=n.y)),Z.map===null||q===!0||K===!0){let Pe=this.type!==ur?{minFilter:wt,magFilter:wt}:{};Z.map!==null&&Z.map.dispose(),Z.map=new Wr(a.x,a.y,Pe),Z.map.texture.name=ae.name+".shadowMap",Z.camera.updateProjectionMatrix()}e.setRenderTarget(Z.map),e.clear();let de=Z.getViewportCount();for(let Pe=0;Pe<de;Pe++){let ve=Z.getViewport(Pe);s.set(n.x*ve.x,n.y*ve.y,n.x*ve.z,n.y*ve.w),z.viewport(s),Z.updateMatrices(ae,Pe),i=Z.getFrustum(),E(R,U,Z.camera,ae,this.type)}Z.isPointLightShadow!==!0&&this.type===ur&&x(Z,U),Z.needsUpdate=!1}p=this.type,f.needsUpdate=!1,e.setRenderTarget(M,T,P)};function x(w,R){let U=t.update(g);d.defines.VSM_SAMPLES!==w.blurSamples&&(d.defines.VSM_SAMPLES=w.blurSamples,m.defines.VSM_SAMPLES=w.blurSamples,d.needsUpdate=!0,m.needsUpdate=!0),w.mapPass===null&&(w.mapPass=new Wr(a.x,a.y)),d.uniforms.shadow_pass.value=w.map.texture,d.uniforms.resolution.value=w.mapSize,d.uniforms.radius.value=w.radius,e.setRenderTarget(w.mapPass),e.clear(),e.renderBufferDirect(R,null,U,d,g,null),m.uniforms.shadow_pass.value=w.mapPass.texture,m.uniforms.resolution.value=w.mapSize,m.uniforms.radius.value=w.radius,e.setRenderTarget(w.map),e.clear(),e.renderBufferDirect(R,null,U,m,g,null)}function v(w,R,U,M){let T=null,P=U.isPointLight===!0?w.customDistanceMaterial:w.customDepthMaterial;if(P!==void 0)T=P;else if(T=U.isPointLight===!0?l:o,e.localClippingEnabled&&R.clipShadows===!0&&Array.isArray(R.clippingPlanes)&&R.clippingPlanes.length!==0||R.displacementMap&&R.displacementScale!==0||R.alphaMap&&R.alphaTest>0||R.map&&R.alphaTest>0){let z=T.uuid,q=R.uuid,K=u[z];K===void 0&&(K={},u[z]=K);let Y=K[q];Y===void 0&&(Y=T.clone(),K[q]=Y,R.addEventListener("dispose",I)),T=Y}if(T.visible=R.visible,T.wireframe=R.wireframe,M===ur?T.side=R.shadowSide!==null?R.shadowSide:R.side:T.side=R.shadowSide!==null?R.shadowSide:c[R.side],T.alphaMap=R.alphaMap,T.alphaTest=R.alphaTest,T.map=R.map,T.clipShadows=R.clipShadows,T.clippingPlanes=R.clippingPlanes,T.clipIntersection=R.clipIntersection,T.displacementMap=R.displacementMap,T.displacementScale=R.displacementScale,T.displacementBias=R.displacementBias,T.wireframeLinewidth=R.wireframeLinewidth,T.linewidth=R.linewidth,U.isPointLight===!0&&T.isMeshDistanceMaterial===!0){let z=e.properties.get(T);z.light=U}return T}function E(w,R,U,M,T){if(w.visible===!1)return;if(w.layers.test(R.layers)&&(w.isMesh||w.isLine||w.isPoints)&&(w.castShadow||w.receiveShadow&&T===ur)&&(!w.frustumCulled||i.intersectsObject(w))){w.modelViewMatrix.multiplyMatrices(U.matrixWorldInverse,w.matrixWorld);let z=t.update(w),q=w.material;if(Array.isArray(q)){let K=z.groups;for(let Y=0,W=K.length;Y<W;Y++){let ae=K[Y],Z=q[ae.materialIndex];if(Z&&Z.visible){let te=v(w,Z,M,T);w.onBeforeShadow(e,w,R,U,z,te,ae),e.renderBufferDirect(U,null,z,te,w,ae),w.onAfterShadow(e,w,R,U,z,te,ae)}}}else if(q.visible){let K=v(w,q,M,T);w.onBeforeShadow(e,w,R,U,z,K,null),e.renderBufferDirect(U,null,z,K,w,null),w.onAfterShadow(e,w,R,U,z,K,null)}}let P=w.children;for(let z=0,q=P.length;z<q;z++)E(P[z],R,U,M,T)}function I(w){w.target.removeEventListener("dispose",I);for(let R in u){let U=u[R],M=w.target.uuid;M in U&&(U[M].dispose(),delete U[M])}}}var Fg={[Dn]:Un,[Nn]:Bn,[On]:zn,[ni]:Fn,[Un]:Dn,[Bn]:Nn,[zn]:On,[Fn]:ni};function Bg(e,t){function r(){let C=!1,k=new tt,b=null,V=new tt(0,0,0,0);return{setMask:function(J){b!==J&&!C&&(e.colorMask(J,J,J,J),b=J)},setLocked:function(J){C=J},setClear:function(J,ie,Se,fe,De){De===!0&&(J*=fe,ie*=fe,Se*=fe),k.set(J,ie,Se,fe),V.equals(k)===!1&&(e.clearColor(J,ie,Se,fe),V.copy(k))},reset:function(){C=!1,b=null,V.set(-1,0,0,0)}}}function i(){let C=!1,k=!1,b=null,V=null,J=null;return{setReversed:function(ie){if(k!==ie){let Se=t.get("EXT_clip_control");k?Se.clipControlEXT(Se.LOWER_LEFT_EXT,Se.ZERO_TO_ONE_EXT):Se.clipControlEXT(Se.LOWER_LEFT_EXT,Se.NEGATIVE_ONE_TO_ONE_EXT);let fe=J;J=null,this.setClear(fe)}k=ie},getReversed:function(){return k},setTest:function(ie){ie?he(e.DEPTH_TEST):Ce(e.DEPTH_TEST)},setMask:function(ie){b!==ie&&!C&&(e.depthMask(ie),b=ie)},setFunc:function(ie){if(k&&(ie=Fg[ie]),V!==ie){switch(ie){case Dn:e.depthFunc(e.NEVER);break;case Un:e.depthFunc(e.ALWAYS);break;case Nn:e.depthFunc(e.LESS);break;case ni:e.depthFunc(e.LEQUAL);break;case On:e.depthFunc(e.EQUAL);break;case Fn:e.depthFunc(e.GEQUAL);break;case Bn:e.depthFunc(e.GREATER);break;case zn:e.depthFunc(e.NOTEQUAL);break;default:e.depthFunc(e.LEQUAL)}V=ie}},setLocked:function(ie){C=ie},setClear:function(ie){J!==ie&&(k&&(ie=1-ie),e.clearDepth(ie),J=ie)},reset:function(){C=!1,b=null,V=null,J=null,k=!1}}}function a(){let C=!1,k=null,b=null,V=null,J=null,ie=null,Se=null,fe=null,De=null;return{setTest:function(Te){C||(Te?he(e.STENCIL_TEST):Ce(e.STENCIL_TEST))},setMask:function(Te){k!==Te&&!C&&(e.stencilMask(Te),k=Te)},setFunc:function(Te,rt,je){(b!==Te||V!==rt||J!==je)&&(e.stencilFunc(Te,rt,je),b=Te,V=rt,J=je)},setOp:function(Te,rt,je){(ie!==Te||Se!==rt||fe!==je)&&(e.stencilOp(Te,rt,je),ie=Te,Se=rt,fe=je)},setLocked:function(Te){C=Te},setClear:function(Te){De!==Te&&(e.clearStencil(Te),De=Te)},reset:function(){C=!1,k=null,b=null,V=null,J=null,ie=null,Se=null,fe=null,De=null}}}let n=new r,s=new i,o=new a,l=new WeakMap,u=new WeakMap,h={},c={},d=new WeakMap,m=[],_=null,g=!1,f=null,p=null,x=null,v=null,E=null,I=null,w=null,R=new Ne(0,0,0),U=0,M=!1,T=null,P=null,z=null,q=null,K=null,Y=e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS),W=!1,ae=0,Z=e.getParameter(e.VERSION);Z.indexOf("WebGL")!==-1?(ae=parseFloat(/^WebGL (\d)/.exec(Z)[1]),W=ae>=1):Z.indexOf("OpenGL ES")!==-1&&(ae=parseFloat(/^OpenGL ES (\d)/.exec(Z)[1]),W=ae>=2);let te=null,de={},Pe=e.getParameter(e.SCISSOR_BOX),ve=e.getParameter(e.VIEWPORT),$=new tt().fromArray(Pe),oe=new tt().fromArray(ve);function ge(C,k,b,V){let J=new Uint8Array(4),ie=e.createTexture();e.bindTexture(C,ie),e.texParameteri(C,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(C,e.TEXTURE_MAG_FILTER,e.NEAREST);for(let Se=0;Se<b;Se++)C===e.TEXTURE_3D||C===e.TEXTURE_2D_ARRAY?e.texImage3D(k,0,e.RGBA,1,1,V,0,e.RGBA,e.UNSIGNED_BYTE,J):e.texImage2D(k+Se,0,e.RGBA,1,1,0,e.RGBA,e.UNSIGNED_BYTE,J);return ie}let Ee={};Ee[e.TEXTURE_2D]=ge(e.TEXTURE_2D,e.TEXTURE_2D,1),Ee[e.TEXTURE_CUBE_MAP]=ge(e.TEXTURE_CUBE_MAP,e.TEXTURE_CUBE_MAP_POSITIVE_X,6),Ee[e.TEXTURE_2D_ARRAY]=ge(e.TEXTURE_2D_ARRAY,e.TEXTURE_2D_ARRAY,1,1),Ee[e.TEXTURE_3D]=ge(e.TEXTURE_3D,e.TEXTURE_3D,1,1),n.setClear(0,0,0,1),s.setClear(1),o.setClear(0),he(e.DEPTH_TEST),s.setFunc(ni),Qe(!1),ye(Co),he(e.CULL_FACE),pt(br);function he(C){h[C]!==!0&&(e.enable(C),h[C]=!0)}function Ce(C){h[C]!==!1&&(e.disable(C),h[C]=!1)}function Ke(C,k){return c[C]!==k?(e.bindFramebuffer(C,k),c[C]=k,C===e.DRAW_FRAMEBUFFER&&(c[e.FRAMEBUFFER]=k),C===e.FRAMEBUFFER&&(c[e.DRAW_FRAMEBUFFER]=k),!0):!1}function Xe(C,k){let b=m,V=!1;if(C){b=d.get(k),b===void 0&&(b=[],d.set(k,b));let J=C.textures;if(b.length!==J.length||b[0]!==e.COLOR_ATTACHMENT0){for(let ie=0,Se=J.length;ie<Se;ie++)b[ie]=e.COLOR_ATTACHMENT0+ie;b.length=J.length,V=!0}}else b[0]!==e.BACK&&(b[0]=e.BACK,V=!0);V&&e.drawBuffers(b)}function qe(C){return _!==C?(e.useProgram(C),_=C,!0):!1}let mt={[Vr]:e.FUNC_ADD,[Bh]:e.FUNC_SUBTRACT,[zh]:e.FUNC_REVERSE_SUBTRACT};mt[Hh]=e.MIN,mt[kh]=e.MAX;let O={[Vh]:e.ZERO,[Gh]:e.ONE,[Wh]:e.SRC_COLOR,[Pn]:e.SRC_ALPHA,[Zh]:e.SRC_ALPHA_SATURATE,[qh]:e.DST_COLOR,[jh]:e.DST_ALPHA,[Xh]:e.ONE_MINUS_SRC_COLOR,[In]:e.ONE_MINUS_SRC_ALPHA,[Kh]:e.ONE_MINUS_DST_COLOR,[Yh]:e.ONE_MINUS_DST_ALPHA,[$h]:e.CONSTANT_COLOR,[Jh]:e.ONE_MINUS_CONSTANT_COLOR,[Qh]:e.CONSTANT_ALPHA,[ec]:e.ONE_MINUS_CONSTANT_ALPHA};function pt(C,k,b,V,J,ie,Se,fe,De,Te){if(C===br){g===!0&&(Ce(e.BLEND),g=!1);return}if(g===!1&&(he(e.BLEND),g=!0),C!==Fh){if(C!==f||Te!==M){if((p!==Vr||E!==Vr)&&(e.blendEquation(e.FUNC_ADD),p=Vr,E=Vr),Te)switch(C){case ai:e.blendFuncSeparate(e.ONE,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case cr:e.blendFunc(e.ONE,e.ONE);break;case Po:e.blendFuncSeparate(e.ZERO,e.ONE_MINUS_SRC_COLOR,e.ZERO,e.ONE);break;case Io:e.blendFuncSeparate(e.ZERO,e.SRC_COLOR,e.ZERO,e.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",C);break}else switch(C){case ai:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case cr:e.blendFunc(e.SRC_ALPHA,e.ONE);break;case Po:e.blendFuncSeparate(e.ZERO,e.ONE_MINUS_SRC_COLOR,e.ZERO,e.ONE);break;case Io:e.blendFunc(e.ZERO,e.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",C);break}x=null,v=null,I=null,w=null,R.set(0,0,0),U=0,f=C,M=Te}return}J=J||k,ie=ie||b,Se=Se||V,(k!==p||J!==E)&&(e.blendEquationSeparate(mt[k],mt[J]),p=k,E=J),(b!==x||V!==v||ie!==I||Se!==w)&&(e.blendFuncSeparate(O[b],O[V],O[ie],O[Se]),x=b,v=V,I=ie,w=Se),(fe.equals(R)===!1||De!==U)&&(e.blendColor(fe.r,fe.g,fe.b,De),R.copy(fe),U=De),f=C,M=!1}function Je(C,k){C.side===Ot?Ce(e.CULL_FACE):he(e.CULL_FACE);let b=C.side===It;k&&(b=!b),Qe(b),C.blending===ai&&C.transparent===!1?pt(br):pt(C.blending,C.blendEquation,C.blendSrc,C.blendDst,C.blendEquationAlpha,C.blendSrcAlpha,C.blendDstAlpha,C.blendColor,C.blendAlpha,C.premultipliedAlpha),s.setFunc(C.depthFunc),s.setTest(C.depthTest),s.setMask(C.depthWrite),n.setMask(C.colorWrite);let V=C.stencilWrite;o.setTest(V),V&&(o.setMask(C.stencilWriteMask),o.setFunc(C.stencilFunc,C.stencilRef,C.stencilFuncMask),o.setOp(C.stencilFail,C.stencilZFail,C.stencilZPass)),we(C.polygonOffset,C.polygonOffsetFactor,C.polygonOffsetUnits),C.alphaToCoverage===!0?he(e.SAMPLE_ALPHA_TO_COVERAGE):Ce(e.SAMPLE_ALPHA_TO_COVERAGE)}function Qe(C){T!==C&&(C?e.frontFace(e.CW):e.frontFace(e.CCW),T=C)}function ye(C){C!==Uh?(he(e.CULL_FACE),C!==P&&(C===Co?e.cullFace(e.BACK):C===Nh?e.cullFace(e.FRONT):e.cullFace(e.FRONT_AND_BACK))):Ce(e.CULL_FACE),P=C}function Ze(C){C!==z&&(W&&e.lineWidth(C),z=C)}function we(C,k,b){C?(he(e.POLYGON_OFFSET_FILL),(q!==k||K!==b)&&(e.polygonOffset(k,b),q=k,K=b)):Ce(e.POLYGON_OFFSET_FILL)}function Ie(C){C?he(e.SCISSOR_TEST):Ce(e.SCISSOR_TEST)}function A(C){C===void 0&&(C=e.TEXTURE0+Y-1),te!==C&&(e.activeTexture(C),te=C)}function y(C,k,b){b===void 0&&(te===null?b=e.TEXTURE0+Y-1:b=te);let V=de[b];V===void 0&&(V={type:void 0,texture:void 0},de[b]=V),(V.type!==C||V.texture!==k)&&(te!==b&&(e.activeTexture(b),te=b),e.bindTexture(C,k||Ee[C]),V.type=C,V.texture=k)}function H(){let C=de[te];C!==void 0&&C.type!==void 0&&(e.bindTexture(C.type,null),C.type=void 0,C.texture=void 0)}function re(){try{e.compressedTexImage2D.apply(e,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function ne(){try{e.compressedTexImage3D.apply(e,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function ee(){try{e.texSubImage2D.apply(e,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function Le(){try{e.texSubImage3D.apply(e,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function pe(){try{e.compressedTexSubImage2D.apply(e,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function xe(){try{e.compressedTexSubImage3D.apply(e,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function Be(){try{e.texStorage2D.apply(e,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function ue(){try{e.texStorage3D.apply(e,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function me(){try{e.texImage2D.apply(e,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function N(){try{e.texImage3D.apply(e,arguments)}catch(C){console.error("THREE.WebGLState:",C)}}function j(C){$.equals(C)===!1&&(e.scissor(C.x,C.y,C.z,C.w),$.copy(C))}function B(C){oe.equals(C)===!1&&(e.viewport(C.x,C.y,C.z,C.w),oe.copy(C))}function Q(C,k){let b=u.get(k);b===void 0&&(b=new WeakMap,u.set(k,b));let V=b.get(C);V===void 0&&(V=e.getUniformBlockIndex(k,C.name),b.set(C,V))}function se(C,k){let b=u.get(k).get(C);l.get(k)!==b&&(e.uniformBlockBinding(k,b,C.__bindingPointIndex),l.set(k,b))}function Me(){e.disable(e.BLEND),e.disable(e.CULL_FACE),e.disable(e.DEPTH_TEST),e.disable(e.POLYGON_OFFSET_FILL),e.disable(e.SCISSOR_TEST),e.disable(e.STENCIL_TEST),e.disable(e.SAMPLE_ALPHA_TO_COVERAGE),e.blendEquation(e.FUNC_ADD),e.blendFunc(e.ONE,e.ZERO),e.blendFuncSeparate(e.ONE,e.ZERO,e.ONE,e.ZERO),e.blendColor(0,0,0,0),e.colorMask(!0,!0,!0,!0),e.clearColor(0,0,0,0),e.depthMask(!0),e.depthFunc(e.LESS),s.setReversed(!1),e.clearDepth(1),e.stencilMask(4294967295),e.stencilFunc(e.ALWAYS,0,4294967295),e.stencilOp(e.KEEP,e.KEEP,e.KEEP),e.clearStencil(0),e.cullFace(e.BACK),e.frontFace(e.CCW),e.polygonOffset(0,0),e.activeTexture(e.TEXTURE0),e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),e.bindFramebuffer(e.READ_FRAMEBUFFER,null),e.useProgram(null),e.lineWidth(1),e.scissor(0,0,e.canvas.width,e.canvas.height),e.viewport(0,0,e.canvas.width,e.canvas.height),h={},te=null,de={},c={},d=new WeakMap,m=[],_=null,g=!1,f=null,p=null,x=null,v=null,E=null,I=null,w=null,R=new Ne(0,0,0),U=0,M=!1,T=null,P=null,z=null,q=null,K=null,$.set(0,0,e.canvas.width,e.canvas.height),oe.set(0,0,e.canvas.width,e.canvas.height),n.reset(),s.reset(),o.reset()}return{buffers:{color:n,depth:s,stencil:o},enable:he,disable:Ce,bindFramebuffer:Ke,drawBuffers:Xe,useProgram:qe,setBlending:pt,setMaterial:Je,setFlipSided:Qe,setCullFace:ye,setLineWidth:Ze,setPolygonOffset:we,setScissorTest:Ie,activeTexture:A,bindTexture:y,unbindTexture:H,compressedTexImage2D:re,compressedTexImage3D:ne,texImage2D:me,texImage3D:N,updateUBOMapping:Q,uniformBlockBinding:se,texStorage2D:Be,texStorage3D:ue,texSubImage2D:ee,texSubImage3D:Le,compressedTexSubImage2D:pe,compressedTexSubImage3D:xe,scissor:j,viewport:B,reset:Me}}function lu(e,t,r,i){let a=zg(i);switch(r){case ko:return e*t;case Go:return e*t;case Wo:return e*t*2;case Wn:return e*t/a.components*a.byteLength;case Xn:return e*t/a.components*a.byteLength;case Xo:return e*t*2/a.components*a.byteLength;case jn:return e*t*2/a.components*a.byteLength;case Vo:return e*t*3/a.components*a.byteLength;case kt:return e*t*4/a.components*a.byteLength;case Yn:return e*t*4/a.components*a.byteLength;case Ra:case Ca:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*8;case La:case Pa:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case Kn:case $n:return Math.max(e,16)*Math.max(t,8)/4;case qn:case Zn:return Math.max(e,8)*Math.max(t,8)/2;case Jn:case Qn:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*8;case es:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case ts:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case rs:return Math.floor((e+4)/5)*Math.floor((t+3)/4)*16;case is:return Math.floor((e+4)/5)*Math.floor((t+4)/5)*16;case as:return Math.floor((e+5)/6)*Math.floor((t+4)/5)*16;case ns:return Math.floor((e+5)/6)*Math.floor((t+5)/6)*16;case ss:return Math.floor((e+7)/8)*Math.floor((t+4)/5)*16;case os:return Math.floor((e+7)/8)*Math.floor((t+5)/6)*16;case ls:return Math.floor((e+7)/8)*Math.floor((t+7)/8)*16;case us:return Math.floor((e+9)/10)*Math.floor((t+4)/5)*16;case hs:return Math.floor((e+9)/10)*Math.floor((t+5)/6)*16;case cs:return Math.floor((e+9)/10)*Math.floor((t+7)/8)*16;case ds:return Math.floor((e+9)/10)*Math.floor((t+9)/10)*16;case ps:return Math.floor((e+11)/12)*Math.floor((t+9)/10)*16;case fs:return Math.floor((e+11)/12)*Math.floor((t+11)/12)*16;case Ia:case ms:case gs:return Math.ceil(e/4)*Math.ceil(t/4)*16;case jo:case _s:return Math.ceil(e/4)*Math.ceil(t/4)*8;case vs:case xs:return Math.ceil(e/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${r} format.`)}function zg(e){switch(e){case dr:case Bo:return{byteLength:1,components:1};case Ki:case zo:case Zi:return{byteLength:2,components:1};case Vn:case Gn:return{byteLength:2,components:4};case Gr:case kn:case Yt:return{byteLength:4,components:1};case Ho:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${e}.`)}function Hg(e,t,r,i,a,n,s){let o=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),u=new Fe,h=new WeakMap,c,d=new WeakMap,m=!1;try{m=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function _(A,y){return m?new OffscreenCanvas(A,y):ta("canvas")}function g(A,y,H){let re=1,ne=Ie(A);if((ne.width>H||ne.height>H)&&(re=H/Math.max(ne.width,ne.height)),re<1)if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap||typeof VideoFrame<"u"&&A instanceof VideoFrame){let ee=Math.floor(re*ne.width),Le=Math.floor(re*ne.height);c===void 0&&(c=_(ee,Le));let pe=y?_(ee,Le):c;return pe.width=ee,pe.height=Le,pe.getContext("2d").drawImage(A,0,0,ee,Le),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+ne.width+"x"+ne.height+") to ("+ee+"x"+Le+")."),pe}else return"data"in A&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+ne.width+"x"+ne.height+")."),A;return A}function f(A){return A.generateMipmaps}function p(A){e.generateMipmap(A)}function x(A){return A.isWebGLCubeRenderTarget?e.TEXTURE_CUBE_MAP:A.isWebGL3DRenderTarget?e.TEXTURE_3D:A.isWebGLArrayRenderTarget||A.isCompressedArrayTexture?e.TEXTURE_2D_ARRAY:e.TEXTURE_2D}function v(A,y,H,re,ne=!1){if(A!==null){if(e[A]!==void 0)return e[A];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let ee=y;if(y===e.RED&&(H===e.FLOAT&&(ee=e.R32F),H===e.HALF_FLOAT&&(ee=e.R16F),H===e.UNSIGNED_BYTE&&(ee=e.R8)),y===e.RED_INTEGER&&(H===e.UNSIGNED_BYTE&&(ee=e.R8UI),H===e.UNSIGNED_SHORT&&(ee=e.R16UI),H===e.UNSIGNED_INT&&(ee=e.R32UI),H===e.BYTE&&(ee=e.R8I),H===e.SHORT&&(ee=e.R16I),H===e.INT&&(ee=e.R32I)),y===e.RG&&(H===e.FLOAT&&(ee=e.RG32F),H===e.HALF_FLOAT&&(ee=e.RG16F),H===e.UNSIGNED_BYTE&&(ee=e.RG8)),y===e.RG_INTEGER&&(H===e.UNSIGNED_BYTE&&(ee=e.RG8UI),H===e.UNSIGNED_SHORT&&(ee=e.RG16UI),H===e.UNSIGNED_INT&&(ee=e.RG32UI),H===e.BYTE&&(ee=e.RG8I),H===e.SHORT&&(ee=e.RG16I),H===e.INT&&(ee=e.RG32I)),y===e.RGB_INTEGER&&(H===e.UNSIGNED_BYTE&&(ee=e.RGB8UI),H===e.UNSIGNED_SHORT&&(ee=e.RGB16UI),H===e.UNSIGNED_INT&&(ee=e.RGB32UI),H===e.BYTE&&(ee=e.RGB8I),H===e.SHORT&&(ee=e.RGB16I),H===e.INT&&(ee=e.RGB32I)),y===e.RGBA_INTEGER&&(H===e.UNSIGNED_BYTE&&(ee=e.RGBA8UI),H===e.UNSIGNED_SHORT&&(ee=e.RGBA16UI),H===e.UNSIGNED_INT&&(ee=e.RGBA32UI),H===e.BYTE&&(ee=e.RGBA8I),H===e.SHORT&&(ee=e.RGBA16I),H===e.INT&&(ee=e.RGBA32I)),y===e.RGB&&H===e.UNSIGNED_INT_5_9_9_9_REV&&(ee=e.RGB9_E5),y===e.RGBA){let Le=ne?Da:Ye.getTransfer(re);H===e.FLOAT&&(ee=e.RGBA32F),H===e.HALF_FLOAT&&(ee=e.RGBA16F),H===e.UNSIGNED_BYTE&&(ee=Le===it?e.SRGB8_ALPHA8:e.RGBA8),H===e.UNSIGNED_SHORT_4_4_4_4&&(ee=e.RGBA4),H===e.UNSIGNED_SHORT_5_5_5_1&&(ee=e.RGB5_A1)}return(ee===e.R16F||ee===e.R32F||ee===e.RG16F||ee===e.RG32F||ee===e.RGBA16F||ee===e.RGBA32F)&&t.get("EXT_color_buffer_float"),ee}function E(A,y){let H;return A?y===null||y===Gr||y===ui?H=e.DEPTH24_STENCIL8:y===Yt?H=e.DEPTH32F_STENCIL8:y===Ki&&(H=e.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):y===null||y===Gr||y===ui?H=e.DEPTH_COMPONENT24:y===Yt?H=e.DEPTH_COMPONENT32F:y===Ki&&(H=e.DEPTH_COMPONENT16),H}function I(A,y){return f(A)===!0||A.isFramebufferTexture&&A.minFilter!==wt&&A.minFilter!==_t?Math.log2(Math.max(y.width,y.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?y.mipmaps.length:1}function w(A){let y=A.target;y.removeEventListener("dispose",w),U(y),y.isVideoTexture&&h.delete(y)}function R(A){let y=A.target;y.removeEventListener("dispose",R),T(y)}function U(A){let y=i.get(A);if(y.__webglInit===void 0)return;let H=A.source,re=d.get(H);if(re){let ne=re[y.__cacheKey];ne.usedTimes--,ne.usedTimes===0&&M(A),Object.keys(re).length===0&&d.delete(H)}i.remove(A)}function M(A){let y=i.get(A);e.deleteTexture(y.__webglTexture);let H=A.source,re=d.get(H);delete re[y.__cacheKey],s.memory.textures--}function T(A){let y=i.get(A);if(A.depthTexture&&(A.depthTexture.dispose(),i.remove(A.depthTexture)),A.isWebGLCubeRenderTarget)for(let re=0;re<6;re++){if(Array.isArray(y.__webglFramebuffer[re]))for(let ne=0;ne<y.__webglFramebuffer[re].length;ne++)e.deleteFramebuffer(y.__webglFramebuffer[re][ne]);else e.deleteFramebuffer(y.__webglFramebuffer[re]);y.__webglDepthbuffer&&e.deleteRenderbuffer(y.__webglDepthbuffer[re])}else{if(Array.isArray(y.__webglFramebuffer))for(let re=0;re<y.__webglFramebuffer.length;re++)e.deleteFramebuffer(y.__webglFramebuffer[re]);else e.deleteFramebuffer(y.__webglFramebuffer);if(y.__webglDepthbuffer&&e.deleteRenderbuffer(y.__webglDepthbuffer),y.__webglMultisampledFramebuffer&&e.deleteFramebuffer(y.__webglMultisampledFramebuffer),y.__webglColorRenderbuffer)for(let re=0;re<y.__webglColorRenderbuffer.length;re++)y.__webglColorRenderbuffer[re]&&e.deleteRenderbuffer(y.__webglColorRenderbuffer[re]);y.__webglDepthRenderbuffer&&e.deleteRenderbuffer(y.__webglDepthRenderbuffer)}let H=A.textures;for(let re=0,ne=H.length;re<ne;re++){let ee=i.get(H[re]);ee.__webglTexture&&(e.deleteTexture(ee.__webglTexture),s.memory.textures--),i.remove(H[re])}i.remove(A)}let P=0;function z(){P=0}function q(){let A=P;return A>=a.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+A+" texture units while this GPU supports only "+a.maxTextures),P+=1,A}function K(A){let y=[];return y.push(A.wrapS),y.push(A.wrapT),y.push(A.wrapR||0),y.push(A.magFilter),y.push(A.minFilter),y.push(A.anisotropy),y.push(A.internalFormat),y.push(A.format),y.push(A.type),y.push(A.generateMipmaps),y.push(A.premultiplyAlpha),y.push(A.flipY),y.push(A.unpackAlignment),y.push(A.colorSpace),y.join()}function Y(A,y){let H=i.get(A);if(A.isVideoTexture&&Ze(A),A.isRenderTargetTexture===!1&&A.version>0&&H.__version!==A.version){let re=A.image;if(re===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(re.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{oe(H,A,y);return}}r.bindTexture(e.TEXTURE_2D,H.__webglTexture,e.TEXTURE0+y)}function W(A,y){let H=i.get(A);if(A.version>0&&H.__version!==A.version){oe(H,A,y);return}r.bindTexture(e.TEXTURE_2D_ARRAY,H.__webglTexture,e.TEXTURE0+y)}function ae(A,y){let H=i.get(A);if(A.version>0&&H.__version!==A.version){oe(H,A,y);return}r.bindTexture(e.TEXTURE_3D,H.__webglTexture,e.TEXTURE0+y)}function Z(A,y){let H=i.get(A);if(A.version>0&&H.__version!==A.version){ge(H,A,y);return}r.bindTexture(e.TEXTURE_CUBE_MAP,H.__webglTexture,e.TEXTURE0+y)}let te={[li]:e.REPEAT,[Ar]:e.CLAMP_TO_EDGE,[wa]:e.MIRRORED_REPEAT},de={[wt]:e.NEAREST,[Fo]:e.NEAREST_MIPMAP_NEAREST,[qi]:e.NEAREST_MIPMAP_LINEAR,[_t]:e.LINEAR,[Aa]:e.LINEAR_MIPMAP_NEAREST,[jt]:e.LINEAR_MIPMAP_LINEAR},Pe={[mc]:e.NEVER,[Mc]:e.ALWAYS,[gc]:e.LESS,[Qo]:e.LEQUAL,[_c]:e.EQUAL,[yc]:e.GEQUAL,[vc]:e.GREATER,[xc]:e.NOTEQUAL};function ve(A,y){if(y.type===Yt&&t.has("OES_texture_float_linear")===!1&&(y.magFilter===_t||y.magFilter===Aa||y.magFilter===qi||y.magFilter===jt||y.minFilter===_t||y.minFilter===Aa||y.minFilter===qi||y.minFilter===jt)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),e.texParameteri(A,e.TEXTURE_WRAP_S,te[y.wrapS]),e.texParameteri(A,e.TEXTURE_WRAP_T,te[y.wrapT]),(A===e.TEXTURE_3D||A===e.TEXTURE_2D_ARRAY)&&e.texParameteri(A,e.TEXTURE_WRAP_R,te[y.wrapR]),e.texParameteri(A,e.TEXTURE_MAG_FILTER,de[y.magFilter]),e.texParameteri(A,e.TEXTURE_MIN_FILTER,de[y.minFilter]),y.compareFunction&&(e.texParameteri(A,e.TEXTURE_COMPARE_MODE,e.COMPARE_REF_TO_TEXTURE),e.texParameteri(A,e.TEXTURE_COMPARE_FUNC,Pe[y.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(y.magFilter===wt||y.minFilter!==qi&&y.minFilter!==jt||y.type===Yt&&t.has("OES_texture_float_linear")===!1)return;if(y.anisotropy>1||i.get(y).__currentAnisotropy){let H=t.get("EXT_texture_filter_anisotropic");e.texParameterf(A,H.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(y.anisotropy,a.getMaxAnisotropy())),i.get(y).__currentAnisotropy=y.anisotropy}}}function $(A,y){let H=!1;A.__webglInit===void 0&&(A.__webglInit=!0,y.addEventListener("dispose",w));let re=y.source,ne=d.get(re);ne===void 0&&(ne={},d.set(re,ne));let ee=K(y);if(ee!==A.__cacheKey){ne[ee]===void 0&&(ne[ee]={texture:e.createTexture(),usedTimes:0},s.memory.textures++,H=!0),ne[ee].usedTimes++;let Le=ne[A.__cacheKey];Le!==void 0&&(ne[A.__cacheKey].usedTimes--,Le.usedTimes===0&&M(y)),A.__cacheKey=ee,A.__webglTexture=ne[ee].texture}return H}function oe(A,y,H){let re=e.TEXTURE_2D;(y.isDataArrayTexture||y.isCompressedArrayTexture)&&(re=e.TEXTURE_2D_ARRAY),y.isData3DTexture&&(re=e.TEXTURE_3D);let ne=$(A,y),ee=y.source;r.bindTexture(re,A.__webglTexture,e.TEXTURE0+H);let Le=i.get(ee);if(ee.version!==Le.__version||ne===!0){r.activeTexture(e.TEXTURE0+H);let pe=Ye.getPrimaries(Ye.workingColorSpace),xe=y.colorSpace===Rr?null:Ye.getPrimaries(y.colorSpace),Be=y.colorSpace===Rr||pe===xe?e.NONE:e.BROWSER_DEFAULT_WEBGL;e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,y.flipY),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,y.premultiplyAlpha),e.pixelStorei(e.UNPACK_ALIGNMENT,y.unpackAlignment),e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,Be);let ue=g(y.image,!1,a.maxTextureSize);ue=we(y,ue);let me=n.convert(y.format,y.colorSpace),N=n.convert(y.type),j=v(y.internalFormat,me,N,y.colorSpace,y.isVideoTexture);ve(re,y);let B,Q=y.mipmaps,se=y.isVideoTexture!==!0,Me=Le.__version===void 0||ne===!0,C=ee.dataReady,k=I(y,ue);if(y.isDepthTexture)j=E(y.format===ci,y.type),Me&&(se?r.texStorage2D(e.TEXTURE_2D,1,j,ue.width,ue.height):r.texImage2D(e.TEXTURE_2D,0,j,ue.width,ue.height,0,me,N,null));else if(y.isDataTexture)if(Q.length>0){se&&Me&&r.texStorage2D(e.TEXTURE_2D,k,j,Q[0].width,Q[0].height);for(let b=0,V=Q.length;b<V;b++)B=Q[b],se?C&&r.texSubImage2D(e.TEXTURE_2D,b,0,0,B.width,B.height,me,N,B.data):r.texImage2D(e.TEXTURE_2D,b,j,B.width,B.height,0,me,N,B.data);y.generateMipmaps=!1}else se?(Me&&r.texStorage2D(e.TEXTURE_2D,k,j,ue.width,ue.height),C&&r.texSubImage2D(e.TEXTURE_2D,0,0,0,ue.width,ue.height,me,N,ue.data)):r.texImage2D(e.TEXTURE_2D,0,j,ue.width,ue.height,0,me,N,ue.data);else if(y.isCompressedTexture)if(y.isCompressedArrayTexture){se&&Me&&r.texStorage3D(e.TEXTURE_2D_ARRAY,k,j,Q[0].width,Q[0].height,ue.depth);for(let b=0,V=Q.length;b<V;b++)if(B=Q[b],y.format!==kt)if(me!==null)if(se){if(C)if(y.layerUpdates.size>0){let J=lu(B.width,B.height,y.format,y.type);for(let ie of y.layerUpdates){let Se=B.data.subarray(ie*J/B.data.BYTES_PER_ELEMENT,(ie+1)*J/B.data.BYTES_PER_ELEMENT);r.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,b,0,0,ie,B.width,B.height,1,me,Se)}y.clearLayerUpdates()}else r.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,b,0,0,0,B.width,B.height,ue.depth,me,B.data)}else r.compressedTexImage3D(e.TEXTURE_2D_ARRAY,b,j,B.width,B.height,ue.depth,0,B.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else se?C&&r.texSubImage3D(e.TEXTURE_2D_ARRAY,b,0,0,0,B.width,B.height,ue.depth,me,N,B.data):r.texImage3D(e.TEXTURE_2D_ARRAY,b,j,B.width,B.height,ue.depth,0,me,N,B.data)}else{se&&Me&&r.texStorage2D(e.TEXTURE_2D,k,j,Q[0].width,Q[0].height);for(let b=0,V=Q.length;b<V;b++)B=Q[b],y.format!==kt?me!==null?se?C&&r.compressedTexSubImage2D(e.TEXTURE_2D,b,0,0,B.width,B.height,me,B.data):r.compressedTexImage2D(e.TEXTURE_2D,b,j,B.width,B.height,0,B.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):se?C&&r.texSubImage2D(e.TEXTURE_2D,b,0,0,B.width,B.height,me,N,B.data):r.texImage2D(e.TEXTURE_2D,b,j,B.width,B.height,0,me,N,B.data)}else if(y.isDataArrayTexture)if(se){if(Me&&r.texStorage3D(e.TEXTURE_2D_ARRAY,k,j,ue.width,ue.height,ue.depth),C)if(y.layerUpdates.size>0){let b=lu(ue.width,ue.height,y.format,y.type);for(let V of y.layerUpdates){let J=ue.data.subarray(V*b/ue.data.BYTES_PER_ELEMENT,(V+1)*b/ue.data.BYTES_PER_ELEMENT);r.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,V,ue.width,ue.height,1,me,N,J)}y.clearLayerUpdates()}else r.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,0,ue.width,ue.height,ue.depth,me,N,ue.data)}else r.texImage3D(e.TEXTURE_2D_ARRAY,0,j,ue.width,ue.height,ue.depth,0,me,N,ue.data);else if(y.isData3DTexture)se?(Me&&r.texStorage3D(e.TEXTURE_3D,k,j,ue.width,ue.height,ue.depth),C&&r.texSubImage3D(e.TEXTURE_3D,0,0,0,0,ue.width,ue.height,ue.depth,me,N,ue.data)):r.texImage3D(e.TEXTURE_3D,0,j,ue.width,ue.height,ue.depth,0,me,N,ue.data);else if(y.isFramebufferTexture){if(Me)if(se)r.texStorage2D(e.TEXTURE_2D,k,j,ue.width,ue.height);else{let b=ue.width,V=ue.height;for(let J=0;J<k;J++)r.texImage2D(e.TEXTURE_2D,J,j,b,V,0,me,N,null),b>>=1,V>>=1}}else if(Q.length>0){if(se&&Me){let b=Ie(Q[0]);r.texStorage2D(e.TEXTURE_2D,k,j,b.width,b.height)}for(let b=0,V=Q.length;b<V;b++)B=Q[b],se?C&&r.texSubImage2D(e.TEXTURE_2D,b,0,0,me,N,B):r.texImage2D(e.TEXTURE_2D,b,j,me,N,B);y.generateMipmaps=!1}else if(se){if(Me){let b=Ie(ue);r.texStorage2D(e.TEXTURE_2D,k,j,b.width,b.height)}C&&r.texSubImage2D(e.TEXTURE_2D,0,0,0,me,N,ue)}else r.texImage2D(e.TEXTURE_2D,0,j,me,N,ue);f(y)&&p(re),Le.__version=ee.version,y.onUpdate&&y.onUpdate(y)}A.__version=y.version}function ge(A,y,H){if(y.image.length!==6)return;let re=$(A,y),ne=y.source;r.bindTexture(e.TEXTURE_CUBE_MAP,A.__webglTexture,e.TEXTURE0+H);let ee=i.get(ne);if(ne.version!==ee.__version||re===!0){r.activeTexture(e.TEXTURE0+H);let Le=Ye.getPrimaries(Ye.workingColorSpace),pe=y.colorSpace===Rr?null:Ye.getPrimaries(y.colorSpace),xe=y.colorSpace===Rr||Le===pe?e.NONE:e.BROWSER_DEFAULT_WEBGL;e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,y.flipY),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,y.premultiplyAlpha),e.pixelStorei(e.UNPACK_ALIGNMENT,y.unpackAlignment),e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,xe);let Be=y.isCompressedTexture||y.image[0].isCompressedTexture,ue=y.image[0]&&y.image[0].isDataTexture,me=[];for(let V=0;V<6;V++)!Be&&!ue?me[V]=g(y.image[V],!0,a.maxCubemapSize):me[V]=ue?y.image[V].image:y.image[V],me[V]=we(y,me[V]);let N=me[0],j=n.convert(y.format,y.colorSpace),B=n.convert(y.type),Q=v(y.internalFormat,j,B,y.colorSpace),se=y.isVideoTexture!==!0,Me=ee.__version===void 0||re===!0,C=ne.dataReady,k=I(y,N);ve(e.TEXTURE_CUBE_MAP,y);let b;if(Be){se&&Me&&r.texStorage2D(e.TEXTURE_CUBE_MAP,k,Q,N.width,N.height);for(let V=0;V<6;V++){b=me[V].mipmaps;for(let J=0;J<b.length;J++){let ie=b[J];y.format!==kt?j!==null?se?C&&r.compressedTexSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+V,J,0,0,ie.width,ie.height,j,ie.data):r.compressedTexImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+V,J,Q,ie.width,ie.height,0,ie.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):se?C&&r.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+V,J,0,0,ie.width,ie.height,j,B,ie.data):r.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+V,J,Q,ie.width,ie.height,0,j,B,ie.data)}}}else{if(b=y.mipmaps,se&&Me){b.length>0&&k++;let V=Ie(me[0]);r.texStorage2D(e.TEXTURE_CUBE_MAP,k,Q,V.width,V.height)}for(let V=0;V<6;V++)if(ue){se?C&&r.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+V,0,0,0,me[V].width,me[V].height,j,B,me[V].data):r.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+V,0,Q,me[V].width,me[V].height,0,j,B,me[V].data);for(let J=0;J<b.length;J++){let ie=b[J].image[V].image;se?C&&r.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+V,J+1,0,0,ie.width,ie.height,j,B,ie.data):r.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+V,J+1,Q,ie.width,ie.height,0,j,B,ie.data)}}else{se?C&&r.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+V,0,0,0,j,B,me[V]):r.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+V,0,Q,j,B,me[V]);for(let J=0;J<b.length;J++){let ie=b[J];se?C&&r.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+V,J+1,0,0,j,B,ie.image[V]):r.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+V,J+1,Q,j,B,ie.image[V])}}}f(y)&&p(e.TEXTURE_CUBE_MAP),ee.__version=ne.version,y.onUpdate&&y.onUpdate(y)}A.__version=y.version}function Ee(A,y,H,re,ne,ee){let Le=n.convert(H.format,H.colorSpace),pe=n.convert(H.type),xe=v(H.internalFormat,Le,pe,H.colorSpace),Be=i.get(y),ue=i.get(H);if(ue.__renderTarget=y,!Be.__hasExternalTextures){let me=Math.max(1,y.width>>ee),N=Math.max(1,y.height>>ee);ne===e.TEXTURE_3D||ne===e.TEXTURE_2D_ARRAY?r.texImage3D(ne,ee,xe,me,N,y.depth,0,Le,pe,null):r.texImage2D(ne,ee,xe,me,N,0,Le,pe,null)}r.bindFramebuffer(e.FRAMEBUFFER,A),ye(y)?o.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,re,ne,ue.__webglTexture,0,Qe(y)):(ne===e.TEXTURE_2D||ne>=e.TEXTURE_CUBE_MAP_POSITIVE_X&&ne<=e.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&e.framebufferTexture2D(e.FRAMEBUFFER,re,ne,ue.__webglTexture,ee),r.bindFramebuffer(e.FRAMEBUFFER,null)}function he(A,y,H){if(e.bindRenderbuffer(e.RENDERBUFFER,A),y.depthBuffer){let re=y.depthTexture,ne=re&&re.isDepthTexture?re.type:null,ee=E(y.stencilBuffer,ne),Le=y.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,pe=Qe(y);ye(y)?o.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,pe,ee,y.width,y.height):H?e.renderbufferStorageMultisample(e.RENDERBUFFER,pe,ee,y.width,y.height):e.renderbufferStorage(e.RENDERBUFFER,ee,y.width,y.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,Le,e.RENDERBUFFER,A)}else{let re=y.textures;for(let ne=0;ne<re.length;ne++){let ee=re[ne],Le=n.convert(ee.format,ee.colorSpace),pe=n.convert(ee.type),xe=v(ee.internalFormat,Le,pe,ee.colorSpace),Be=Qe(y);H&&ye(y)===!1?e.renderbufferStorageMultisample(e.RENDERBUFFER,Be,xe,y.width,y.height):ye(y)?o.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,Be,xe,y.width,y.height):e.renderbufferStorage(e.RENDERBUFFER,xe,y.width,y.height)}}e.bindRenderbuffer(e.RENDERBUFFER,null)}function Ce(A,y){if(y&&y.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(r.bindFramebuffer(e.FRAMEBUFFER,A),!(y.depthTexture&&y.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");let H=i.get(y.depthTexture);H.__renderTarget=y,(!H.__webglTexture||y.depthTexture.image.width!==y.width||y.depthTexture.image.height!==y.height)&&(y.depthTexture.image.width=y.width,y.depthTexture.image.height=y.height,y.depthTexture.needsUpdate=!0),Y(y.depthTexture,0);let re=H.__webglTexture,ne=Qe(y);if(y.depthTexture.format===hi)ye(y)?o.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,e.DEPTH_ATTACHMENT,e.TEXTURE_2D,re,0,ne):e.framebufferTexture2D(e.FRAMEBUFFER,e.DEPTH_ATTACHMENT,e.TEXTURE_2D,re,0);else if(y.depthTexture.format===ci)ye(y)?o.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,e.DEPTH_STENCIL_ATTACHMENT,e.TEXTURE_2D,re,0,ne):e.framebufferTexture2D(e.FRAMEBUFFER,e.DEPTH_STENCIL_ATTACHMENT,e.TEXTURE_2D,re,0);else throw new Error("Unknown depthTexture format")}function Ke(A){let y=i.get(A),H=A.isWebGLCubeRenderTarget===!0;if(y.__boundDepthTexture!==A.depthTexture){let re=A.depthTexture;if(y.__depthDisposeCallback&&y.__depthDisposeCallback(),re){let ne=()=>{delete y.__boundDepthTexture,delete y.__depthDisposeCallback,re.removeEventListener("dispose",ne)};re.addEventListener("dispose",ne),y.__depthDisposeCallback=ne}y.__boundDepthTexture=re}if(A.depthTexture&&!y.__autoAllocateDepthBuffer){if(H)throw new Error("target.depthTexture not supported in Cube render targets");Ce(y.__webglFramebuffer,A)}else if(H){y.__webglDepthbuffer=[];for(let re=0;re<6;re++)if(r.bindFramebuffer(e.FRAMEBUFFER,y.__webglFramebuffer[re]),y.__webglDepthbuffer[re]===void 0)y.__webglDepthbuffer[re]=e.createRenderbuffer(),he(y.__webglDepthbuffer[re],A,!1);else{let ne=A.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,ee=y.__webglDepthbuffer[re];e.bindRenderbuffer(e.RENDERBUFFER,ee),e.framebufferRenderbuffer(e.FRAMEBUFFER,ne,e.RENDERBUFFER,ee)}}else if(r.bindFramebuffer(e.FRAMEBUFFER,y.__webglFramebuffer),y.__webglDepthbuffer===void 0)y.__webglDepthbuffer=e.createRenderbuffer(),he(y.__webglDepthbuffer,A,!1);else{let re=A.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,ne=y.__webglDepthbuffer;e.bindRenderbuffer(e.RENDERBUFFER,ne),e.framebufferRenderbuffer(e.FRAMEBUFFER,re,e.RENDERBUFFER,ne)}r.bindFramebuffer(e.FRAMEBUFFER,null)}function Xe(A,y,H){let re=i.get(A);y!==void 0&&Ee(re.__webglFramebuffer,A,A.texture,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,0),H!==void 0&&Ke(A)}function qe(A){let y=A.texture,H=i.get(A),re=i.get(y);A.addEventListener("dispose",R);let ne=A.textures,ee=A.isWebGLCubeRenderTarget===!0,Le=ne.length>1;if(Le||(re.__webglTexture===void 0&&(re.__webglTexture=e.createTexture()),re.__version=y.version,s.memory.textures++),ee){H.__webglFramebuffer=[];for(let pe=0;pe<6;pe++)if(y.mipmaps&&y.mipmaps.length>0){H.__webglFramebuffer[pe]=[];for(let xe=0;xe<y.mipmaps.length;xe++)H.__webglFramebuffer[pe][xe]=e.createFramebuffer()}else H.__webglFramebuffer[pe]=e.createFramebuffer()}else{if(y.mipmaps&&y.mipmaps.length>0){H.__webglFramebuffer=[];for(let pe=0;pe<y.mipmaps.length;pe++)H.__webglFramebuffer[pe]=e.createFramebuffer()}else H.__webglFramebuffer=e.createFramebuffer();if(Le)for(let pe=0,xe=ne.length;pe<xe;pe++){let Be=i.get(ne[pe]);Be.__webglTexture===void 0&&(Be.__webglTexture=e.createTexture(),s.memory.textures++)}if(A.samples>0&&ye(A)===!1){H.__webglMultisampledFramebuffer=e.createFramebuffer(),H.__webglColorRenderbuffer=[],r.bindFramebuffer(e.FRAMEBUFFER,H.__webglMultisampledFramebuffer);for(let pe=0;pe<ne.length;pe++){let xe=ne[pe];H.__webglColorRenderbuffer[pe]=e.createRenderbuffer(),e.bindRenderbuffer(e.RENDERBUFFER,H.__webglColorRenderbuffer[pe]);let Be=n.convert(xe.format,xe.colorSpace),ue=n.convert(xe.type),me=v(xe.internalFormat,Be,ue,xe.colorSpace,A.isXRRenderTarget===!0),N=Qe(A);e.renderbufferStorageMultisample(e.RENDERBUFFER,N,me,A.width,A.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+pe,e.RENDERBUFFER,H.__webglColorRenderbuffer[pe])}e.bindRenderbuffer(e.RENDERBUFFER,null),A.depthBuffer&&(H.__webglDepthRenderbuffer=e.createRenderbuffer(),he(H.__webglDepthRenderbuffer,A,!0)),r.bindFramebuffer(e.FRAMEBUFFER,null)}}if(ee){r.bindTexture(e.TEXTURE_CUBE_MAP,re.__webglTexture),ve(e.TEXTURE_CUBE_MAP,y);for(let pe=0;pe<6;pe++)if(y.mipmaps&&y.mipmaps.length>0)for(let xe=0;xe<y.mipmaps.length;xe++)Ee(H.__webglFramebuffer[pe][xe],A,y,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+pe,xe);else Ee(H.__webglFramebuffer[pe],A,y,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+pe,0);f(y)&&p(e.TEXTURE_CUBE_MAP),r.unbindTexture()}else if(Le){for(let pe=0,xe=ne.length;pe<xe;pe++){let Be=ne[pe],ue=i.get(Be);r.bindTexture(e.TEXTURE_2D,ue.__webglTexture),ve(e.TEXTURE_2D,Be),Ee(H.__webglFramebuffer,A,Be,e.COLOR_ATTACHMENT0+pe,e.TEXTURE_2D,0),f(Be)&&p(e.TEXTURE_2D)}r.unbindTexture()}else{let pe=e.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(pe=A.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),r.bindTexture(pe,re.__webglTexture),ve(pe,y),y.mipmaps&&y.mipmaps.length>0)for(let xe=0;xe<y.mipmaps.length;xe++)Ee(H.__webglFramebuffer[xe],A,y,e.COLOR_ATTACHMENT0,pe,xe);else Ee(H.__webglFramebuffer,A,y,e.COLOR_ATTACHMENT0,pe,0);f(y)&&p(pe),r.unbindTexture()}A.depthBuffer&&Ke(A)}function mt(A){let y=A.textures;for(let H=0,re=y.length;H<re;H++){let ne=y[H];if(f(ne)){let ee=x(A),Le=i.get(ne).__webglTexture;r.bindTexture(ee,Le),p(ee),r.unbindTexture()}}}let O=[],pt=[];function Je(A){if(A.samples>0){if(ye(A)===!1){let y=A.textures,H=A.width,re=A.height,ne=e.COLOR_BUFFER_BIT,ee=A.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,Le=i.get(A),pe=y.length>1;if(pe)for(let xe=0;xe<y.length;xe++)r.bindFramebuffer(e.FRAMEBUFFER,Le.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+xe,e.RENDERBUFFER,null),r.bindFramebuffer(e.FRAMEBUFFER,Le.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+xe,e.TEXTURE_2D,null,0);r.bindFramebuffer(e.READ_FRAMEBUFFER,Le.__webglMultisampledFramebuffer),r.bindFramebuffer(e.DRAW_FRAMEBUFFER,Le.__webglFramebuffer);for(let xe=0;xe<y.length;xe++){if(A.resolveDepthBuffer&&(A.depthBuffer&&(ne|=e.DEPTH_BUFFER_BIT),A.stencilBuffer&&A.resolveStencilBuffer&&(ne|=e.STENCIL_BUFFER_BIT)),pe){e.framebufferRenderbuffer(e.READ_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.RENDERBUFFER,Le.__webglColorRenderbuffer[xe]);let Be=i.get(y[xe]).__webglTexture;e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,Be,0)}e.blitFramebuffer(0,0,H,re,0,0,H,re,ne,e.NEAREST),l===!0&&(O.length=0,pt.length=0,O.push(e.COLOR_ATTACHMENT0+xe),A.depthBuffer&&A.resolveDepthBuffer===!1&&(O.push(ee),pt.push(ee),e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,pt)),e.invalidateFramebuffer(e.READ_FRAMEBUFFER,O))}if(r.bindFramebuffer(e.READ_FRAMEBUFFER,null),r.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),pe)for(let xe=0;xe<y.length;xe++){r.bindFramebuffer(e.FRAMEBUFFER,Le.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+xe,e.RENDERBUFFER,Le.__webglColorRenderbuffer[xe]);let Be=i.get(y[xe]).__webglTexture;r.bindFramebuffer(e.FRAMEBUFFER,Le.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+xe,e.TEXTURE_2D,Be,0)}r.bindFramebuffer(e.DRAW_FRAMEBUFFER,Le.__webglMultisampledFramebuffer)}else if(A.depthBuffer&&A.resolveDepthBuffer===!1&&l){let y=A.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,[y])}}}function Qe(A){return Math.min(a.maxSamples,A.samples)}function ye(A){let y=i.get(A);return A.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&y.__useRenderToTexture!==!1}function Ze(A){let y=s.render.frame;h.get(A)!==y&&(h.set(A,y),A.update())}function we(A,y){let H=A.colorSpace,re=A.format,ne=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||H!==At&&H!==Rr&&(Ye.getTransfer(H)===it?(re!==kt||ne!==dr)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",H)),y}function Ie(A){return typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement?(u.width=A.naturalWidth||A.width,u.height=A.naturalHeight||A.height):typeof VideoFrame<"u"&&A instanceof VideoFrame?(u.width=A.displayWidth,u.height=A.displayHeight):(u.width=A.width,u.height=A.height),u}this.allocateTextureUnit=q,this.resetTextureUnits=z,this.setTexture2D=Y,this.setTexture2DArray=W,this.setTexture3D=ae,this.setTextureCube=Z,this.rebindTextures=Xe,this.setupRenderTarget=qe,this.updateRenderTargetMipmap=mt,this.updateMultisampleRenderTarget=Je,this.setupDepthRenderbuffer=Ke,this.setupFrameBufferTexture=Ee,this.useMultisampledRTT=ye}function kg(e,t){function r(i,a=Rr){let n,s=Ye.getTransfer(a);if(i===dr)return e.UNSIGNED_BYTE;if(i===Vn)return e.UNSIGNED_SHORT_4_4_4_4;if(i===Gn)return e.UNSIGNED_SHORT_5_5_5_1;if(i===Ho)return e.UNSIGNED_INT_5_9_9_9_REV;if(i===Bo)return e.BYTE;if(i===zo)return e.SHORT;if(i===Ki)return e.UNSIGNED_SHORT;if(i===kn)return e.INT;if(i===Gr)return e.UNSIGNED_INT;if(i===Yt)return e.FLOAT;if(i===Zi)return e.HALF_FLOAT;if(i===ko)return e.ALPHA;if(i===Vo)return e.RGB;if(i===kt)return e.RGBA;if(i===Go)return e.LUMINANCE;if(i===Wo)return e.LUMINANCE_ALPHA;if(i===hi)return e.DEPTH_COMPONENT;if(i===ci)return e.DEPTH_STENCIL;if(i===Wn)return e.RED;if(i===Xn)return e.RED_INTEGER;if(i===Xo)return e.RG;if(i===jn)return e.RG_INTEGER;if(i===Yn)return e.RGBA_INTEGER;if(i===Ra||i===Ca||i===La||i===Pa)if(s===it)if(n=t.get("WEBGL_compressed_texture_s3tc_srgb"),n!==null){if(i===Ra)return n.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(i===Ca)return n.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(i===La)return n.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(i===Pa)return n.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(n=t.get("WEBGL_compressed_texture_s3tc"),n!==null){if(i===Ra)return n.COMPRESSED_RGB_S3TC_DXT1_EXT;if(i===Ca)return n.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(i===La)return n.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(i===Pa)return n.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(i===qn||i===Kn||i===Zn||i===$n)if(n=t.get("WEBGL_compressed_texture_pvrtc"),n!==null){if(i===qn)return n.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(i===Kn)return n.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(i===Zn)return n.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(i===$n)return n.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(i===Jn||i===Qn||i===es)if(n=t.get("WEBGL_compressed_texture_etc"),n!==null){if(i===Jn||i===Qn)return s===it?n.COMPRESSED_SRGB8_ETC2:n.COMPRESSED_RGB8_ETC2;if(i===es)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:n.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(i===ts||i===rs||i===is||i===as||i===ns||i===ss||i===os||i===ls||i===us||i===hs||i===cs||i===ds||i===ps||i===fs)if(n=t.get("WEBGL_compressed_texture_astc"),n!==null){if(i===ts)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:n.COMPRESSED_RGBA_ASTC_4x4_KHR;if(i===rs)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:n.COMPRESSED_RGBA_ASTC_5x4_KHR;if(i===is)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:n.COMPRESSED_RGBA_ASTC_5x5_KHR;if(i===as)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:n.COMPRESSED_RGBA_ASTC_6x5_KHR;if(i===ns)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:n.COMPRESSED_RGBA_ASTC_6x6_KHR;if(i===ss)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:n.COMPRESSED_RGBA_ASTC_8x5_KHR;if(i===os)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:n.COMPRESSED_RGBA_ASTC_8x6_KHR;if(i===ls)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:n.COMPRESSED_RGBA_ASTC_8x8_KHR;if(i===us)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:n.COMPRESSED_RGBA_ASTC_10x5_KHR;if(i===hs)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:n.COMPRESSED_RGBA_ASTC_10x6_KHR;if(i===cs)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:n.COMPRESSED_RGBA_ASTC_10x8_KHR;if(i===ds)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:n.COMPRESSED_RGBA_ASTC_10x10_KHR;if(i===ps)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:n.COMPRESSED_RGBA_ASTC_12x10_KHR;if(i===fs)return s===it?n.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:n.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(i===Ia||i===ms||i===gs)if(n=t.get("EXT_texture_compression_bptc"),n!==null){if(i===Ia)return s===it?n.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:n.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(i===ms)return n.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(i===gs)return n.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(i===jo||i===_s||i===vs||i===xs)if(n=t.get("EXT_texture_compression_rgtc"),n!==null){if(i===Ia)return n.COMPRESSED_RED_RGTC1_EXT;if(i===_s)return n.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(i===vs)return n.COMPRESSED_RED_GREEN_RGTC2_EXT;if(i===xs)return n.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return i===ui?e.UNSIGNED_INT_24_8:e[i]!==void 0?e[i]:null}return{convert:r}}var Vg=class extends Lt{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}},nr=class extends ct{constructor(){super(),this.isGroup=!0,this.type="Group"}},Gg={type:"move"},to=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new nr,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new nr,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new L,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new L),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new nr,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new L,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new L),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let r of e.hand.values())this._getHandJoint(t,r)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,r){let i=null,a=null,n=null,s=this._targetRay,o=this._grip,l=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(l&&e.hand){n=!0;for(let _ of e.hand.values()){let g=t.getJointPose(_,r),f=this._getHandJoint(l,_);g!==null&&(f.matrix.fromArray(g.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=g.radius),f.visible=g!==null}let u=l.joints["index-finger-tip"],h=l.joints["thumb-tip"],c=u.position.distanceTo(h.position),d=.02,m=.005;l.inputState.pinching&&c>d+m?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!l.inputState.pinching&&c<=d-m&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else o!==null&&e.gripSpace&&(a=t.getPose(e.gripSpace,r),a!==null&&(o.matrix.fromArray(a.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,a.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(a.linearVelocity)):o.hasLinearVelocity=!1,a.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(a.angularVelocity)):o.hasAngularVelocity=!1));s!==null&&(i=t.getPose(e.targetRaySpace,r),i===null&&a!==null&&(i=a),i!==null&&(s.matrix.fromArray(i.transform.matrix),s.matrix.decompose(s.position,s.rotation,s.scale),s.matrixWorldNeedsUpdate=!0,i.linearVelocity?(s.hasLinearVelocity=!0,s.linearVelocity.copy(i.linearVelocity)):s.hasLinearVelocity=!1,i.angularVelocity?(s.hasAngularVelocity=!0,s.angularVelocity.copy(i.angularVelocity)):s.hasAngularVelocity=!1,this.dispatchEvent(Gg)))}return s!==null&&(s.visible=i!==null),o!==null&&(o.visible=a!==null),l!==null&&(l.visible=n!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let r=new nr;r.matrixAutoUpdate=!1,r.visible=!1,e.joints[t.jointName]=r,e.add(r)}return e.joints[t.jointName]}},Wg=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Xg=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,jg=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t,r){if(this.texture===null){let i=new Et,a=e.properties.get(i);a.__webglTexture=t.texture,(t.depthNear!=r.depthNear||t.depthFar!=r.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=i}}getMesh(e){if(this.texture!==null&&this.mesh===null){let t=e.cameras[0].viewport,r=new Or({vertexShader:Wg,fragmentShader:Xg,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new ut(new js(20,20),r)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},Yg=class extends pi{constructor(e,t){super();let r=this,i=null,a=1,n=null,s="local-floor",o=1,l=null,u=null,h=null,c=null,d=null,m=null,_=new jg,g=t.getContextAttributes(),f=null,p=null,x=[],v=[],E=new Fe,I=null,w=new Lt;w.viewport=new tt;let R=new Lt;R.viewport=new tt;let U=[w,R],M=new Vg,T=null,P=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function($){let oe=x[$];return oe===void 0&&(oe=new to,x[$]=oe),oe.getTargetRaySpace()},this.getControllerGrip=function($){let oe=x[$];return oe===void 0&&(oe=new to,x[$]=oe),oe.getGripSpace()},this.getHand=function($){let oe=x[$];return oe===void 0&&(oe=new to,x[$]=oe),oe.getHandSpace()};function z($){let oe=v.indexOf($.inputSource);if(oe===-1)return;let ge=x[oe];ge!==void 0&&(ge.update($.inputSource,$.frame,l||n),ge.dispatchEvent({type:$.type,data:$.inputSource}))}function q(){i.removeEventListener("select",z),i.removeEventListener("selectstart",z),i.removeEventListener("selectend",z),i.removeEventListener("squeeze",z),i.removeEventListener("squeezestart",z),i.removeEventListener("squeezeend",z),i.removeEventListener("end",q),i.removeEventListener("inputsourceschange",K);for(let $=0;$<x.length;$++){let oe=v[$];oe!==null&&(v[$]=null,x[$].disconnect(oe))}T=null,P=null,_.reset(),e.setRenderTarget(f),d=null,c=null,h=null,i=null,p=null,ve.stop(),r.isPresenting=!1,e.setPixelRatio(I),e.setSize(E.width,E.height,!1),r.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function($){a=$,r.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function($){s=$,r.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||n},this.setReferenceSpace=function($){l=$},this.getBaseLayer=function(){return c!==null?c:d},this.getBinding=function(){return h},this.getFrame=function(){return m},this.getSession=function(){return i},this.setSession=async function($){if(i=$,i!==null){if(f=e.getRenderTarget(),i.addEventListener("select",z),i.addEventListener("selectstart",z),i.addEventListener("selectend",z),i.addEventListener("squeeze",z),i.addEventListener("squeezestart",z),i.addEventListener("squeezeend",z),i.addEventListener("end",q),i.addEventListener("inputsourceschange",K),g.xrCompatible!==!0&&await t.makeXRCompatible(),I=e.getPixelRatio(),e.getSize(E),i.renderState.layers===void 0){let oe={antialias:g.antialias,alpha:!0,depth:g.depth,stencil:g.stencil,framebufferScaleFactor:a};d=new XRWebGLLayer(i,t,oe),i.updateRenderState({baseLayer:d}),e.setPixelRatio(1),e.setSize(d.framebufferWidth,d.framebufferHeight,!1),p=new Wr(d.framebufferWidth,d.framebufferHeight,{format:kt,type:dr,colorSpace:e.outputColorSpace,stencilBuffer:g.stencil})}else{let oe=null,ge=null,Ee=null;g.depth&&(Ee=g.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,oe=g.stencil?ci:hi,ge=g.stencil?ui:Gr);let he={colorFormat:t.RGBA8,depthFormat:Ee,scaleFactor:a};h=new XRWebGLBinding(i,t),c=h.createProjectionLayer(he),i.updateRenderState({layers:[c]}),e.setPixelRatio(1),e.setSize(c.textureWidth,c.textureHeight,!1),p=new Wr(c.textureWidth,c.textureHeight,{format:kt,type:dr,depthTexture:new Hl(c.textureWidth,c.textureHeight,ge,void 0,void 0,void 0,void 0,void 0,void 0,oe),stencilBuffer:g.stencil,colorSpace:e.outputColorSpace,samples:g.antialias?4:0,resolveDepthBuffer:c.ignoreDepthValues===!1})}p.isXRRenderTarget=!0,this.setFoveation(o),l=null,n=await i.requestReferenceSpace(s),ve.setContext(i),ve.start(),r.isPresenting=!0,r.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode},this.getDepthTexture=function(){return _.getDepthTexture()};function K($){for(let oe=0;oe<$.removed.length;oe++){let ge=$.removed[oe],Ee=v.indexOf(ge);Ee>=0&&(v[Ee]=null,x[Ee].disconnect(ge))}for(let oe=0;oe<$.added.length;oe++){let ge=$.added[oe],Ee=v.indexOf(ge);if(Ee===-1){for(let Ce=0;Ce<x.length;Ce++)if(Ce>=v.length){v.push(ge),Ee=Ce;break}else if(v[Ce]===null){v[Ce]=ge,Ee=Ce;break}if(Ee===-1)break}let he=x[Ee];he&&he.connect(ge)}}let Y=new L,W=new L;function ae($,oe,ge){Y.setFromMatrixPosition(oe.matrixWorld),W.setFromMatrixPosition(ge.matrixWorld);let Ee=Y.distanceTo(W),he=oe.projectionMatrix.elements,Ce=ge.projectionMatrix.elements,Ke=he[14]/(he[10]-1),Xe=he[14]/(he[10]+1),qe=(he[9]+1)/he[5],mt=(he[9]-1)/he[5],O=(he[8]-1)/he[0],pt=(Ce[8]+1)/Ce[0],Je=Ke*O,Qe=Ke*pt,ye=Ee/(-O+pt),Ze=ye*-O;if(oe.matrixWorld.decompose($.position,$.quaternion,$.scale),$.translateX(Ze),$.translateZ(ye),$.matrixWorld.compose($.position,$.quaternion,$.scale),$.matrixWorldInverse.copy($.matrixWorld).invert(),he[10]===-1)$.projectionMatrix.copy(oe.projectionMatrix),$.projectionMatrixInverse.copy(oe.projectionMatrixInverse);else{let we=Ke+ye,Ie=Xe+ye,A=Je-Ze,y=Qe+(Ee-Ze),H=qe*Xe/Ie*we,re=mt*Xe/Ie*we;$.projectionMatrix.makePerspective(A,y,H,re,we,Ie),$.projectionMatrixInverse.copy($.projectionMatrix).invert()}}function Z($,oe){oe===null?$.matrixWorld.copy($.matrix):$.matrixWorld.multiplyMatrices(oe.matrixWorld,$.matrix),$.matrixWorldInverse.copy($.matrixWorld).invert()}this.updateCamera=function($){if(i===null)return;let oe=$.near,ge=$.far;_.texture!==null&&(_.depthNear>0&&(oe=_.depthNear),_.depthFar>0&&(ge=_.depthFar)),M.near=R.near=w.near=oe,M.far=R.far=w.far=ge,(T!==M.near||P!==M.far)&&(i.updateRenderState({depthNear:M.near,depthFar:M.far}),T=M.near,P=M.far),w.layers.mask=$.layers.mask|2,R.layers.mask=$.layers.mask|4,M.layers.mask=w.layers.mask|R.layers.mask;let Ee=$.parent,he=M.cameras;Z(M,Ee);for(let Ce=0;Ce<he.length;Ce++)Z(he[Ce],Ee);he.length===2?ae(M,w,R):M.projectionMatrix.copy(w.projectionMatrix),te($,M,Ee)};function te($,oe,ge){ge===null?$.matrix.copy(oe.matrixWorld):($.matrix.copy(ge.matrixWorld),$.matrix.invert(),$.matrix.multiply(oe.matrixWorld)),$.matrix.decompose($.position,$.quaternion,$.scale),$.updateMatrixWorld(!0),$.projectionMatrix.copy(oe.projectionMatrix),$.projectionMatrixInverse.copy(oe.projectionMatrixInverse),$.isPerspectiveCamera&&($.fov=fi*2*Math.atan(1/$.projectionMatrix.elements[5]),$.zoom=1)}this.getCamera=function(){return M},this.getFoveation=function(){if(!(c===null&&d===null))return o},this.setFoveation=function($){o=$,c!==null&&(c.fixedFoveation=$),d!==null&&d.fixedFoveation!==void 0&&(d.fixedFoveation=$)},this.hasDepthSensing=function(){return _.texture!==null},this.getDepthSensingMesh=function(){return _.getMesh(M)};let de=null;function Pe($,oe){if(u=oe.getViewerPose(l||n),m=oe,u!==null){let ge=u.views;d!==null&&(e.setRenderTargetFramebuffer(p,d.framebuffer),e.setRenderTarget(p));let Ee=!1;ge.length!==M.cameras.length&&(M.cameras.length=0,Ee=!0);for(let Ce=0;Ce<ge.length;Ce++){let Ke=ge[Ce],Xe=null;if(d!==null)Xe=d.getViewport(Ke);else{let mt=h.getViewSubImage(c,Ke);Xe=mt.viewport,Ce===0&&(e.setRenderTargetTextures(p,mt.colorTexture,c.ignoreDepthValues?void 0:mt.depthStencilTexture),e.setRenderTarget(p))}let qe=U[Ce];qe===void 0&&(qe=new Lt,qe.layers.enable(Ce),qe.viewport=new tt,U[Ce]=qe),qe.matrix.fromArray(Ke.transform.matrix),qe.matrix.decompose(qe.position,qe.quaternion,qe.scale),qe.projectionMatrix.fromArray(Ke.projectionMatrix),qe.projectionMatrixInverse.copy(qe.projectionMatrix).invert(),qe.viewport.set(Xe.x,Xe.y,Xe.width,Xe.height),Ce===0&&(M.matrix.copy(qe.matrix),M.matrix.decompose(M.position,M.quaternion,M.scale)),Ee===!0&&M.cameras.push(qe)}let he=i.enabledFeatures;if(he&&he.includes("depth-sensing")){let Ce=h.getDepthInformation(ge[0]);Ce&&Ce.isValid&&Ce.texture&&_.init(e,Ce,i.renderState)}}for(let ge=0;ge<x.length;ge++){let Ee=v[ge],he=x[ge];Ee!==null&&he!==void 0&&he.update(Ee,oe,l||n)}de&&de($,oe),oe.detectedPlanes&&r.dispatchEvent({type:"planesdetected",data:oe}),m=null}let ve=new Il;ve.setAnimationLoop(Pe),this.setAnimationLoop=function($){de=$},this.dispose=function(){}}},Qr=new Ur,qg=new Ge;function Kg(e,t){function r(f,p){f.matrixAutoUpdate===!0&&f.updateMatrix(),p.value.copy(f.matrix)}function i(f,p){p.color.getRGB(f.fogColor.value,Al(e)),p.isFog?(f.fogNear.value=p.near,f.fogFar.value=p.far):p.isFogExp2&&(f.fogDensity.value=p.density)}function a(f,p,x,v,E){p.isMeshBasicMaterial||p.isMeshLambertMaterial?n(f,p):p.isMeshToonMaterial?(n(f,p),c(f,p)):p.isMeshPhongMaterial?(n(f,p),h(f,p)):p.isMeshStandardMaterial?(n(f,p),d(f,p),p.isMeshPhysicalMaterial&&m(f,p,E)):p.isMeshMatcapMaterial?(n(f,p),_(f,p)):p.isMeshDepthMaterial?n(f,p):p.isMeshDistanceMaterial?(n(f,p),g(f,p)):p.isMeshNormalMaterial?n(f,p):p.isLineBasicMaterial?(s(f,p),p.isLineDashedMaterial&&o(f,p)):p.isPointsMaterial?l(f,p,x,v):p.isSpriteMaterial?u(f,p):p.isShadowMaterial?(f.color.value.copy(p.color),f.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function n(f,p){f.opacity.value=p.opacity,p.color&&f.diffuse.value.copy(p.color),p.emissive&&f.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(f.map.value=p.map,r(p.map,f.mapTransform)),p.alphaMap&&(f.alphaMap.value=p.alphaMap,r(p.alphaMap,f.alphaMapTransform)),p.bumpMap&&(f.bumpMap.value=p.bumpMap,r(p.bumpMap,f.bumpMapTransform),f.bumpScale.value=p.bumpScale,p.side===It&&(f.bumpScale.value*=-1)),p.normalMap&&(f.normalMap.value=p.normalMap,r(p.normalMap,f.normalMapTransform),f.normalScale.value.copy(p.normalScale),p.side===It&&f.normalScale.value.negate()),p.displacementMap&&(f.displacementMap.value=p.displacementMap,r(p.displacementMap,f.displacementMapTransform),f.displacementScale.value=p.displacementScale,f.displacementBias.value=p.displacementBias),p.emissiveMap&&(f.emissiveMap.value=p.emissiveMap,r(p.emissiveMap,f.emissiveMapTransform)),p.specularMap&&(f.specularMap.value=p.specularMap,r(p.specularMap,f.specularMapTransform)),p.alphaTest>0&&(f.alphaTest.value=p.alphaTest);let x=t.get(p),v=x.envMap,E=x.envMapRotation;v&&(f.envMap.value=v,Qr.copy(E),Qr.x*=-1,Qr.y*=-1,Qr.z*=-1,v.isCubeTexture&&v.isRenderTargetTexture===!1&&(Qr.y*=-1,Qr.z*=-1),f.envMapRotation.value.setFromMatrix4(qg.makeRotationFromEuler(Qr)),f.flipEnvMap.value=v.isCubeTexture&&v.isRenderTargetTexture===!1?-1:1,f.reflectivity.value=p.reflectivity,f.ior.value=p.ior,f.refractionRatio.value=p.refractionRatio),p.lightMap&&(f.lightMap.value=p.lightMap,f.lightMapIntensity.value=p.lightMapIntensity,r(p.lightMap,f.lightMapTransform)),p.aoMap&&(f.aoMap.value=p.aoMap,f.aoMapIntensity.value=p.aoMapIntensity,r(p.aoMap,f.aoMapTransform))}function s(f,p){f.diffuse.value.copy(p.color),f.opacity.value=p.opacity,p.map&&(f.map.value=p.map,r(p.map,f.mapTransform))}function o(f,p){f.dashSize.value=p.dashSize,f.totalSize.value=p.dashSize+p.gapSize,f.scale.value=p.scale}function l(f,p,x,v){f.diffuse.value.copy(p.color),f.opacity.value=p.opacity,f.size.value=p.size*x,f.scale.value=v*.5,p.map&&(f.map.value=p.map,r(p.map,f.uvTransform)),p.alphaMap&&(f.alphaMap.value=p.alphaMap,r(p.alphaMap,f.alphaMapTransform)),p.alphaTest>0&&(f.alphaTest.value=p.alphaTest)}function u(f,p){f.diffuse.value.copy(p.color),f.opacity.value=p.opacity,f.rotation.value=p.rotation,p.map&&(f.map.value=p.map,r(p.map,f.mapTransform)),p.alphaMap&&(f.alphaMap.value=p.alphaMap,r(p.alphaMap,f.alphaMapTransform)),p.alphaTest>0&&(f.alphaTest.value=p.alphaTest)}function h(f,p){f.specular.value.copy(p.specular),f.shininess.value=Math.max(p.shininess,1e-4)}function c(f,p){p.gradientMap&&(f.gradientMap.value=p.gradientMap)}function d(f,p){f.metalness.value=p.metalness,p.metalnessMap&&(f.metalnessMap.value=p.metalnessMap,r(p.metalnessMap,f.metalnessMapTransform)),f.roughness.value=p.roughness,p.roughnessMap&&(f.roughnessMap.value=p.roughnessMap,r(p.roughnessMap,f.roughnessMapTransform)),p.envMap&&(f.envMapIntensity.value=p.envMapIntensity)}function m(f,p,x){f.ior.value=p.ior,p.sheen>0&&(f.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),f.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(f.sheenColorMap.value=p.sheenColorMap,r(p.sheenColorMap,f.sheenColorMapTransform)),p.sheenRoughnessMap&&(f.sheenRoughnessMap.value=p.sheenRoughnessMap,r(p.sheenRoughnessMap,f.sheenRoughnessMapTransform))),p.clearcoat>0&&(f.clearcoat.value=p.clearcoat,f.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(f.clearcoatMap.value=p.clearcoatMap,r(p.clearcoatMap,f.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(f.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,r(p.clearcoatRoughnessMap,f.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(f.clearcoatNormalMap.value=p.clearcoatNormalMap,r(p.clearcoatNormalMap,f.clearcoatNormalMapTransform),f.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===It&&f.clearcoatNormalScale.value.negate())),p.dispersion>0&&(f.dispersion.value=p.dispersion),p.iridescence>0&&(f.iridescence.value=p.iridescence,f.iridescenceIOR.value=p.iridescenceIOR,f.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],f.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(f.iridescenceMap.value=p.iridescenceMap,r(p.iridescenceMap,f.iridescenceMapTransform)),p.iridescenceThicknessMap&&(f.iridescenceThicknessMap.value=p.iridescenceThicknessMap,r(p.iridescenceThicknessMap,f.iridescenceThicknessMapTransform))),p.transmission>0&&(f.transmission.value=p.transmission,f.transmissionSamplerMap.value=x.texture,f.transmissionSamplerSize.value.set(x.width,x.height),p.transmissionMap&&(f.transmissionMap.value=p.transmissionMap,r(p.transmissionMap,f.transmissionMapTransform)),f.thickness.value=p.thickness,p.thicknessMap&&(f.thicknessMap.value=p.thicknessMap,r(p.thicknessMap,f.thicknessMapTransform)),f.attenuationDistance.value=p.attenuationDistance,f.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(f.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(f.anisotropyMap.value=p.anisotropyMap,r(p.anisotropyMap,f.anisotropyMapTransform))),f.specularIntensity.value=p.specularIntensity,f.specularColor.value.copy(p.specularColor),p.specularColorMap&&(f.specularColorMap.value=p.specularColorMap,r(p.specularColorMap,f.specularColorMapTransform)),p.specularIntensityMap&&(f.specularIntensityMap.value=p.specularIntensityMap,r(p.specularIntensityMap,f.specularIntensityMapTransform))}function _(f,p){p.matcap&&(f.matcap.value=p.matcap)}function g(f,p){let x=t.get(p).light;f.referencePosition.value.setFromMatrixPosition(x.matrixWorld),f.nearDistance.value=x.shadow.camera.near,f.farDistance.value=x.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:a}}function Zg(e,t,r,i){let a={},n={},s=[],o=e.getParameter(e.MAX_UNIFORM_BUFFER_BINDINGS);function l(x,v){let E=v.program;i.uniformBlockBinding(x,E)}function u(x,v){let E=a[x.id];E===void 0&&(_(x),E=h(x),a[x.id]=E,x.addEventListener("dispose",f));let I=v.program;i.updateUBOMapping(x,I);let w=t.render.frame;n[x.id]!==w&&(d(x),n[x.id]=w)}function h(x){let v=c();x.__bindingPointIndex=v;let E=e.createBuffer(),I=x.__size,w=x.usage;return e.bindBuffer(e.UNIFORM_BUFFER,E),e.bufferData(e.UNIFORM_BUFFER,I,w),e.bindBuffer(e.UNIFORM_BUFFER,null),e.bindBufferBase(e.UNIFORM_BUFFER,v,E),E}function c(){for(let x=0;x<o;x++)if(s.indexOf(x)===-1)return s.push(x),x;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(x){let v=a[x.id],E=x.uniforms,I=x.__cache;e.bindBuffer(e.UNIFORM_BUFFER,v);for(let w=0,R=E.length;w<R;w++){let U=Array.isArray(E[w])?E[w]:[E[w]];for(let M=0,T=U.length;M<T;M++){let P=U[M];if(m(P,w,M,I)===!0){let z=P.__offset,q=Array.isArray(P.value)?P.value:[P.value],K=0;for(let Y=0;Y<q.length;Y++){let W=q[Y],ae=g(W);typeof W=="number"||typeof W=="boolean"?(P.__data[0]=W,e.bufferSubData(e.UNIFORM_BUFFER,z+K,P.__data)):W.isMatrix3?(P.__data[0]=W.elements[0],P.__data[1]=W.elements[1],P.__data[2]=W.elements[2],P.__data[3]=0,P.__data[4]=W.elements[3],P.__data[5]=W.elements[4],P.__data[6]=W.elements[5],P.__data[7]=0,P.__data[8]=W.elements[6],P.__data[9]=W.elements[7],P.__data[10]=W.elements[8],P.__data[11]=0):(W.toArray(P.__data,K),K+=ae.storage/Float32Array.BYTES_PER_ELEMENT)}e.bufferSubData(e.UNIFORM_BUFFER,z,P.__data)}}}e.bindBuffer(e.UNIFORM_BUFFER,null)}function m(x,v,E,I){let w=x.value,R=v+"_"+E;if(I[R]===void 0)return typeof w=="number"||typeof w=="boolean"?I[R]=w:I[R]=w.clone(),!0;{let U=I[R];if(typeof w=="number"||typeof w=="boolean"){if(U!==w)return I[R]=w,!0}else if(U.equals(w)===!1)return U.copy(w),!0}return!1}function _(x){let v=x.uniforms,E=0,I=16;for(let R=0,U=v.length;R<U;R++){let M=Array.isArray(v[R])?v[R]:[v[R]];for(let T=0,P=M.length;T<P;T++){let z=M[T],q=Array.isArray(z.value)?z.value:[z.value];for(let K=0,Y=q.length;K<Y;K++){let W=q[K],ae=g(W),Z=E%I,te=Z%ae.boundary,de=Z+te;E+=te,de!==0&&I-de<ae.storage&&(E+=I-de),z.__data=new Float32Array(ae.storage/Float32Array.BYTES_PER_ELEMENT),z.__offset=E,E+=ae.storage}}}let w=E%I;return w>0&&(E+=I-w),x.__size=E,x.__cache={},this}function g(x){let v={boundary:0,storage:0};return typeof x=="number"||typeof x=="boolean"?(v.boundary=4,v.storage=4):x.isVector2?(v.boundary=8,v.storage=8):x.isVector3||x.isColor?(v.boundary=16,v.storage=12):x.isVector4?(v.boundary=16,v.storage=16):x.isMatrix3?(v.boundary=48,v.storage=48):x.isMatrix4?(v.boundary=64,v.storage=64):x.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",x),v}function f(x){let v=x.target;v.removeEventListener("dispose",f);let E=s.indexOf(v.__bindingPointIndex);s.splice(E,1),e.deleteBuffer(a[v.id]),delete a[v.id],delete n[v.id]}function p(){for(let x in a)e.deleteBuffer(a[x]);s=[],a={},n={}}return{bind:l,update:u,dispose:p}}var $g=class{constructor(e={}){let{canvas:t=Bc(),context:r=null,depth:i=!0,stencil:a=!1,alpha:n=!1,antialias:s=!1,premultipliedAlpha:o=!0,preserveDrawingBuffer:l=!1,powerPreference:u="default",failIfMajorPerformanceCaveat:h=!1,reverseDepthBuffer:c=!1}=e;this.isWebGLRenderer=!0;let d;if(r!==null){if(typeof WebGLRenderingContext<"u"&&r instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");d=r.getContextAttributes().alpha}else d=n;let m=new Uint32Array(4),_=new Int32Array(4),g=null,f=null,p=[],x=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=at,this.toneMapping=wr,this.toneMappingExposure=1;let v=this,E=!1,I=0,w=0,R=null,U=-1,M=null,T=new tt,P=new tt,z=null,q=new Ne(0),K=0,Y=t.width,W=t.height,ae=1,Z=null,te=null,de=new tt(0,0,Y,W),Pe=new tt(0,0,Y,W),ve=!1,$=new Xs,oe=!1,ge=!1,Ee=new Ge,he=new Ge,Ce=new L,Ke=new tt,Xe={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},qe=!1;function mt(){return R===null?ae:1}let O=r;function pt(S,F){return t.getContext(S,F)}try{let S={alpha:!0,depth:i,stencil:a,antialias:s,premultipliedAlpha:o,preserveDrawingBuffer:l,powerPreference:u,failIfMajorPerformanceCaveat:h};if("setAttribute"in t&&t.setAttribute("data-engine","three.js r170"),t.addEventListener("webglcontextlost",b,!1),t.addEventListener("webglcontextrestored",V,!1),t.addEventListener("webglcontextcreationerror",J,!1),O===null){let F="webgl2";if(O=pt(F,S),O===null)throw pt(F)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(S){throw console.error("THREE.WebGLRenderer: "+S.message),S}let Je,Qe,ye,Ze,we,Ie,A,y,H,re,ne,ee,Le,pe,xe,Be,ue,me,N,j,B,Q,se,Me;function C(){Je=new rm(O),Je.init(),Q=new kg(O,Je),Qe=new Zf(O,Je,e,Q),ye=new Bg(O,Je),Qe.reverseDepthBuffer&&c&&ye.buffers.depth.setReversed(!0),Ze=new nm(O),we=new Tg,Ie=new Hg(O,Je,ye,we,Qe,Q,Ze),A=new Jf(v),y=new tm(v),H=new cd(O),se=new qf(O,H),re=new im(O,H,Ze,se),ne=new om(O,re,H,Ze),N=new sm(O,Qe,Ie),Be=new $f(we),ee=new Sg(v,A,y,Je,Qe,se,Be),Le=new Kg(v,we),pe=new bg,xe=new Pg(Je),me=new Yf(v,A,y,ye,ne,d,o),ue=new Og(v,ne,Qe),Me=new Zg(O,Ze,Qe,ye),j=new Kf(O,Je,Ze),B=new am(O,Je,Ze),Ze.programs=ee.programs,v.capabilities=Qe,v.extensions=Je,v.properties=we,v.renderLists=pe,v.shadowMap=ue,v.state=ye,v.info=Ze}C();let k=new Yg(v,O);this.xr=k,this.getContext=function(){return O},this.getContextAttributes=function(){return O.getContextAttributes()},this.forceContextLoss=function(){let S=Je.get("WEBGL_lose_context");S&&S.loseContext()},this.forceContextRestore=function(){let S=Je.get("WEBGL_lose_context");S&&S.restoreContext()},this.getPixelRatio=function(){return ae},this.setPixelRatio=function(S){S!==void 0&&(ae=S,this.setSize(Y,W,!1))},this.getSize=function(S){return S.set(Y,W)},this.setSize=function(S,F,G=!0){if(k.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}Y=S,W=F,t.width=Math.floor(S*ae),t.height=Math.floor(F*ae),G===!0&&(t.style.width=S+"px",t.style.height=F+"px"),this.setViewport(0,0,S,F)},this.getDrawingBufferSize=function(S){return S.set(Y*ae,W*ae).floor()},this.setDrawingBufferSize=function(S,F,G){Y=S,W=F,ae=G,t.width=Math.floor(S*G),t.height=Math.floor(F*G),this.setViewport(0,0,S,F)},this.getCurrentViewport=function(S){return S.copy(T)},this.getViewport=function(S){return S.copy(de)},this.setViewport=function(S,F,G,X){S.isVector4?de.set(S.x,S.y,S.z,S.w):de.set(S,F,G,X),ye.viewport(T.copy(de).multiplyScalar(ae).round())},this.getScissor=function(S){return S.copy(Pe)},this.setScissor=function(S,F,G,X){S.isVector4?Pe.set(S.x,S.y,S.z,S.w):Pe.set(S,F,G,X),ye.scissor(P.copy(Pe).multiplyScalar(ae).round())},this.getScissorTest=function(){return ve},this.setScissorTest=function(S){ye.setScissorTest(ve=S)},this.setOpaqueSort=function(S){Z=S},this.setTransparentSort=function(S){te=S},this.getClearColor=function(S){return S.copy(me.getClearColor())},this.setClearColor=function(){me.setClearColor.apply(me,arguments)},this.getClearAlpha=function(){return me.getClearAlpha()},this.setClearAlpha=function(){me.setClearAlpha.apply(me,arguments)},this.clear=function(S=!0,F=!0,G=!0){let X=0;if(S){let D=!1;if(R!==null){let le=R.texture.format;D=le===Yn||le===jn||le===Xn}if(D){let le=R.texture.type,_e=le===dr||le===Gr||le===Ki||le===ui||le===Vn||le===Gn,be=me.getClearColor(),Ae=me.getClearAlpha(),ze=be.r,He=be.g,Ue=be.b;_e?(m[0]=ze,m[1]=He,m[2]=Ue,m[3]=Ae,O.clearBufferuiv(O.COLOR,0,m)):(_[0]=ze,_[1]=He,_[2]=Ue,_[3]=Ae,O.clearBufferiv(O.COLOR,0,_))}else X|=O.COLOR_BUFFER_BIT}F&&(X|=O.DEPTH_BUFFER_BIT),G&&(X|=O.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),O.clear(X)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",b,!1),t.removeEventListener("webglcontextrestored",V,!1),t.removeEventListener("webglcontextcreationerror",J,!1),pe.dispose(),xe.dispose(),we.dispose(),A.dispose(),y.dispose(),ne.dispose(),se.dispose(),Me.dispose(),ee.dispose(),k.dispose(),k.removeEventListener("sessionstart",je),k.removeEventListener("sessionend",Ut),zt.stop()};function b(S){S.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),E=!0}function V(){console.log("THREE.WebGLRenderer: Context Restored."),E=!1;let S=Ze.autoReset,F=ue.enabled,G=ue.autoUpdate,X=ue.needsUpdate,D=ue.type;C(),Ze.autoReset=S,ue.enabled=F,ue.autoUpdate=G,ue.needsUpdate=X,ue.type=D}function J(S){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",S.statusMessage)}function ie(S){let F=S.target;F.removeEventListener("dispose",ie),Se(F)}function Se(S){fe(S),we.remove(S)}function fe(S){let F=we.get(S).programs;F!==void 0&&(F.forEach(function(G){ee.releaseProgram(G)}),S.isShaderMaterial&&ee.releaseShaderCache(S))}this.renderBufferDirect=function(S,F,G,X,D,le){F===null&&(F=Xe);let _e=D.isMesh&&D.matrixWorld.determinant()<0,be=k0(S,F,G,X,D);ye.setMaterial(X,_e);let Ae=G.index,ze=1;if(X.wireframe===!0){if(Ae=re.getWireframeAttribute(G),Ae===void 0)return;ze=2}let He=G.drawRange,Ue=G.attributes.position,$e=He.start*ze,st=(He.start+He.count)*ze;le!==null&&($e=Math.max($e,le.start*ze),st=Math.min(st,(le.start+le.count)*ze)),Ae!==null?($e=Math.max($e,0),st=Math.min(st,Ae.count)):Ue!=null&&($e=Math.max($e,0),st=Math.min(st,Ue.count));let ot=st-$e;if(ot<0||ot===1/0)return;se.setup(D,X,be,G,Ae);let gt,lt=j;if(Ae!==null&&(gt=H.get(Ae),lt=B,lt.setIndex(gt)),D.isMesh)X.wireframe===!0?(ye.setLineWidth(X.wireframeLinewidth*mt()),lt.setMode(O.LINES)):lt.setMode(O.TRIANGLES);else if(D.isLine){let Re=X.linewidth;Re===void 0&&(Re=1),ye.setLineWidth(Re*mt()),D.isLineSegments?lt.setMode(O.LINES):D.isLineLoop?lt.setMode(O.LINE_LOOP):lt.setMode(O.LINE_STRIP)}else D.isPoints?lt.setMode(O.POINTS):D.isSprite&&lt.setMode(O.TRIANGLES);if(D.isBatchedMesh)if(D._multiDrawInstances!==null)lt.renderMultiDrawInstances(D._multiDrawStarts,D._multiDrawCounts,D._multiDrawCount,D._multiDrawInstances);else if(Je.get("WEBGL_multi_draw"))lt.renderMultiDraw(D._multiDrawStarts,D._multiDrawCounts,D._multiDrawCount);else{let Re=D._multiDrawStarts,ri=D._multiDrawCounts,ii=D._multiDrawCount,rr=Ae?H.get(Ae).bytesPerElement:1,Xi=we.get(X).currentProgram.getUniforms();for(let Ht=0;Ht<ii;Ht++)Xi.setValue(O,"_gl_DrawID",Ht),lt.render(Re[Ht]/rr,ri[Ht])}else if(D.isInstancedMesh)lt.renderInstances($e,ot,D.count);else if(G.isInstancedBufferGeometry){let Re=G._maxInstanceCount!==void 0?G._maxInstanceCount:1/0,ri=Math.min(G.instanceCount,Re);lt.renderInstances($e,ot,ri)}else lt.render($e,ot)};function De(S,F,G){S.transparent===!0&&S.side===Ot&&S.forceSinglePass===!1?(S.side=It,S.needsUpdate=!0,wn(S,F,G),S.side=hr,S.needsUpdate=!0,wn(S,F,G),S.side=Ot):wn(S,F,G)}this.compile=function(S,F,G=null){G===null&&(G=S),f=xe.get(G),f.init(F),x.push(f),G.traverseVisible(function(D){D.isLight&&D.layers.test(F.layers)&&(f.pushLight(D),D.castShadow&&f.pushShadow(D))}),S!==G&&S.traverseVisible(function(D){D.isLight&&D.layers.test(F.layers)&&(f.pushLight(D),D.castShadow&&f.pushShadow(D))}),f.setupLights();let X=new Set;return S.traverse(function(D){if(!(D.isMesh||D.isPoints||D.isLine||D.isSprite))return;let le=D.material;if(le)if(Array.isArray(le))for(let _e=0;_e<le.length;_e++){let be=le[_e];De(be,G,D),X.add(be)}else De(le,G,D),X.add(le)}),x.pop(),f=null,X},this.compileAsync=function(S,F,G=null){let X=this.compile(S,F,G);return new Promise(D=>{function le(){if(X.forEach(function(_e){we.get(_e).currentProgram.isReady()&&X.delete(_e)}),X.size===0){D(S);return}setTimeout(le,10)}Je.get("KHR_parallel_shader_compile")!==null?le():setTimeout(le,10)})};let Te=null;function rt(S){Te&&Te(S)}function je(){zt.stop()}function Ut(){zt.start()}let zt=new Il;zt.setAnimationLoop(rt),typeof self<"u"&&zt.setContext(self),this.setAnimationLoop=function(S){Te=S,k.setAnimationLoop(S),S===null?zt.stop():zt.start()},k.addEventListener("sessionstart",je),k.addEventListener("sessionend",Ut),this.render=function(S,F){if(F!==void 0&&F.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(E===!0)return;if(S.matrixWorldAutoUpdate===!0&&S.updateMatrixWorld(),F.parent===null&&F.matrixWorldAutoUpdate===!0&&F.updateMatrixWorld(),k.enabled===!0&&k.isPresenting===!0&&(k.cameraAutoUpdate===!0&&k.updateCamera(F),F=k.getCamera()),S.isScene===!0&&S.onBeforeRender(v,S,F,R),f=xe.get(S,x.length),f.init(F),x.push(f),he.multiplyMatrices(F.projectionMatrix,F.matrixWorldInverse),$.setFromProjectionMatrix(he),ge=this.localClippingEnabled,oe=Be.init(this.clippingPlanes,ge),g=pe.get(S,p.length),g.init(),p.push(g),k.enabled===!0&&k.isPresenting===!0){let le=v.xr.getDepthSensingMesh();le!==null&&Sr(le,F,-1/0,v.sortObjects)}Sr(S,F,0,v.sortObjects),g.finish(),v.sortObjects===!0&&g.sort(Z,te),qe=k.enabled===!1||k.isPresenting===!1||k.hasDepthSensing()===!1,qe&&me.addToRenderList(g,S),this.info.render.frame++,oe===!0&&Be.beginShadows();let G=f.state.shadowsArray;ue.render(G,S,F),oe===!0&&Be.endShadows(),this.info.autoReset===!0&&this.info.reset();let X=g.opaque,D=g.transmissive;if(f.setupLights(),F.isArrayCamera){let le=F.cameras;if(D.length>0)for(let _e=0,be=le.length;_e<be;_e++){let Ae=le[_e];xa(X,D,S,Ae)}qe&&me.render(S);for(let _e=0,be=le.length;_e<be;_e++){let Ae=le[_e];Tr(g,S,Ae,Ae.viewport)}}else D.length>0&&xa(X,D,S,F),qe&&me.render(S),Tr(g,S,F);R!==null&&(Ie.updateMultisampleRenderTarget(R),Ie.updateRenderTargetMipmap(R)),S.isScene===!0&&S.onAfterRender(v,S,F),se.resetDefaultState(),U=-1,M=null,x.pop(),x.length>0?(f=x[x.length-1],oe===!0&&Be.setGlobalState(v.clippingPlanes,f.state.camera)):f=null,p.pop(),p.length>0?g=p[p.length-1]:g=null};function Sr(S,F,G,X){if(S.visible===!1)return;if(S.layers.test(F.layers)){if(S.isGroup)G=S.renderOrder;else if(S.isLOD)S.autoUpdate===!0&&S.update(F);else if(S.isLight)f.pushLight(S),S.castShadow&&f.pushShadow(S);else if(S.isSprite){if(!S.frustumCulled||$.intersectsSprite(S)){X&&Ke.setFromMatrixPosition(S.matrixWorld).applyMatrix4(he);let le=ne.update(S),_e=S.material;_e.visible&&g.push(S,le,_e,G,Ke.z,null)}}else if((S.isMesh||S.isLine||S.isPoints)&&(!S.frustumCulled||$.intersectsObject(S))){let le=ne.update(S),_e=S.material;if(X&&(S.boundingSphere!==void 0?(S.boundingSphere===null&&S.computeBoundingSphere(),Ke.copy(S.boundingSphere.center)):(le.boundingSphere===null&&le.computeBoundingSphere(),Ke.copy(le.boundingSphere.center)),Ke.applyMatrix4(S.matrixWorld).applyMatrix4(he)),Array.isArray(_e)){let be=le.groups;for(let Ae=0,ze=be.length;Ae<ze;Ae++){let He=be[Ae],Ue=_e[He.materialIndex];Ue&&Ue.visible&&g.push(S,le,Ue,G,Ke.z,He)}}else _e.visible&&g.push(S,le,_e,G,Ke.z,null)}}let D=S.children;for(let le=0,_e=D.length;le<_e;le++)Sr(D[le],F,G,X)}function Tr(S,F,G,X){let D=S.opaque,le=S.transmissive,_e=S.transparent;f.setupLightsView(G),oe===!0&&Be.setGlobalState(v.clippingPlanes,G),X&&ye.viewport(T.copy(X)),D.length>0&&bn(D,F,G),le.length>0&&bn(le,F,G),_e.length>0&&bn(_e,F,G),ye.buffers.depth.setTest(!0),ye.buffers.depth.setMask(!0),ye.buffers.color.setMask(!0),ye.setPolygonOffset(!1)}function xa(S,F,G,X){if((G.isScene===!0?G.overrideMaterial:null)!==null)return;f.state.transmissionRenderTarget[X.id]===void 0&&(f.state.transmissionRenderTarget[X.id]=new Wr(1,1,{generateMipmaps:!0,type:Je.has("EXT_color_buffer_half_float")||Je.has("EXT_color_buffer_float")?Zi:dr,minFilter:jt,samples:4,stencilBuffer:a,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Ye.workingColorSpace}));let D=f.state.transmissionRenderTarget[X.id],le=X.viewport||T;D.setSize(le.z,le.w);let _e=v.getRenderTarget();v.setRenderTarget(D),v.getClearColor(q),K=v.getClearAlpha(),K<1&&v.setClearColor(16777215,.5),v.clear(),qe&&me.render(G);let be=v.toneMapping;v.toneMapping=wr;let Ae=X.viewport;if(X.viewport!==void 0&&(X.viewport=void 0),f.setupLightsView(X),oe===!0&&Be.setGlobalState(v.clippingPlanes,X),bn(S,G,X),Ie.updateMultisampleRenderTarget(D),Ie.updateRenderTargetMipmap(D),Je.has("WEBGL_multisampled_render_to_texture")===!1){let ze=!1;for(let He=0,Ue=F.length;He<Ue;He++){let $e=F[He],st=$e.object,ot=$e.geometry,gt=$e.material,lt=$e.group;if(gt.side===Ot&&st.layers.test(X.layers)){let Re=gt.side;gt.side=It,gt.needsUpdate=!0,nh(st,G,X,ot,gt,lt),gt.side=Re,gt.needsUpdate=!0,ze=!0}}ze===!0&&(Ie.updateMultisampleRenderTarget(D),Ie.updateRenderTargetMipmap(D))}v.setRenderTarget(_e),v.setClearColor(q,K),Ae!==void 0&&(X.viewport=Ae),v.toneMapping=be}function bn(S,F,G){let X=F.isScene===!0?F.overrideMaterial:null;for(let D=0,le=S.length;D<le;D++){let _e=S[D],be=_e.object,Ae=_e.geometry,ze=X===null?_e.material:X,He=_e.group;be.layers.test(G.layers)&&nh(be,F,G,Ae,ze,He)}}function nh(S,F,G,X,D,le){S.onBeforeRender(v,F,G,X,D,le),S.modelViewMatrix.multiplyMatrices(G.matrixWorldInverse,S.matrixWorld),S.normalMatrix.getNormalMatrix(S.modelViewMatrix),D.onBeforeRender(v,F,G,X,S,le),D.transparent===!0&&D.side===Ot&&D.forceSinglePass===!1?(D.side=It,D.needsUpdate=!0,v.renderBufferDirect(G,F,X,D,S,le),D.side=hr,D.needsUpdate=!0,v.renderBufferDirect(G,F,X,D,S,le),D.side=Ot):v.renderBufferDirect(G,F,X,D,S,le),S.onAfterRender(v,F,G,X,D,le)}function wn(S,F,G){F.isScene!==!0&&(F=Xe);let X=we.get(S),D=f.state.lights,le=f.state.shadowsArray,_e=D.state.version,be=ee.getParameters(S,D.state,le,F,G),Ae=ee.getProgramCacheKey(be),ze=X.programs;X.environment=S.isMeshStandardMaterial?F.environment:null,X.fog=F.fog,X.envMap=(S.isMeshStandardMaterial?y:A).get(S.envMap||X.environment),X.envMapRotation=X.environment!==null&&S.envMap===null?F.environmentRotation:S.envMapRotation,ze===void 0&&(S.addEventListener("dispose",ie),ze=new Map,X.programs=ze);let He=ze.get(Ae);if(He!==void 0){if(X.currentProgram===He&&X.lightsStateVersion===_e)return oh(S,be),He}else be.uniforms=ee.getUniforms(S),S.onBeforeCompile(be,v),He=ee.acquireProgram(be,Ae),ze.set(Ae,He),X.uniforms=be.uniforms;let Ue=X.uniforms;return(!S.isShaderMaterial&&!S.isRawShaderMaterial||S.clipping===!0)&&(Ue.clippingPlanes=Be.uniform),oh(S,be),X.needsLights=G0(S),X.lightsStateVersion=_e,X.needsLights&&(Ue.ambientLightColor.value=D.state.ambient,Ue.lightProbe.value=D.state.probe,Ue.directionalLights.value=D.state.directional,Ue.directionalLightShadows.value=D.state.directionalShadow,Ue.spotLights.value=D.state.spot,Ue.spotLightShadows.value=D.state.spotShadow,Ue.rectAreaLights.value=D.state.rectArea,Ue.ltc_1.value=D.state.rectAreaLTC1,Ue.ltc_2.value=D.state.rectAreaLTC2,Ue.pointLights.value=D.state.point,Ue.pointLightShadows.value=D.state.pointShadow,Ue.hemisphereLights.value=D.state.hemi,Ue.directionalShadowMap.value=D.state.directionalShadowMap,Ue.directionalShadowMatrix.value=D.state.directionalShadowMatrix,Ue.spotShadowMap.value=D.state.spotShadowMap,Ue.spotLightMatrix.value=D.state.spotLightMatrix,Ue.spotLightMap.value=D.state.spotLightMap,Ue.pointShadowMap.value=D.state.pointShadowMap,Ue.pointShadowMatrix.value=D.state.pointShadowMatrix),X.currentProgram=He,X.uniformsList=null,He}function sh(S){if(S.uniformsList===null){let F=S.currentProgram.getUniforms();S.uniformsList=nn.seqWithValue(F.seq,S.uniforms)}return S.uniformsList}function oh(S,F){let G=we.get(S);G.outputColorSpace=F.outputColorSpace,G.batching=F.batching,G.batchingColor=F.batchingColor,G.instancing=F.instancing,G.instancingColor=F.instancingColor,G.instancingMorph=F.instancingMorph,G.skinning=F.skinning,G.morphTargets=F.morphTargets,G.morphNormals=F.morphNormals,G.morphColors=F.morphColors,G.morphTargetsCount=F.morphTargetsCount,G.numClippingPlanes=F.numClippingPlanes,G.numIntersection=F.numClipIntersection,G.vertexAlphas=F.vertexAlphas,G.vertexTangents=F.vertexTangents,G.toneMapping=F.toneMapping}function k0(S,F,G,X,D){F.isScene!==!0&&(F=Xe),Ie.resetTextureUnits();let le=F.fog,_e=X.isMeshStandardMaterial?F.environment:null,be=R===null?v.outputColorSpace:R.isXRRenderTarget===!0?R.texture.colorSpace:At,Ae=(X.isMeshStandardMaterial?y:A).get(X.envMap||_e),ze=X.vertexColors===!0&&!!G.attributes.color&&G.attributes.color.itemSize===4,He=!!G.attributes.tangent&&(!!X.normalMap||X.anisotropy>0),Ue=!!G.morphAttributes.position,$e=!!G.morphAttributes.normal,st=!!G.morphAttributes.color,ot=wr;X.toneMapped&&(R===null||R.isXRRenderTarget===!0)&&(ot=v.toneMapping);let gt=G.morphAttributes.position||G.morphAttributes.normal||G.morphAttributes.color,lt=gt!==void 0?gt.length:0,Re=we.get(X),ri=f.state.lights;if(oe===!0&&(ge===!0||S!==M)){let Nt=S===M&&X.id===U;Be.setState(X,S,Nt)}let ii=!1;X.version===Re.__version?(Re.needsLights&&Re.lightsStateVersion!==ri.state.version||Re.outputColorSpace!==be||D.isBatchedMesh&&Re.batching===!1||!D.isBatchedMesh&&Re.batching===!0||D.isBatchedMesh&&Re.batchingColor===!0&&D.colorTexture===null||D.isBatchedMesh&&Re.batchingColor===!1&&D.colorTexture!==null||D.isInstancedMesh&&Re.instancing===!1||!D.isInstancedMesh&&Re.instancing===!0||D.isSkinnedMesh&&Re.skinning===!1||!D.isSkinnedMesh&&Re.skinning===!0||D.isInstancedMesh&&Re.instancingColor===!0&&D.instanceColor===null||D.isInstancedMesh&&Re.instancingColor===!1&&D.instanceColor!==null||D.isInstancedMesh&&Re.instancingMorph===!0&&D.morphTexture===null||D.isInstancedMesh&&Re.instancingMorph===!1&&D.morphTexture!==null||Re.envMap!==Ae||X.fog===!0&&Re.fog!==le||Re.numClippingPlanes!==void 0&&(Re.numClippingPlanes!==Be.numPlanes||Re.numIntersection!==Be.numIntersection)||Re.vertexAlphas!==ze||Re.vertexTangents!==He||Re.morphTargets!==Ue||Re.morphNormals!==$e||Re.morphColors!==st||Re.toneMapping!==ot||Re.morphTargetsCount!==lt)&&(ii=!0):(ii=!0,Re.__version=X.version);let rr=Re.currentProgram;ii===!0&&(rr=wn(X,F,D));let Xi=!1,Ht=!1,ya=!1,nt=rr.getUniforms(),lr=Re.uniforms;if(ye.useProgram(rr.program)&&(Xi=!0,Ht=!0,ya=!0),X.id!==U&&(U=X.id,Ht=!0),Xi||M!==S){ye.buffers.depth.getReversed()?(Ee.copy(S.projectionMatrix),Hc(Ee),kc(Ee),nt.setValue(O,"projectionMatrix",Ee)):nt.setValue(O,"projectionMatrix",S.projectionMatrix),nt.setValue(O,"viewMatrix",S.matrixWorldInverse);let Nt=nt.map.cameraPosition;Nt!==void 0&&Nt.setValue(O,Ce.setFromMatrixPosition(S.matrixWorld)),Qe.logarithmicDepthBuffer&&nt.setValue(O,"logDepthBufFC",2/(Math.log(S.far+1)/Math.LN2)),(X.isMeshPhongMaterial||X.isMeshToonMaterial||X.isMeshLambertMaterial||X.isMeshBasicMaterial||X.isMeshStandardMaterial||X.isShaderMaterial)&&nt.setValue(O,"isOrthographic",S.isOrthographicCamera===!0),M!==S&&(M=S,Ht=!0,ya=!0)}if(D.isSkinnedMesh){nt.setOptional(O,D,"bindMatrix"),nt.setOptional(O,D,"bindMatrixInverse");let Nt=D.skeleton;Nt&&(Nt.boneTexture===null&&Nt.computeBoneTexture(),nt.setValue(O,"boneTexture",Nt.boneTexture,Ie))}D.isBatchedMesh&&(nt.setOptional(O,D,"batchingTexture"),nt.setValue(O,"batchingTexture",D._matricesTexture,Ie),nt.setOptional(O,D,"batchingIdTexture"),nt.setValue(O,"batchingIdTexture",D._indirectTexture,Ie),nt.setOptional(O,D,"batchingColorTexture"),D._colorsTexture!==null&&nt.setValue(O,"batchingColorTexture",D._colorsTexture,Ie));let Ma=G.morphAttributes;if((Ma.position!==void 0||Ma.normal!==void 0||Ma.color!==void 0)&&N.update(D,G,rr),(Ht||Re.receiveShadow!==D.receiveShadow)&&(Re.receiveShadow=D.receiveShadow,nt.setValue(O,"receiveShadow",D.receiveShadow)),X.isMeshGouraudMaterial&&X.envMap!==null&&(lr.envMap.value=Ae,lr.flipEnvMap.value=Ae.isCubeTexture&&Ae.isRenderTargetTexture===!1?-1:1),X.isMeshStandardMaterial&&X.envMap===null&&F.environment!==null&&(lr.envMapIntensity.value=F.environmentIntensity),Ht&&(nt.setValue(O,"toneMappingExposure",v.toneMappingExposure),Re.needsLights&&V0(lr,ya),le&&X.fog===!0&&Le.refreshFogUniforms(lr,le),Le.refreshMaterialUniforms(lr,X,ae,W,f.state.transmissionRenderTarget[S.id]),nn.upload(O,sh(Re),lr,Ie)),X.isShaderMaterial&&X.uniformsNeedUpdate===!0&&(nn.upload(O,sh(Re),lr,Ie),X.uniformsNeedUpdate=!1),X.isSpriteMaterial&&nt.setValue(O,"center",D.center),nt.setValue(O,"modelViewMatrix",D.modelViewMatrix),nt.setValue(O,"normalMatrix",D.normalMatrix),nt.setValue(O,"modelMatrix",D.matrixWorld),X.isShaderMaterial||X.isRawShaderMaterial){let Nt=X.uniformsGroups;for(let Sa=0,kr=Nt.length;Sa<kr;Sa++){let lh=Nt[Sa];Me.update(lh,rr),Me.bind(lh,rr)}}return rr}function V0(S,F){S.ambientLightColor.needsUpdate=F,S.lightProbe.needsUpdate=F,S.directionalLights.needsUpdate=F,S.directionalLightShadows.needsUpdate=F,S.pointLights.needsUpdate=F,S.pointLightShadows.needsUpdate=F,S.spotLights.needsUpdate=F,S.spotLightShadows.needsUpdate=F,S.rectAreaLights.needsUpdate=F,S.hemisphereLights.needsUpdate=F}function G0(S){return S.isMeshLambertMaterial||S.isMeshToonMaterial||S.isMeshPhongMaterial||S.isMeshStandardMaterial||S.isShadowMaterial||S.isShaderMaterial&&S.lights===!0}this.getActiveCubeFace=function(){return I},this.getActiveMipmapLevel=function(){return w},this.getRenderTarget=function(){return R},this.setRenderTargetTextures=function(S,F,G){we.get(S.texture).__webglTexture=F,we.get(S.depthTexture).__webglTexture=G;let X=we.get(S);X.__hasExternalTextures=!0,X.__autoAllocateDepthBuffer=G===void 0,X.__autoAllocateDepthBuffer||Je.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),X.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(S,F){let G=we.get(S);G.__webglFramebuffer=F,G.__useDefaultFramebuffer=F===void 0},this.setRenderTarget=function(S,F=0,G=0){R=S,I=F,w=G;let X=!0,D=null,le=!1,_e=!1;if(S){let be=we.get(S);if(be.__useDefaultFramebuffer!==void 0)ye.bindFramebuffer(O.FRAMEBUFFER,null),X=!1;else if(be.__webglFramebuffer===void 0)Ie.setupRenderTarget(S);else if(be.__hasExternalTextures)Ie.rebindTextures(S,we.get(S.texture).__webglTexture,we.get(S.depthTexture).__webglTexture);else if(S.depthBuffer){let He=S.depthTexture;if(be.__boundDepthTexture!==He){if(He!==null&&we.has(He)&&(S.width!==He.image.width||S.height!==He.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Ie.setupDepthRenderbuffer(S)}}let Ae=S.texture;(Ae.isData3DTexture||Ae.isDataArrayTexture||Ae.isCompressedArrayTexture)&&(_e=!0);let ze=we.get(S).__webglFramebuffer;S.isWebGLCubeRenderTarget?(Array.isArray(ze[F])?D=ze[F][G]:D=ze[F],le=!0):S.samples>0&&Ie.useMultisampledRTT(S)===!1?D=we.get(S).__webglMultisampledFramebuffer:Array.isArray(ze)?D=ze[G]:D=ze,T.copy(S.viewport),P.copy(S.scissor),z=S.scissorTest}else T.copy(de).multiplyScalar(ae).floor(),P.copy(Pe).multiplyScalar(ae).floor(),z=ve;if(ye.bindFramebuffer(O.FRAMEBUFFER,D)&&X&&ye.drawBuffers(S,D),ye.viewport(T),ye.scissor(P),ye.setScissorTest(z),le){let be=we.get(S.texture);O.framebufferTexture2D(O.FRAMEBUFFER,O.COLOR_ATTACHMENT0,O.TEXTURE_CUBE_MAP_POSITIVE_X+F,be.__webglTexture,G)}else if(_e){let be=we.get(S.texture),Ae=F||0;O.framebufferTextureLayer(O.FRAMEBUFFER,O.COLOR_ATTACHMENT0,be.__webglTexture,G||0,Ae)}U=-1},this.readRenderTargetPixels=function(S,F,G,X,D,le,_e){if(!(S&&S.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let be=we.get(S).__webglFramebuffer;if(S.isWebGLCubeRenderTarget&&_e!==void 0&&(be=be[_e]),be){ye.bindFramebuffer(O.FRAMEBUFFER,be);try{let Ae=S.texture,ze=Ae.format,He=Ae.type;if(!Qe.textureFormatReadable(ze)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!Qe.textureTypeReadable(He)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}F>=0&&F<=S.width-X&&G>=0&&G<=S.height-D&&O.readPixels(F,G,X,D,Q.convert(ze),Q.convert(He),le)}finally{let Ae=R!==null?we.get(R).__webglFramebuffer:null;ye.bindFramebuffer(O.FRAMEBUFFER,Ae)}}},this.readRenderTargetPixelsAsync=async function(S,F,G,X,D,le,_e){if(!(S&&S.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let be=we.get(S).__webglFramebuffer;if(S.isWebGLCubeRenderTarget&&_e!==void 0&&(be=be[_e]),be){let Ae=S.texture,ze=Ae.format,He=Ae.type;if(!Qe.textureFormatReadable(ze))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!Qe.textureTypeReadable(He))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(F>=0&&F<=S.width-X&&G>=0&&G<=S.height-D){ye.bindFramebuffer(O.FRAMEBUFFER,be);let Ue=O.createBuffer();O.bindBuffer(O.PIXEL_PACK_BUFFER,Ue),O.bufferData(O.PIXEL_PACK_BUFFER,le.byteLength,O.STREAM_READ),O.readPixels(F,G,X,D,Q.convert(ze),Q.convert(He),0);let $e=R!==null?we.get(R).__webglFramebuffer:null;ye.bindFramebuffer(O.FRAMEBUFFER,$e);let st=O.fenceSync(O.SYNC_GPU_COMMANDS_COMPLETE,0);return O.flush(),await zc(O,st,4),O.bindBuffer(O.PIXEL_PACK_BUFFER,Ue),O.getBufferSubData(O.PIXEL_PACK_BUFFER,0,le),O.deleteBuffer(Ue),O.deleteSync(st),le}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(S,F=null,G=0){S.isTexture!==!0&&(ra("WebGLRenderer: copyFramebufferToTexture function signature has changed."),F=arguments[0]||null,S=arguments[1]);let X=Math.pow(2,-G),D=Math.floor(S.image.width*X),le=Math.floor(S.image.height*X),_e=F!==null?F.x:0,be=F!==null?F.y:0;Ie.setTexture2D(S,0),O.copyTexSubImage2D(O.TEXTURE_2D,G,0,0,_e,be,D,le),ye.unbindTexture()},this.copyTextureToTexture=function(S,F,G=null,X=null,D=0){S.isTexture!==!0&&(ra("WebGLRenderer: copyTextureToTexture function signature has changed."),X=arguments[0]||null,S=arguments[1],F=arguments[2],D=arguments[3]||0,G=null);let le,_e,be,Ae,ze,He,Ue,$e,st,ot=S.isCompressedTexture?S.mipmaps[D]:S.image;G!==null?(le=G.max.x-G.min.x,_e=G.max.y-G.min.y,be=G.isBox3?G.max.z-G.min.z:1,Ae=G.min.x,ze=G.min.y,He=G.isBox3?G.min.z:0):(le=ot.width,_e=ot.height,be=ot.depth||1,Ae=0,ze=0,He=0),X!==null?(Ue=X.x,$e=X.y,st=X.z):(Ue=0,$e=0,st=0);let gt=Q.convert(F.format),lt=Q.convert(F.type),Re;F.isData3DTexture?(Ie.setTexture3D(F,0),Re=O.TEXTURE_3D):F.isDataArrayTexture||F.isCompressedArrayTexture?(Ie.setTexture2DArray(F,0),Re=O.TEXTURE_2D_ARRAY):(Ie.setTexture2D(F,0),Re=O.TEXTURE_2D),O.pixelStorei(O.UNPACK_FLIP_Y_WEBGL,F.flipY),O.pixelStorei(O.UNPACK_PREMULTIPLY_ALPHA_WEBGL,F.premultiplyAlpha),O.pixelStorei(O.UNPACK_ALIGNMENT,F.unpackAlignment);let ri=O.getParameter(O.UNPACK_ROW_LENGTH),ii=O.getParameter(O.UNPACK_IMAGE_HEIGHT),rr=O.getParameter(O.UNPACK_SKIP_PIXELS),Xi=O.getParameter(O.UNPACK_SKIP_ROWS),Ht=O.getParameter(O.UNPACK_SKIP_IMAGES);O.pixelStorei(O.UNPACK_ROW_LENGTH,ot.width),O.pixelStorei(O.UNPACK_IMAGE_HEIGHT,ot.height),O.pixelStorei(O.UNPACK_SKIP_PIXELS,Ae),O.pixelStorei(O.UNPACK_SKIP_ROWS,ze),O.pixelStorei(O.UNPACK_SKIP_IMAGES,He);let ya=S.isDataArrayTexture||S.isData3DTexture,nt=F.isDataArrayTexture||F.isData3DTexture;if(S.isRenderTargetTexture||S.isDepthTexture){let lr=we.get(S),Ma=we.get(F),Nt=we.get(lr.__renderTarget),Sa=we.get(Ma.__renderTarget);ye.bindFramebuffer(O.READ_FRAMEBUFFER,Nt.__webglFramebuffer),ye.bindFramebuffer(O.DRAW_FRAMEBUFFER,Sa.__webglFramebuffer);for(let kr=0;kr<be;kr++)ya&&O.framebufferTextureLayer(O.READ_FRAMEBUFFER,O.COLOR_ATTACHMENT0,we.get(S).__webglTexture,D,He+kr),S.isDepthTexture?(nt&&O.framebufferTextureLayer(O.DRAW_FRAMEBUFFER,O.COLOR_ATTACHMENT0,we.get(F).__webglTexture,D,st+kr),O.blitFramebuffer(Ae,ze,le,_e,Ue,$e,le,_e,O.DEPTH_BUFFER_BIT,O.NEAREST)):nt?O.copyTexSubImage3D(Re,D,Ue,$e,st+kr,Ae,ze,le,_e):O.copyTexSubImage2D(Re,D,Ue,$e,st+kr,Ae,ze,le,_e);ye.bindFramebuffer(O.READ_FRAMEBUFFER,null),ye.bindFramebuffer(O.DRAW_FRAMEBUFFER,null)}else nt?S.isDataTexture||S.isData3DTexture?O.texSubImage3D(Re,D,Ue,$e,st,le,_e,be,gt,lt,ot.data):F.isCompressedArrayTexture?O.compressedTexSubImage3D(Re,D,Ue,$e,st,le,_e,be,gt,ot.data):O.texSubImage3D(Re,D,Ue,$e,st,le,_e,be,gt,lt,ot):S.isDataTexture?O.texSubImage2D(O.TEXTURE_2D,D,Ue,$e,le,_e,gt,lt,ot.data):S.isCompressedTexture?O.compressedTexSubImage2D(O.TEXTURE_2D,D,Ue,$e,ot.width,ot.height,gt,ot.data):O.texSubImage2D(O.TEXTURE_2D,D,Ue,$e,le,_e,gt,lt,ot);O.pixelStorei(O.UNPACK_ROW_LENGTH,ri),O.pixelStorei(O.UNPACK_IMAGE_HEIGHT,ii),O.pixelStorei(O.UNPACK_SKIP_PIXELS,rr),O.pixelStorei(O.UNPACK_SKIP_ROWS,Xi),O.pixelStorei(O.UNPACK_SKIP_IMAGES,Ht),D===0&&F.generateMipmaps&&O.generateMipmap(Re),ye.unbindTexture()},this.copyTextureToTexture3D=function(S,F,G=null,X=null,D=0){return S.isTexture!==!0&&(ra("WebGLRenderer: copyTextureToTexture3D function signature has changed."),G=arguments[0]||null,X=arguments[1]||null,S=arguments[2],F=arguments[3],D=arguments[4]||0),ra('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(S,F,G,X,D)},this.initRenderTarget=function(S){we.get(S).__webglFramebuffer===void 0&&Ie.setupRenderTarget(S)},this.initTexture=function(S){S.isCubeTexture?Ie.setTextureCube(S,0):S.isData3DTexture?Ie.setTexture3D(S,0):S.isDataArrayTexture||S.isCompressedArrayTexture?Ie.setTexture2DArray(S,0):Ie.setTexture2D(S,0),ye.unbindTexture()},this.resetState=function(){I=0,w=0,R=null,ye.reset(),se.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return pr}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorspace=Ye._getDrawingBufferColorSpace(e),t.unpackColorSpace=Ye._getUnpackColorSpace()}},Jg=class _h{constructor(t,r=1,i=1e3){this.isFog=!0,this.name="",this.color=new Ne(t),this.near=r,this.far=i}clone(){return new _h(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},uu=class extends ct{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Ur,this.environmentIntensity=1,this.environmentRotation=new Ur,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}},hu=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=Ss,this.updateRanges=[],this.version=0,this.uuid=qt()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,r){e*=this.stride,r*=t.stride;for(let i=0,a=this.stride;i<a;i++)this.array[e+i]=t.array[r+i];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=qt()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),r=new this.constructor(t,this.stride);return r.setUsage(this.usage),r}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=qt()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},Pt=new L,ro=class vh{constructor(t,r,i,a=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=r,this.offset=i,this.normalized=a}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let r=0,i=this.data.count;r<i;r++)Pt.fromBufferAttribute(this,r),Pt.applyMatrix4(t),this.setXYZ(r,Pt.x,Pt.y,Pt.z);return this}applyNormalMatrix(t){for(let r=0,i=this.count;r<i;r++)Pt.fromBufferAttribute(this,r),Pt.applyNormalMatrix(t),this.setXYZ(r,Pt.x,Pt.y,Pt.z);return this}transformDirection(t){for(let r=0,i=this.count;r<i;r++)Pt.fromBufferAttribute(this,r),Pt.transformDirection(t),this.setXYZ(r,Pt.x,Pt.y,Pt.z);return this}getComponent(t,r){let i=this.array[t*this.data.stride+this.offset+r];return this.normalized&&(i=Kt(i,this.array)),i}setComponent(t,r,i){return this.normalized&&(i=et(i,this.array)),this.data.array[t*this.data.stride+this.offset+r]=i,this}setX(t,r){return this.normalized&&(r=et(r,this.array)),this.data.array[t*this.data.stride+this.offset]=r,this}setY(t,r){return this.normalized&&(r=et(r,this.array)),this.data.array[t*this.data.stride+this.offset+1]=r,this}setZ(t,r){return this.normalized&&(r=et(r,this.array)),this.data.array[t*this.data.stride+this.offset+2]=r,this}setW(t,r){return this.normalized&&(r=et(r,this.array)),this.data.array[t*this.data.stride+this.offset+3]=r,this}getX(t){let r=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(r=Kt(r,this.array)),r}getY(t){let r=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(r=Kt(r,this.array)),r}getZ(t){let r=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(r=Kt(r,this.array)),r}getW(t){let r=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(r=Kt(r,this.array)),r}setXY(t,r,i){return t=t*this.data.stride+this.offset,this.normalized&&(r=et(r,this.array),i=et(i,this.array)),this.data.array[t+0]=r,this.data.array[t+1]=i,this}setXYZ(t,r,i,a){return t=t*this.data.stride+this.offset,this.normalized&&(r=et(r,this.array),i=et(i,this.array),a=et(a,this.array)),this.data.array[t+0]=r,this.data.array[t+1]=i,this.data.array[t+2]=a,this}setXYZW(t,r,i,a,n){return t=t*this.data.stride+this.offset,this.normalized&&(r=et(r,this.array),i=et(i,this.array),a=et(a,this.array),n=et(n,this.array)),this.data.array[t+0]=r,this.data.array[t+1]=i,this.data.array[t+2]=a,this.data.array[t+3]=n,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let r=[];for(let i=0;i<this.count;i++){let a=i*this.data.stride+this.offset;for(let n=0;n<this.itemSize;n++)r.push(this.data.array[a+n])}return new vt(new this.array.constructor(r),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new vh(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let r=[];for(let i=0;i<this.count;i++){let a=i*this.data.stride+this.offset;for(let n=0;n<this.itemSize;n++)r.push(this.data.array[a+n])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:r,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},on=class extends er{static get type(){return"SpriteMaterial"}constructor(e){super(),this.isSpriteMaterial=!0,this.color=new Ne(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Di,la=new L,Ui=new L,Ni=new L,Oi=new Fe,ua=new Fe,cu=new Ge,ln=new L,ha=new L,un=new L,du=new Fe,io=new Fe,pu=new Fe,ao=class extends ct{constructor(e=new on){if(super(),this.isSprite=!0,this.type="Sprite",Di===void 0){Di=new Rt;let t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),r=new hu(t,5);Di.setIndex([0,1,2,0,2,3]),Di.setAttribute("position",new ro(r,3,0,!1)),Di.setAttribute("uv",new ro(r,2,3,!1))}this.geometry=Di,this.material=e,this.center=new Fe(.5,.5)}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Ui.setFromMatrixScale(this.matrixWorld),cu.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),Ni.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Ui.multiplyScalar(-Ni.z);let r=this.material.rotation,i,a;r!==0&&(a=Math.cos(r),i=Math.sin(r));let n=this.center;hn(ln.set(-.5,-.5,0),Ni,n,Ui,i,a),hn(ha.set(.5,-.5,0),Ni,n,Ui,i,a),hn(un.set(.5,.5,0),Ni,n,Ui,i,a),du.set(0,0),io.set(1,0),pu.set(1,1);let s=e.ray.intersectTriangle(ln,ha,un,!1,la);if(s===null&&(hn(ha.set(-.5,.5,0),Ni,n,Ui,i,a),io.set(0,1),s=e.ray.intersectTriangle(ln,un,ha,!1,la),s===null))return;let o=e.ray.origin.distanceTo(la);o<e.near||o>e.far||t.push({distance:o,point:la.clone(),uv:bi.getInterpolation(la,ln,ha,un,du,io,pu,new Fe),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}};function hn(e,t,r,i,a,n){Oi.subVectors(e,r).addScalar(.5).multiply(i),a!==void 0?(ua.x=n*Oi.x-a*Oi.y,ua.y=a*Oi.x+n*Oi.y):ua.copy(Oi),e.copy(t),e.x+=ua.x,e.y+=ua.y,e.applyMatrix4(cu)}var fu=new L,mu=new tt,gu=new tt,Qg=new L,_u=new Ge,cn=new L,no=new ir,vu=new Ge,so=new Ha,e_=class extends ut{constructor(e,t){super(e,t),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=No,this.bindMatrix=new Ge,this.bindMatrixInverse=new Ge,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){let e=this.geometry;this.boundingBox===null&&(this.boundingBox=new Zt),this.boundingBox.makeEmpty();let t=e.getAttribute("position");for(let r=0;r<t.count;r++)this.getVertexPosition(r,cn),this.boundingBox.expandByPoint(cn)}computeBoundingSphere(){let e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new ir),this.boundingSphere.makeEmpty();let t=e.getAttribute("position");for(let r=0;r<t.count;r++)this.getVertexPosition(r,cn),this.boundingSphere.expandByPoint(cn)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,t){let r=this.material,i=this.matrixWorld;r!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),no.copy(this.boundingSphere),no.applyMatrix4(i),e.ray.intersectsSphere(no)!==!1&&(vu.copy(i).invert(),so.copy(e.ray).applyMatrix4(vu),!(this.boundingBox!==null&&so.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,t,so)))}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){this.skeleton=e,t===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld),this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){let e=new tt,t=this.geometry.attributes.skinWeight;for(let r=0,i=t.count;r<i;r++){e.fromBufferAttribute(t,r);let a=1/e.manhattanLength();a!==1/0?e.multiplyScalar(a):e.set(1,0,0,0),t.setXYZW(r,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===No?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===uc?this.bindMatrixInverse.copy(this.bindMatrix).invert():console.warn("THREE.SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,t){let r=this.skeleton,i=this.geometry;mu.fromBufferAttribute(i.attributes.skinIndex,e),gu.fromBufferAttribute(i.attributes.skinWeight,e),fu.copy(t).applyMatrix4(this.bindMatrix),t.set(0,0,0);for(let a=0;a<4;a++){let n=gu.getComponent(a);if(n!==0){let s=mu.getComponent(a);_u.multiplyMatrices(r.bones[s].matrixWorld,r.boneInverses[s]),t.addScaledVector(Qg.copy(fu).applyMatrix4(_u),n)}}return t.applyMatrix4(this.bindMatrixInverse)}},xu=class extends ct{constructor(){super(),this.isBone=!0,this.type="Bone"}},ca=class extends Et{constructor(e=null,t=1,r=1,i,a,n,s,o,l=wt,u=wt,h,c){super(null,n,s,o,l,u,i,a,h,c),this.isDataTexture=!0,this.image={data:e,width:t,height:r},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}},yu=new Ge,t_=new Ge,r_=class xh{constructor(t=[],r=[]){this.uuid=qt(),this.bones=t.slice(0),this.boneInverses=r,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){let t=this.bones,r=this.boneInverses;if(this.boneMatrices=new Float32Array(t.length*16),r.length===0)this.calculateInverses();else if(t.length!==r.length){console.warn("THREE.Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let i=0,a=this.bones.length;i<a;i++)this.boneInverses.push(new Ge)}}calculateInverses(){this.boneInverses.length=0;for(let t=0,r=this.bones.length;t<r;t++){let i=new Ge;this.bones[t]&&i.copy(this.bones[t].matrixWorld).invert(),this.boneInverses.push(i)}}pose(){for(let t=0,r=this.bones.length;t<r;t++){let i=this.bones[t];i&&i.matrixWorld.copy(this.boneInverses[t]).invert()}for(let t=0,r=this.bones.length;t<r;t++){let i=this.bones[t];i&&(i.parent&&i.parent.isBone?(i.matrix.copy(i.parent.matrixWorld).invert(),i.matrix.multiply(i.matrixWorld)):i.matrix.copy(i.matrixWorld),i.matrix.decompose(i.position,i.quaternion,i.scale))}}update(){let t=this.bones,r=this.boneInverses,i=this.boneMatrices,a=this.boneTexture;for(let n=0,s=t.length;n<s;n++){let o=t[n]?t[n].matrixWorld:t_;yu.multiplyMatrices(o,r[n]),yu.toArray(i,n*16)}a!==null&&(a.needsUpdate=!0)}clone(){return new xh(this.bones,this.boneInverses)}computeBoneTexture(){let t=Math.sqrt(this.bones.length*4);t=Math.ceil(t/4)*4,t=Math.max(t,4);let r=new Float32Array(t*t*4);r.set(this.boneMatrices);let i=new ca(r,t,t,kt,Yt);return i.needsUpdate=!0,this.boneMatrices=r,this.boneTexture=i,this}getBoneByName(t){for(let r=0,i=this.bones.length;r<i;r++){let a=this.bones[r];if(a.name===t)return a}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(t,r){this.uuid=t.uuid;for(let i=0,a=t.bones.length;i<a;i++){let n=t.bones[i],s=r[n];s===void 0&&(console.warn("THREE.Skeleton: No bone found with UUID:",n),s=new xu),this.bones.push(s),this.boneInverses.push(new Ge().fromArray(t.boneInverses[i]))}return this.init(),this}toJSON(){let t={metadata:{version:4.6,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};t.uuid=this.uuid;let r=this.bones,i=this.boneInverses;for(let a=0,n=r.length;a<n;a++){let s=r[a];t.bones.push(s.uuid);let o=i[a];t.boneInverses.push(o.toArray())}return t}},oo=class extends vt{constructor(e,t,r,i=1){super(e,t,r),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=i}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},Fi=new Ge,Mu=new Ge,dn=[],Su=new Zt,i_=new Ge,da=new ut,pa=new ir,a_=class extends ut{constructor(e,t,r){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new oo(new Float32Array(r*16),16),this.instanceColor=null,this.morphTexture=null,this.count=r,this.boundingBox=null,this.boundingSphere=null;for(let i=0;i<r;i++)this.setMatrixAt(i,i_)}computeBoundingBox(){let e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new Zt),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let r=0;r<t;r++)this.getMatrixAt(r,Fi),Su.copy(e.boundingBox).applyMatrix4(Fi),this.boundingBox.union(Su)}computeBoundingSphere(){let e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new ir),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let r=0;r<t;r++)this.getMatrixAt(r,Fi),pa.copy(e.boundingSphere).applyMatrix4(Fi),this.boundingSphere.union(pa)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){let r=t.morphTargetInfluences,i=this.morphTexture.source.data.data,a=r.length+1,n=e*a+1;for(let s=0;s<r.length;s++)r[s]=i[n+s]}raycast(e,t){let r=this.matrixWorld,i=this.count;if(da.geometry=this.geometry,da.material=this.material,da.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),pa.copy(this.boundingSphere),pa.applyMatrix4(r),e.ray.intersectsSphere(pa)!==!1))for(let a=0;a<i;a++){this.getMatrixAt(a,Fi),Mu.multiplyMatrices(r,Fi),da.matrixWorld=Mu,da.raycast(e,dn);for(let n=0,s=dn.length;n<s;n++){let o=dn[n];o.instanceId=a,o.object=this,t.push(o)}dn.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new oo(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}setMorphAt(e,t){let r=t.morphTargetInfluences,i=r.length+1;this.morphTexture===null&&(this.morphTexture=new ca(new Float32Array(i*this.count),i,this.count,Wn,Yt));let a=this.morphTexture.source.data.data,n=0;for(let l=0;l<r.length;l++)n+=r[l];let s=this.geometry.morphTargetsRelative?1:1-n,o=i*e;a[o]=s,a.set(r,o+1)}updateMorphTargets(){}dispose(){return this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null),this}},lo=class extends er{static get type(){return"LineBasicMaterial"}constructor(e){super(),this.isLineBasicMaterial=!0,this.color=new Ne(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},pn=new L,fn=new L,Tu=new Ge,fa=new Ha,mn=new ir,uo=new L,Eu=new L,ho=class extends ct{constructor(e=new Rt,t=new lo){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,r=[0];for(let i=1,a=t.count;i<a;i++)pn.fromBufferAttribute(t,i-1),fn.fromBufferAttribute(t,i),r[i]=r[i-1],r[i]+=pn.distanceTo(fn);e.setAttribute("lineDistance",new dt(r,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){let r=this.geometry,i=this.matrixWorld,a=e.params.Line.threshold,n=r.drawRange;if(r.boundingSphere===null&&r.computeBoundingSphere(),mn.copy(r.boundingSphere),mn.applyMatrix4(i),mn.radius+=a,e.ray.intersectsSphere(mn)===!1)return;Tu.copy(i).invert(),fa.copy(e.ray).applyMatrix4(Tu);let s=a/((this.scale.x+this.scale.y+this.scale.z)/3),o=s*s,l=this.isLineSegments?2:1,u=r.index,h=r.attributes.position;if(u!==null){let c=Math.max(0,n.start),d=Math.min(u.count,n.start+n.count);for(let m=c,_=d-1;m<_;m+=l){let g=u.getX(m),f=u.getX(m+1),p=gn(this,e,fa,o,g,f);p&&t.push(p)}if(this.isLineLoop){let m=u.getX(d-1),_=u.getX(c),g=gn(this,e,fa,o,m,_);g&&t.push(g)}}else{let c=Math.max(0,n.start),d=Math.min(h.count,n.start+n.count);for(let m=c,_=d-1;m<_;m+=l){let g=gn(this,e,fa,o,m,m+1);g&&t.push(g)}if(this.isLineLoop){let m=gn(this,e,fa,o,d-1,c);m&&t.push(m)}}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let r=e[t[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let i=0,a=r.length;i<a;i++){let n=r[i].name||String(i);this.morphTargetInfluences.push(0),this.morphTargetDictionary[n]=i}}}}};function gn(e,t,r,i,a,n){let s=e.geometry.attributes.position;if(pn.fromBufferAttribute(s,a),fn.fromBufferAttribute(s,n),r.distanceSqToSegment(pn,fn,uo,Eu)>i)return;uo.applyMatrix4(e.matrixWorld);let o=t.ray.origin.distanceTo(uo);if(!(o<t.near||o>t.far))return{distance:o,point:Eu.clone().applyMatrix4(e.matrixWorld),index:a,face:null,faceIndex:null,barycoord:null,object:e}}var bu=new L,wu=new L,Au=class extends ho{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,r=[];for(let i=0,a=t.count;i<a;i+=2)bu.fromBufferAttribute(t,i),wu.fromBufferAttribute(t,i+1),r[i]=i===0?0:r[i-1],r[i+1]=r[i]+bu.distanceTo(wu);e.setAttribute("lineDistance",new dt(r,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}},n_=class extends ho{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type="LineLoop"}},co=class extends er{static get type(){return"PointsMaterial"}constructor(e){super(),this.isPointsMaterial=!0,this.color=new Ne(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Ru=new Ge,po=new Ha,_n=new ir,vn=new L,Cu=class extends ct{constructor(e=new Rt,t=new co){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){let r=this.geometry,i=this.matrixWorld,a=e.params.Points.threshold,n=r.drawRange;if(r.boundingSphere===null&&r.computeBoundingSphere(),_n.copy(r.boundingSphere),_n.applyMatrix4(i),_n.radius+=a,e.ray.intersectsSphere(_n)===!1)return;Ru.copy(i).invert(),po.copy(e.ray).applyMatrix4(Ru);let s=a/((this.scale.x+this.scale.y+this.scale.z)/3),o=s*s,l=r.index,u=r.attributes.position;if(l!==null){let h=Math.max(0,n.start),c=Math.min(l.count,n.start+n.count);for(let d=h,m=c;d<m;d++){let _=l.getX(d);vn.fromBufferAttribute(u,_),Lu(vn,_,o,i,e,t,this)}}else{let h=Math.max(0,n.start),c=Math.min(u.count,n.start+n.count);for(let d=h,m=c;d<m;d++)vn.fromBufferAttribute(u,d),Lu(vn,d,o,i,e,t,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let r=e[t[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let i=0,a=r.length;i<a;i++){let n=r[i].name||String(i);this.morphTargetInfluences.push(0),this.morphTargetDictionary[n]=i}}}}};function Lu(e,t,r,i,a,n,s){let o=po.distanceSqToPoint(e);if(o<r){let l=new L;po.closestPointToPoint(e,l),l.applyMatrix4(i);let u=a.ray.origin.distanceTo(l);if(u<a.near||u>a.far)return;n.push({distance:u,distanceToRay:Math.sqrt(o),point:l,index:t,face:null,faceIndex:null,barycoord:null,object:s})}}var fo=class extends Et{constructor(e,t,r,i,a,n,s,o,l){super(e,t,r,i,a,n,s,o,l),this.isCanvasTexture=!0,this.needsUpdate=!0}},Pu=class yh extends Rt{constructor(t=1,r=1,i=1,a=32,n=1,s=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:r,height:i,radialSegments:a,heightSegments:n,openEnded:s,thetaStart:o,thetaLength:l};let u=this;a=Math.floor(a),n=Math.floor(n);let h=[],c=[],d=[],m=[],_=0,g=[],f=i/2,p=0;x(),s===!1&&(t>0&&v(!0),r>0&&v(!1)),this.setIndex(h),this.setAttribute("position",new dt(c,3)),this.setAttribute("normal",new dt(d,3)),this.setAttribute("uv",new dt(m,2));function x(){let E=new L,I=new L,w=0,R=(r-t)/i;for(let U=0;U<=n;U++){let M=[],T=U/n,P=T*(r-t)+t;for(let z=0;z<=a;z++){let q=z/a,K=q*l+o,Y=Math.sin(K),W=Math.cos(K);I.x=P*Y,I.y=-T*i+f,I.z=P*W,c.push(I.x,I.y,I.z),E.set(Y,R,W).normalize(),d.push(E.x,E.y,E.z),m.push(q,1-T),M.push(_++)}g.push(M)}for(let U=0;U<a;U++)for(let M=0;M<n;M++){let T=g[M][U],P=g[M+1][U],z=g[M+1][U+1],q=g[M][U+1];(t>0||M!==0)&&(h.push(T,P,q),w+=3),(r>0||M!==n-1)&&(h.push(P,z,q),w+=3)}u.addGroup(p,w,0),p+=w}function v(E){let I=_,w=new Fe,R=new L,U=0,M=E===!0?t:r,T=E===!0?1:-1;for(let z=1;z<=a;z++)c.push(0,f*T,0),d.push(0,T,0),m.push(.5,.5),_++;let P=_;for(let z=0;z<=a;z++){let q=z/a*l+o,K=Math.cos(q),Y=Math.sin(q);R.x=M*Y,R.y=f*T,R.z=M*K,c.push(R.x,R.y,R.z),d.push(0,T,0),w.x=K*.5+.5,w.y=Y*.5*T+.5,m.push(w.x,w.y),_++}for(let z=0;z<a;z++){let q=I+z,K=P+z;E===!0?h.push(K,K+1,q):h.push(K+1,K,q),U+=3}u.addGroup(p,U,E===!0?1:2),p+=U}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new yh(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Iu=class Mh extends Pu{constructor(t=1,r=1,i=32,a=1,n=!1,s=0,o=Math.PI*2){super(0,t,r,i,a,n,s,o),this.type="ConeGeometry",this.parameters={radius:t,height:r,radialSegments:i,heightSegments:a,openEnded:n,thetaStart:s,thetaLength:o}}static fromJSON(t){return new Mh(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Du=class Sh extends Rt{constructor(t=[],r=[],i=1,a=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:r,radius:i,detail:a};let n=[],s=[];o(a),u(i),h(),this.setAttribute("position",new dt(n,3)),this.setAttribute("normal",new dt(n.slice(),3)),this.setAttribute("uv",new dt(s,2)),a===0?this.computeVertexNormals():this.normalizeNormals();function o(x){let v=new L,E=new L,I=new L;for(let w=0;w<r.length;w+=3)m(r[w+0],v),m(r[w+1],E),m(r[w+2],I),l(v,E,I,x)}function l(x,v,E,I){let w=I+1,R=[];for(let U=0;U<=w;U++){R[U]=[];let M=x.clone().lerp(E,U/w),T=v.clone().lerp(E,U/w),P=w-U;for(let z=0;z<=P;z++)z===0&&U===w?R[U][z]=M:R[U][z]=M.clone().lerp(T,z/P)}for(let U=0;U<w;U++)for(let M=0;M<2*(w-U)-1;M++){let T=Math.floor(M/2);M%2===0?(d(R[U][T+1]),d(R[U+1][T]),d(R[U][T])):(d(R[U][T+1]),d(R[U+1][T+1]),d(R[U+1][T]))}}function u(x){let v=new L;for(let E=0;E<n.length;E+=3)v.x=n[E+0],v.y=n[E+1],v.z=n[E+2],v.normalize().multiplyScalar(x),n[E+0]=v.x,n[E+1]=v.y,n[E+2]=v.z}function h(){let x=new L;for(let v=0;v<n.length;v+=3){x.x=n[v+0],x.y=n[v+1],x.z=n[v+2];let E=f(x)/2/Math.PI+.5,I=p(x)/Math.PI+.5;s.push(E,1-I)}_(),c()}function c(){for(let x=0;x<s.length;x+=6){let v=s[x+0],E=s[x+2],I=s[x+4],w=Math.max(v,E,I),R=Math.min(v,E,I);w>.9&&R<.1&&(v<.2&&(s[x+0]+=1),E<.2&&(s[x+2]+=1),I<.2&&(s[x+4]+=1))}}function d(x){n.push(x.x,x.y,x.z)}function m(x,v){let E=x*3;v.x=t[E+0],v.y=t[E+1],v.z=t[E+2]}function _(){let x=new L,v=new L,E=new L,I=new L,w=new Fe,R=new Fe,U=new Fe;for(let M=0,T=0;M<n.length;M+=9,T+=6){x.set(n[M+0],n[M+1],n[M+2]),v.set(n[M+3],n[M+4],n[M+5]),E.set(n[M+6],n[M+7],n[M+8]),w.set(s[T+0],s[T+1]),R.set(s[T+2],s[T+3]),U.set(s[T+4],s[T+5]),I.copy(x).add(v).add(E).divideScalar(3);let P=f(I);g(w,T+0,x,P),g(R,T+2,v,P),g(U,T+4,E,P)}}function g(x,v,E,I){I<0&&x.x===1&&(s[v]=x.x-1),E.x===0&&E.z===0&&(s[v]=I/2/Math.PI+.5)}function f(x){return Math.atan2(x.z,-x.x)}function p(x){return Math.atan2(-x.y,Math.sqrt(x.x*x.x+x.z*x.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Sh(t.vertices,t.indices,t.radius,t.details)}},s_=class Th extends Du{constructor(t=1,r=0){let i=(1+Math.sqrt(5))/2,a=[-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],n=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(a,n,t,r),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:r}}static fromJSON(t){return new Th(t.radius,t.detail)}},o_=class Eh extends Du{constructor(t=1,r=0){let i=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],a=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(i,a,t,r),this.type="OctahedronGeometry",this.parameters={radius:t,detail:r}}static fromJSON(t){return new Eh(t.radius,t.detail)}},l_=class bh extends Rt{constructor(t=.5,r=1,i=32,a=1,n=0,s=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:r,thetaSegments:i,phiSegments:a,thetaStart:n,thetaLength:s},i=Math.max(3,i),a=Math.max(1,a);let o=[],l=[],u=[],h=[],c=t,d=(r-t)/a,m=new L,_=new Fe;for(let g=0;g<=a;g++){for(let f=0;f<=i;f++){let p=n+f/i*s;m.x=c*Math.cos(p),m.y=c*Math.sin(p),l.push(m.x,m.y,m.z),u.push(0,0,1),_.x=(m.x/r+1)/2,_.y=(m.y/r+1)/2,h.push(_.x,_.y)}c+=d}for(let g=0;g<a;g++){let f=g*(i+1);for(let p=0;p<i;p++){let x=p+f,v=x,E=x+i+1,I=x+i+2,w=x+1;o.push(v,E,w),o.push(E,I,w)}}this.setIndex(o),this.setAttribute("position",new dt(l,3)),this.setAttribute("normal",new dt(u,3)),this.setAttribute("uv",new dt(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new bh(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}},Uu=class wh extends Rt{constructor(t=1,r=32,i=16,a=0,n=Math.PI*2,s=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:r,heightSegments:i,phiStart:a,phiLength:n,thetaStart:s,thetaLength:o},r=Math.max(3,Math.floor(r)),i=Math.max(2,Math.floor(i));let l=Math.min(s+o,Math.PI),u=0,h=[],c=new L,d=new L,m=[],_=[],g=[],f=[];for(let p=0;p<=i;p++){let x=[],v=p/i,E=0;p===0&&s===0?E=.5/r:p===i&&l===Math.PI&&(E=-.5/r);for(let I=0;I<=r;I++){let w=I/r;c.x=-t*Math.cos(a+w*n)*Math.sin(s+v*o),c.y=t*Math.cos(s+v*o),c.z=t*Math.sin(a+w*n)*Math.sin(s+v*o),_.push(c.x,c.y,c.z),d.copy(c).normalize(),g.push(d.x,d.y,d.z),f.push(w+E,1-v),x.push(u++)}h.push(x)}for(let p=0;p<i;p++)for(let x=0;x<r;x++){let v=h[p][x+1],E=h[p][x],I=h[p+1][x],w=h[p+1][x+1];(p!==0||s>0)&&m.push(v,E,w),(p!==i-1||l<Math.PI)&&m.push(E,I,w)}this.setIndex(m),this.setAttribute("position",new dt(_,3)),this.setAttribute("normal",new dt(g,3)),this.setAttribute("uv",new dt(f,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new wh(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}},tr=class extends er{static get type(){return"MeshStandardMaterial"}constructor(e){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.color=new Ne(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ne(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=$o,this.normalScale=new Fe(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ur,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},sr=class extends tr{static get type(){return"MeshPhysicalMaterial"}constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new Fe(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Tt(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(t){this.ior=(1+.4*t)/(1-.4*t)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new Ne(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new Ne(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new Ne(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get dispersion(){return this._dispersion}set dispersion(e){this._dispersion>0!=e>0&&this.version++,this._dispersion=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.dispersion=e.dispersion,this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}};function xn(e,t,r){return!e||!r&&e.constructor===t?e:typeof t.BYTES_PER_ELEMENT=="number"?new t(e):Array.prototype.slice.call(e)}function u_(e){return ArrayBuffer.isView(e)&&!(e instanceof DataView)}function h_(e){function t(a,n){return e[a]-e[n]}let r=e.length,i=new Array(r);for(let a=0;a!==r;++a)i[a]=a;return i.sort(t),i}function Nu(e,t,r){let i=e.length,a=new e.constructor(i);for(let n=0,s=0;s!==i;++n){let o=r[n]*t;for(let l=0;l!==t;++l)a[s++]=e[o+l]}return a}function Ou(e,t,r,i){let a=1,n=e[0];for(;n!==void 0&&n[i]===void 0;)n=e[a++];if(n===void 0)return;let s=n[i];if(s!==void 0)if(Array.isArray(s))do s=n[i],s!==void 0&&(t.push(n.time),r.push.apply(r,s)),n=e[a++];while(n!==void 0);else if(s.toArray!==void 0)do s=n[i],s!==void 0&&(t.push(n.time),s.toArray(r,r.length)),n=e[a++];while(n!==void 0);else do s=n[i],s!==void 0&&(t.push(n.time),r.push(s)),n=e[a++];while(n!==void 0)}var ma=class{constructor(e,t,r,i){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=i!==void 0?i:new t.constructor(r),this.sampleValues=t,this.valueSize=r,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,r=this._cachedIndex,i=t[r],a=t[r-1];r:{e:{let n;t:{i:if(!(e<i)){for(let s=r+2;;){if(i===void 0){if(e<a)break i;return r=t.length,this._cachedIndex=r,this.copySampleValue_(r-1)}if(r===s)break;if(a=i,i=t[++r],e<i)break e}n=t.length;break t}if(!(e>=a)){let s=t[1];e<s&&(r=2,a=s);for(let o=r-2;;){if(a===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(r===o)break;if(i=a,a=t[--r-1],e>=a)break e}n=r,r=0;break t}break r}for(;r<n;){let s=r+n>>>1;e<t[s]?n=s:r=s+1}if(i=t[r],a=t[r-1],a===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===void 0)return r=t.length,this._cachedIndex=r,this.copySampleValue_(r-1)}this._cachedIndex=r,this.intervalChanged_(r,a,i)}return this.interpolate_(r,a,e,i)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,r=this.sampleValues,i=this.valueSize,a=e*i;for(let n=0;n!==i;++n)t[n]=r[a+n];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},c_=class extends ma{constructor(e,t,r,i){super(e,t,r,i),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Yo,endingEnd:Yo}}intervalChanged_(e,t,r){let i=this.parameterPositions,a=e-2,n=e+1,s=i[a],o=i[n];if(s===void 0)switch(this.getSettings_().endingStart){case qo:a=e,s=2*t-r;break;case Ko:a=i.length-2,s=t+i[a]-i[a+1];break;default:a=e,s=r}if(o===void 0)switch(this.getSettings_().endingEnd){case qo:n=e,o=2*r-t;break;case Ko:n=1,o=r+i[1]-i[0];break;default:n=e-1,o=t}let l=(r-t)*.5,u=this.valueSize;this._weightPrev=l/(t-s),this._weightNext=l/(o-r),this._offsetPrev=a*u,this._offsetNext=n*u}interpolate_(e,t,r,i){let a=this.resultBuffer,n=this.sampleValues,s=this.valueSize,o=e*s,l=o-s,u=this._offsetPrev,h=this._offsetNext,c=this._weightPrev,d=this._weightNext,m=(r-t)/(i-t),_=m*m,g=_*m,f=-c*g+2*c*_-c*m,p=(1+c)*g+(-1.5-2*c)*_+(-.5+c)*m+1,x=(-1-d)*g+(1.5+d)*_+.5*m,v=d*g-d*_;for(let E=0;E!==s;++E)a[E]=f*n[u+E]+p*n[l+E]+x*n[o+E]+v*n[h+E];return a}},d_=class extends ma{constructor(e,t,r,i){super(e,t,r,i)}interpolate_(e,t,r,i){let a=this.resultBuffer,n=this.sampleValues,s=this.valueSize,o=e*s,l=o-s,u=(r-t)/(i-t),h=1-u;for(let c=0;c!==s;++c)a[c]=n[l+c]*h+n[o+c]*u;return a}},p_=class extends ma{constructor(e,t,r,i){super(e,t,r,i)}interpolate_(e){return this.copySampleValue_(e-1)}},or=class{constructor(e,t,r,i){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=xn(t,this.TimeBufferType),this.values=xn(r,this.ValueBufferType),this.setInterpolation(i||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,r;if(t.toJSON!==this.toJSON)r=t.toJSON(e);else{r={name:e.name,times:xn(e.times,Array),values:xn(e.values,Array)};let i=e.getInterpolation();i!==e.DefaultInterpolation&&(r.interpolation=i)}return r.type=e.ValueTypeName,r}InterpolantFactoryMethodDiscrete(e){return new p_(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new d_(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new c_(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case $i:t=this.InterpolantFactoryMethodDiscrete;break;case Ji:t=this.InterpolantFactoryMethodLinear;break;case ys:t=this.InterpolantFactoryMethodSmooth;break}if(t===void 0){let r="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(r);return console.warn("THREE.KeyframeTrack:",r),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return $i;case this.InterpolantFactoryMethodLinear:return Ji;case this.InterpolantFactoryMethodSmooth:return ys}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let r=0,i=t.length;r!==i;++r)t[r]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let r=0,i=t.length;r!==i;++r)t[r]*=e}return this}trim(e,t){let r=this.times,i=r.length,a=0,n=i-1;for(;a!==i&&r[a]<e;)++a;for(;n!==-1&&r[n]>t;)--n;if(++n,a!==0||n!==i){a>=n&&(n=Math.max(n,1),a=n-1);let s=this.getValueSize();this.times=r.slice(a,n),this.values=this.values.slice(a*s,n*s)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);let r=this.times,i=this.values,a=r.length;a===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let n=null;for(let s=0;s!==a;s++){let o=r[s];if(typeof o=="number"&&isNaN(o)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,s,o),e=!1;break}if(n!==null&&n>o){console.error("THREE.KeyframeTrack: Out of order keys.",this,s,o,n),e=!1;break}n=o}if(i!==void 0&&u_(i))for(let s=0,o=i.length;s!==o;++s){let l=i[s];if(isNaN(l)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,s,l),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),r=this.getValueSize(),i=this.getInterpolation()===ys,a=e.length-1,n=1;for(let s=1;s<a;++s){let o=!1,l=e[s],u=e[s+1];if(l!==u&&(s!==1||l!==e[0]))if(i)o=!0;else{let h=s*r,c=h-r,d=h+r;for(let m=0;m!==r;++m){let _=t[h+m];if(_!==t[c+m]||_!==t[d+m]){o=!0;break}}}if(o){if(s!==n){e[n]=e[s];let h=s*r,c=n*r;for(let d=0;d!==r;++d)t[c+d]=t[h+d]}++n}}if(a>0){e[n]=e[a];for(let s=a*r,o=n*r,l=0;l!==r;++l)t[o+l]=t[s+l];++n}return n!==e.length?(this.times=e.slice(0,n),this.values=t.slice(0,n*r)):(this.times=e,this.values=t),this}clone(){let e=this.times.slice(),t=this.values.slice(),r=this.constructor,i=new r(this.name,e,t);return i.createInterpolant=this.createInterpolant,i}};or.prototype.TimeBufferType=Float32Array,or.prototype.ValueBufferType=Float32Array,or.prototype.DefaultInterpolation=Ji;var Bi=class extends or{constructor(e,t,r){super(e,t,r)}};Bi.prototype.ValueTypeName="bool",Bi.prototype.ValueBufferType=Array,Bi.prototype.DefaultInterpolation=$i,Bi.prototype.InterpolantFactoryMethodLinear=void 0,Bi.prototype.InterpolantFactoryMethodSmooth=void 0;var Fu=class extends or{};Fu.prototype.ValueTypeName="color";var zi=class extends or{};zi.prototype.ValueTypeName="number";var f_=class extends ma{constructor(e,t,r,i){super(e,t,r,i)}interpolate_(e,t,r,i){let a=this.resultBuffer,n=this.sampleValues,s=this.valueSize,o=(r-t)/(i-t),l=e*s;for(let u=l+s;l!==u;l+=4)Cr.slerpFlat(a,0,n,l-s,n,l,o);return a}},Hi=class extends or{InterpolantFactoryMethodLinear(e){return new f_(this.times,this.values,this.getValueSize(),e)}};Hi.prototype.ValueTypeName="quaternion",Hi.prototype.InterpolantFactoryMethodSmooth=void 0;var ki=class extends or{constructor(e,t,r){super(e,t,r)}};ki.prototype.ValueTypeName="string",ki.prototype.ValueBufferType=Array,ki.prototype.DefaultInterpolation=$i,ki.prototype.InterpolantFactoryMethodLinear=void 0,ki.prototype.InterpolantFactoryMethodSmooth=void 0;var Vi=class extends or{};Vi.prototype.ValueTypeName="vector";var m_=class{constructor(e="",t=-1,r=[],i=hc){this.name=e,this.tracks=r,this.duration=t,this.blendMode=i,this.uuid=qt(),this.duration<0&&this.resetDuration()}static parse(e){let t=[],r=e.tracks,i=1/(e.fps||1);for(let n=0,s=r.length;n!==s;++n)t.push(__(r[n]).scale(i));let a=new this(e.name,e.duration,t,e.blendMode);return a.uuid=e.uuid,a}static toJSON(e){let t=[],r=e.tracks,i={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode};for(let a=0,n=r.length;a!==n;++a)t.push(or.toJSON(r[a]));return i}static CreateFromMorphTargetSequence(e,t,r,i){let a=t.length,n=[];for(let s=0;s<a;s++){let o=[],l=[];o.push((s+a-1)%a,s,(s+1)%a),l.push(0,1,0);let u=h_(o);o=Nu(o,1,u),l=Nu(l,1,u),!i&&o[0]===0&&(o.push(a),l.push(l[0])),n.push(new zi(".morphTargetInfluences["+t[s].name+"]",o,l).scale(1/r))}return new this(e,-1,n)}static findByName(e,t){let r=e;if(!Array.isArray(e)){let i=e;r=i.geometry&&i.geometry.animations||i.animations}for(let i=0;i<r.length;i++)if(r[i].name===t)return r[i];return null}static CreateClipsFromMorphTargetSequences(e,t,r){let i={},a=/^([\w-]*?)([\d]+)$/;for(let s=0,o=e.length;s<o;s++){let l=e[s],u=l.name.match(a);if(u&&u.length>1){let h=u[1],c=i[h];c||(i[h]=c=[]),c.push(l)}}let n=[];for(let s in i)n.push(this.CreateFromMorphTargetSequence(s,i[s],t,r));return n}static parseAnimation(e,t){if(!e)return console.error("THREE.AnimationClip: No animation in JSONLoader data."),null;let r=function(u,h,c,d,m){if(c.length!==0){let _=[],g=[];Ou(c,_,g,d),_.length!==0&&m.push(new u(h,_,g))}},i=[],a=e.name||"default",n=e.fps||30,s=e.blendMode,o=e.length||-1,l=e.hierarchy||[];for(let u=0;u<l.length;u++){let h=l[u].keys;if(!(!h||h.length===0))if(h[0].morphTargets){let c={},d;for(d=0;d<h.length;d++)if(h[d].morphTargets)for(let m=0;m<h[d].morphTargets.length;m++)c[h[d].morphTargets[m]]=-1;for(let m in c){let _=[],g=[];for(let f=0;f!==h[d].morphTargets.length;++f){let p=h[d];_.push(p.time),g.push(p.morphTarget===m?1:0)}i.push(new zi(".morphTargetInfluence["+m+"]",_,g))}o=c.length*n}else{let c=".bones["+t[u].name+"]";r(Vi,c+".position",h,"pos",i),r(Hi,c+".quaternion",h,"rot",i),r(Vi,c+".scale",h,"scl",i)}}return i.length===0?null:new this(a,o,i,s)}resetDuration(){let e=this.tracks,t=0;for(let r=0,i=e.length;r!==i;++r){let a=this.tracks[r];t=Math.max(t,a.times[a.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e=e&&this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){let e=[];for(let t=0;t<this.tracks.length;t++)e.push(this.tracks[t].clone());return new this.constructor(this.name,this.duration,e,this.blendMode)}toJSON(){return this.constructor.toJSON(this)}};function g_(e){switch(e.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return zi;case"vector":case"vector2":case"vector3":case"vector4":return Vi;case"color":return Fu;case"quaternion":return Hi;case"bool":case"boolean":return Bi;case"string":return ki}throw new Error("THREE.KeyframeTrack: Unsupported typeName: "+e)}function __(e){if(e.type===void 0)throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");let t=g_(e.type);if(e.times===void 0){let r=[],i=[];Ou(e.keys,r,i,"value"),e.times=r,e.values=i}return t.parse!==void 0?t.parse(e):new t(e.name,e.times,e.values,e.interpolation)}var Br={enabled:!1,files:{},add:function(e,t){this.enabled!==!1&&(this.files[e]=t)},get:function(e){if(this.enabled!==!1)return this.files[e]},remove:function(e){delete this.files[e]},clear:function(){this.files={}}},v_=class{constructor(e,t,r){let i=this,a=!1,n=0,s=0,o,l=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=r,this.itemStart=function(u){s++,a===!1&&i.onStart!==void 0&&i.onStart(u,n,s),a=!0},this.itemEnd=function(u){n++,i.onProgress!==void 0&&i.onProgress(u,n,s),n===s&&(a=!1,i.onLoad!==void 0&&i.onLoad())},this.itemError=function(u){i.onError!==void 0&&i.onError(u)},this.resolveURL=function(u){return o?o(u):u},this.setURLModifier=function(u){return o=u,this},this.addHandler=function(u,h){return l.push(u,h),this},this.removeHandler=function(u){let h=l.indexOf(u);return h!==-1&&l.splice(h,2),this},this.getHandler=function(u){for(let h=0,c=l.length;h<c;h+=2){let d=l[h],m=l[h+1];if(d.global&&(d.lastIndex=0),d.test(u))return m}return null}}},x_=new v_,Gi=class{constructor(e){this.manager=e!==void 0?e:x_,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){let r=this;return new Promise(function(i,a){r.load(e,i,t,a)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}};Gi.DEFAULT_MATERIAL_NAME="__DEFAULT";var yr={},y_=class extends Error{constructor(e,t){super(e),this.response=t}},yn=class extends Gi{constructor(e){super(e)}load(e,t,r,i){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let a=Br.get(e);if(a!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(a),this.manager.itemEnd(e)},0),a;if(yr[e]!==void 0){yr[e].push({onLoad:t,onProgress:r,onError:i});return}yr[e]=[],yr[e].push({onLoad:t,onProgress:r,onError:i});let n=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin"}),s=this.mimeType,o=this.responseType;fetch(n).then(l=>{if(l.status===200||l.status===0){if(l.status===0&&console.warn("THREE.FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||l.body===void 0||l.body.getReader===void 0)return l;let u=yr[e],h=l.body.getReader(),c=l.headers.get("X-File-Size")||l.headers.get("Content-Length"),d=c?parseInt(c):0,m=d!==0,_=0,g=new ReadableStream({start(f){p();function p(){h.read().then(({done:x,value:v})=>{if(x)f.close();else{_+=v.byteLength;let E=new ProgressEvent("progress",{lengthComputable:m,loaded:_,total:d});for(let I=0,w=u.length;I<w;I++){let R=u[I];R.onProgress&&R.onProgress(E)}f.enqueue(v),p()}},x=>{f.error(x)})}}});return new Response(g)}else throw new y_(`fetch for "${l.url}" responded with ${l.status}: ${l.statusText}`,l)}).then(l=>{switch(o){case"arraybuffer":return l.arrayBuffer();case"blob":return l.blob();case"document":return l.text().then(u=>new DOMParser().parseFromString(u,s));case"json":return l.json();default:if(s===void 0)return l.text();{let u=/charset="?([^;"\s]*)"?/i.exec(s),h=u&&u[1]?u[1].toLowerCase():void 0,c=new TextDecoder(h);return l.arrayBuffer().then(d=>c.decode(d))}}}).then(l=>{Br.add(e,l);let u=yr[e];delete yr[e];for(let h=0,c=u.length;h<c;h++){let d=u[h];d.onLoad&&d.onLoad(l)}}).catch(l=>{let u=yr[e];if(u===void 0)throw this.manager.itemError(e),l;delete yr[e];for(let h=0,c=u.length;h<c;h++){let d=u[h];d.onError&&d.onError(l)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}},M_=class extends Gi{constructor(e){super(e)}load(e,t,r,i){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let a=this,n=Br.get(e);if(n!==void 0)return a.manager.itemStart(e),setTimeout(function(){t&&t(n),a.manager.itemEnd(e)},0),n;let s=ta("img");function o(){u(),Br.add(e,this),t&&t(this),a.manager.itemEnd(e)}function l(h){u(),i&&i(h),a.manager.itemError(e),a.manager.itemEnd(e)}function u(){s.removeEventListener("load",o,!1),s.removeEventListener("error",l,!1)}return s.addEventListener("load",o,!1),s.addEventListener("error",l,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(s.crossOrigin=this.crossOrigin),a.manager.itemStart(e),s.src=e,s}},mo=class extends Gi{constructor(e){super(e)}load(e,t,r,i){let a=new Et,n=new M_(this.manager);return n.setCrossOrigin(this.crossOrigin),n.setPath(this.path),n.load(e,function(s){a.image=s,a.needsUpdate=!0,t!==void 0&&t(a)},r,i),a}},Mn=class extends ct{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Ne(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(t.object.target=this.target.uuid),t}},S_=class extends Mn{constructor(e,t,r){super(e,r),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(ct.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Ne(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}},go=new Ge,Bu=new L,zu=new L,_o=class{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Fe(512,512),this.map=null,this.mapPass=null,this.matrix=new Ge,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Xs,this._frameExtents=new Fe(1,1),this._viewportCount=1,this._viewports=[new tt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera,r=this.matrix;Bu.setFromMatrixPosition(e.matrixWorld),t.position.copy(Bu),zu.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(zu),t.updateMatrixWorld(),go.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(go),r.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),r.multiply(go)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},T_=class extends _o{constructor(){super(new Lt(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(e){let t=this.camera,r=fi*2*e.angle*this.focus,i=this.mapSize.width/this.mapSize.height,a=e.distance||t.far;(r!==t.fov||i!==t.aspect||a!==t.far)&&(t.fov=r,t.aspect=i,t.far=a,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}},E_=class extends Mn{constructor(e,t,r=0,i=Math.PI/3,a=0,n=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(ct.DEFAULT_UP),this.updateMatrix(),this.target=new ct,this.distance=r,this.angle=i,this.penumbra=a,this.decay=n,this.map=null,this.shadow=new T_}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}},Hu=new Ge,ga=new L,vo=new L,b_=class extends _o{constructor(){super(new Lt(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new Fe(4,2),this._viewportCount=6,this._viewports=[new tt(2,1,1,1),new tt(0,1,1,1),new tt(3,1,1,1),new tt(1,1,1,1),new tt(3,0,1,1),new tt(1,0,1,1)],this._cubeDirections=[new L(1,0,0),new L(-1,0,0),new L(0,0,1),new L(0,0,-1),new L(0,1,0),new L(0,-1,0)],this._cubeUps=[new L(0,1,0),new L(0,1,0),new L(0,1,0),new L(0,1,0),new L(0,0,1),new L(0,0,-1)]}updateMatrices(e,t=0){let r=this.camera,i=this.matrix,a=e.distance||r.far;a!==r.far&&(r.far=a,r.updateProjectionMatrix()),ga.setFromMatrixPosition(e.matrixWorld),r.position.copy(ga),vo.copy(r.position),vo.add(this._cubeDirections[t]),r.up.copy(this._cubeUps[t]),r.lookAt(vo),r.updateMatrixWorld(),i.makeTranslation(-ga.x,-ga.y,-ga.z),Hu.multiplyMatrices(r.projectionMatrix,r.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Hu)}},ku=class extends Mn{constructor(e,t,r=0,i=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=r,this.decay=i,this.shadow=new b_}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}},w_=class extends _o{constructor(){super(new tn(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Sn=class extends Mn{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(ct.DEFAULT_UP),this.updateMatrix(),this.target=new ct,this.shadow=new w_}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}},_a=class{static decodeText(e){if(console.warn("THREE.LoaderUtils: decodeText() has been deprecated with r165 and will be removed with r175. Use TextDecoder instead."),typeof TextDecoder<"u")return new TextDecoder().decode(e);let t="";for(let r=0,i=e.length;r<i;r++)t+=String.fromCharCode(e[r]);try{return decodeURIComponent(escape(t))}catch{return t}}static extractUrlBase(e){let t=e.lastIndexOf("/");return t===-1?"./":e.slice(0,t+1)}static resolveURL(e,t){return typeof e!="string"||e===""?"":(/^https?:\/\//i.test(t)&&/^\//.test(e)&&(t=t.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:t+e)}},A_=class extends Gi{constructor(e){super(e),this.isImageBitmapLoader=!0,typeof createImageBitmap>"u"&&console.warn("THREE.ImageBitmapLoader: createImageBitmap() not supported."),typeof fetch>"u"&&console.warn("THREE.ImageBitmapLoader: fetch() not supported."),this.options={premultiplyAlpha:"none"}}setOptions(e){return this.options=e,this}load(e,t,r,i){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let a=this,n=Br.get(e);if(n!==void 0){if(a.manager.itemStart(e),n.then){n.then(l=>{t&&t(l),a.manager.itemEnd(e)}).catch(l=>{i&&i(l)});return}return setTimeout(function(){t&&t(n),a.manager.itemEnd(e)},0),n}let s={};s.credentials=this.crossOrigin==="anonymous"?"same-origin":"include",s.headers=this.requestHeader;let o=fetch(e,s).then(function(l){return l.blob()}).then(function(l){return createImageBitmap(l,Object.assign(a.options,{colorSpaceConversion:"none"}))}).then(function(l){return Br.add(e,l),t&&t(l),a.manager.itemEnd(e),l}).catch(function(l){i&&i(l),Br.remove(e),a.manager.itemError(e),a.manager.itemEnd(e)});Br.add(e,o),a.manager.itemStart(e)}},xo="\\[\\]\\.:\\/",R_=new RegExp("["+xo+"]","g"),yo="[^"+xo+"]",C_="[^"+xo.replace("\\.","")+"]",L_=/((?:WC+[\/:])*)/.source.replace("WC",yo),P_=/(WCOD+)?/.source.replace("WCOD",C_),I_=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",yo),D_=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",yo),U_=new RegExp("^"+L_+P_+I_+D_+"$"),N_=["material","materials","bones","map"],O_=class{constructor(e,t,r){let i=r||ht.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,i)}getValue(e,t){this.bind();let r=this._targetGroup.nCachedObjects_,i=this._bindings[r];i!==void 0&&i.getValue(e,t)}setValue(e,t){let r=this._bindings;for(let i=this._targetGroup.nCachedObjects_,a=r.length;i!==a;++i)r[i].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,r=e.length;t!==r;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,r=e.length;t!==r;++t)e[t].unbind()}},ht=class Yi{constructor(t,r,i){this.path=r,this.parsedPath=i||Yi.parseTrackName(r),this.node=Yi.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,r,i){return t&&t.isAnimationObjectGroup?new Yi.Composite(t,r,i):new Yi(t,r,i)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(R_,"")}static parseTrackName(t){let r=U_.exec(t);if(r===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let i={nodeName:r[2],objectName:r[3],objectIndex:r[4],propertyName:r[5],propertyIndex:r[6]},a=i.nodeName&&i.nodeName.lastIndexOf(".");if(a!==void 0&&a!==-1){let n=i.nodeName.substring(a+1);N_.indexOf(n)!==-1&&(i.nodeName=i.nodeName.substring(0,a),i.objectName=n)}if(i.propertyName===null||i.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return i}static findNode(t,r){if(r===void 0||r===""||r==="."||r===-1||r===t.name||r===t.uuid)return t;if(t.skeleton){let i=t.skeleton.getBoneByName(r);if(i!==void 0)return i}if(t.children){let i=function(n){for(let s=0;s<n.length;s++){let o=n[s];if(o.name===r||o.uuid===r)return o;let l=i(o.children);if(l)return l}return null},a=i(t.children);if(a)return a}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,r){t[r]=this.targetObject[this.propertyName]}_getValue_array(t,r){let i=this.resolvedProperty;for(let a=0,n=i.length;a!==n;++a)t[r++]=i[a]}_getValue_arrayElement(t,r){t[r]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,r){this.resolvedProperty.toArray(t,r)}_setValue_direct(t,r){this.targetObject[this.propertyName]=t[r]}_setValue_direct_setNeedsUpdate(t,r){this.targetObject[this.propertyName]=t[r],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,r){this.targetObject[this.propertyName]=t[r],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,r){let i=this.resolvedProperty;for(let a=0,n=i.length;a!==n;++a)i[a]=t[r++]}_setValue_array_setNeedsUpdate(t,r){let i=this.resolvedProperty;for(let a=0,n=i.length;a!==n;++a)i[a]=t[r++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,r){let i=this.resolvedProperty;for(let a=0,n=i.length;a!==n;++a)i[a]=t[r++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,r){this.resolvedProperty[this.propertyIndex]=t[r]}_setValue_arrayElement_setNeedsUpdate(t,r){this.resolvedProperty[this.propertyIndex]=t[r],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,r){this.resolvedProperty[this.propertyIndex]=t[r],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,r){this.resolvedProperty.fromArray(t,r)}_setValue_fromArray_setNeedsUpdate(t,r){this.resolvedProperty.fromArray(t,r),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,r){this.resolvedProperty.fromArray(t,r),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,r){this.bind(),this.getValue(t,r)}_setValue_unbound(t,r){this.bind(),this.setValue(t,r)}bind(){let t=this.node,r=this.parsedPath,i=r.objectName,a=r.propertyName,n=r.propertyIndex;if(t||(t=Yi.findNode(this.rootNode,r.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(i){let u=r.objectIndex;switch(i){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let h=0;h<t.length;h++)if(t[h].name===u){u=h;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[i]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[i]}if(u!==void 0){if(t[u]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[u]}}let s=t[a];if(s===void 0){let u=r.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+u+"."+a+" but it wasn't found.",t);return}let o=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(n!==void 0){if(a==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[n]!==void 0&&(n=t.morphTargetDictionary[n])}l=this.BindingType.ArrayElement,this.resolvedProperty=s,this.propertyIndex=n}else s.fromArray!==void 0&&s.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=s):Array.isArray(s)?(l=this.BindingType.EntireArray,this.resolvedProperty=s):this.propertyName=a;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};ht.Composite=O_,ht.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3},ht.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2},ht.prototype.GetterByBindingType=[ht.prototype._getValue_direct,ht.prototype._getValue_array,ht.prototype._getValue_arrayElement,ht.prototype._getValue_toArray],ht.prototype.SetterByBindingTypeAndVersioning=[[ht.prototype._setValue_direct,ht.prototype._setValue_direct_setNeedsUpdate,ht.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[ht.prototype._setValue_array,ht.prototype._setValue_array_setNeedsUpdate,ht.prototype._setValue_array_setMatrixWorldNeedsUpdate],[ht.prototype._setValue_arrayElement,ht.prototype._setValue_arrayElement_setNeedsUpdate,ht.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[ht.prototype._setValue_fromArray,ht.prototype._setValue_fromArray_setNeedsUpdate,ht.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var Y0=new Float32Array(1);typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"170"}})),typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="170");function Vu(e,t){if(t===cc)return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."),e;if(t===Ms||t===Zo){let r=e.getIndex();if(r===null){let s=[],o=e.getAttribute("position");if(o!==void 0){for(let l=0;l<o.count;l++)s.push(l);e.setIndex(s),r=e.getIndex()}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."),e}let i=r.count-2,a=[];if(t===Ms)for(let s=1;s<=i;s++)a.push(r.getX(0)),a.push(r.getX(s)),a.push(r.getX(s+1));else for(let s=0;s<i;s++)s%2===0?(a.push(r.getX(s)),a.push(r.getX(s+1)),a.push(r.getX(s+2))):(a.push(r.getX(s+2)),a.push(r.getX(s+1)),a.push(r.getX(s)));a.length/3!==i&&console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");let n=e.clone();return n.setIndex(a),n.clearGroups(),n}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:",t),e}var Gu=class extends Gi{constructor(e){super(e),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(t){return new k_(t)}),this.register(function(t){return new V_(t)}),this.register(function(t){return new $_(t)}),this.register(function(t){return new J_(t)}),this.register(function(t){return new Q_(t)}),this.register(function(t){return new W_(t)}),this.register(function(t){return new X_(t)}),this.register(function(t){return new j_(t)}),this.register(function(t){return new Y_(t)}),this.register(function(t){return new H_(t)}),this.register(function(t){return new q_(t)}),this.register(function(t){return new G_(t)}),this.register(function(t){return new Z_(t)}),this.register(function(t){return new K_(t)}),this.register(function(t){return new B_(t)}),this.register(function(t){return new e0(t)}),this.register(function(t){return new t0(t)})}load(e,t,r,i){let a=this,n;if(this.resourcePath!=="")n=this.resourcePath;else if(this.path!==""){let l=_a.extractUrlBase(e);n=_a.resolveURL(l,this.path)}else n=_a.extractUrlBase(e);this.manager.itemStart(e);let s=function(l){i?i(l):console.error(l),a.manager.itemError(e),a.manager.itemEnd(e)},o=new yn(this.manager);o.setPath(this.path),o.setResponseType("arraybuffer"),o.setRequestHeader(this.requestHeader),o.setWithCredentials(this.withCredentials),o.load(e,function(l){try{a.parse(l,n,function(u){t(u),a.manager.itemEnd(e)},s)}catch(u){s(u)}},r,s)}setDRACOLoader(e){return this.dracoLoader=e,this}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){return this.pluginCallbacks.indexOf(e)===-1&&this.pluginCallbacks.push(e),this}unregister(e){return this.pluginCallbacks.indexOf(e)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}parse(e,t,r,i){let a,n={},s={},o=new TextDecoder;if(typeof e=="string")a=JSON.parse(e);else if(e instanceof ArrayBuffer)if(o.decode(new Uint8Array(e,0,4))===Wu){try{n[We.KHR_BINARY_GLTF]=new r0(e)}catch(u){i&&i(u);return}a=JSON.parse(n[We.KHR_BINARY_GLTF].content)}else a=JSON.parse(o.decode(e));else a=e;if(a.asset===void 0||a.asset.version[0]<2){i&&i(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}let l=new m0(a,{path:t||this.resourcePath||"",crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});l.fileLoader.setRequestHeader(this.requestHeader);for(let u=0;u<this.pluginCallbacks.length;u++){let h=this.pluginCallbacks[u](l);h.name||console.error("THREE.GLTFLoader: Invalid plugin found: missing name"),s[h.name]=h,n[h.name]=!0}if(a.extensionsUsed)for(let u=0;u<a.extensionsUsed.length;++u){let h=a.extensionsUsed[u],c=a.extensionsRequired||[];switch(h){case We.KHR_MATERIALS_UNLIT:n[h]=new z_;break;case We.KHR_DRACO_MESH_COMPRESSION:n[h]=new i0(a,this.dracoLoader);break;case We.KHR_TEXTURE_TRANSFORM:n[h]=new a0;break;case We.KHR_MESH_QUANTIZATION:n[h]=new n0;break;default:c.indexOf(h)>=0&&s[h]===void 0&&console.warn('THREE.GLTFLoader: Unknown extension "'+h+'".')}}l.setExtensions(n),l.setPlugins(s),l.parse(r,i)}parseAsync(e,t){let r=this;return new Promise(function(i,a){r.parse(e,t,i,a)})}};function F_(){let e={};return{get:function(t){return e[t]},add:function(t,r){e[t]=r},remove:function(t){delete e[t]},removeAll:function(){e={}}}}var We={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_DISPERSION:"KHR_materials_dispersion",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"},B_=class{constructor(e){this.parser=e,this.name=We.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){let e=this.parser,t=this.parser.json.nodes||[];for(let r=0,i=t.length;r<i;r++){let a=t[r];a.extensions&&a.extensions[this.name]&&a.extensions[this.name].light!==void 0&&e._addNodeRef(this.cache,a.extensions[this.name].light)}}_loadLight(e){let t=this.parser,r="light:"+e,i=t.cache.get(r);if(i)return i;let a=t.json,n=((a.extensions&&a.extensions[this.name]||{}).lights||[])[e],s,o=new Ne(16777215);n.color!==void 0&&o.setRGB(n.color[0],n.color[1],n.color[2],At);let l=n.range!==void 0?n.range:0;switch(n.type){case"directional":s=new Sn(o),s.target.position.set(0,0,-1),s.add(s.target);break;case"point":s=new ku(o),s.distance=l;break;case"spot":s=new E_(o),s.distance=l,n.spot=n.spot||{},n.spot.innerConeAngle=n.spot.innerConeAngle!==void 0?n.spot.innerConeAngle:0,n.spot.outerConeAngle=n.spot.outerConeAngle!==void 0?n.spot.outerConeAngle:Math.PI/4,s.angle=n.spot.outerConeAngle,s.penumbra=1-n.spot.innerConeAngle/n.spot.outerConeAngle,s.target.position.set(0,0,-1),s.add(s.target);break;default:throw new Error("THREE.GLTFLoader: Unexpected light type: "+n.type)}return s.position.set(0,0,0),s.decay=2,Mr(s,n),n.intensity!==void 0&&(s.intensity=n.intensity),s.name=t.createUniqueName(n.name||"light_"+e),i=Promise.resolve(s),t.cache.add(r,i),i}getDependency(e,t){if(e==="light")return this._loadLight(t)}createNodeAttachment(e){let t=this,r=this.parser,i=r.json.nodes[e],a=(i.extensions&&i.extensions[this.name]||{}).light;return a===void 0?null:this._loadLight(a).then(function(n){return r._getNodeRef(t.cache,a,n)})}},z_=class{constructor(){this.name=We.KHR_MATERIALS_UNLIT}getMaterialType(){return Vt}extendParams(e,t,r){let i=[];e.color=new Ne(1,1,1),e.opacity=1;let a=t.pbrMetallicRoughness;if(a){if(Array.isArray(a.baseColorFactor)){let n=a.baseColorFactor;e.color.setRGB(n[0],n[1],n[2],At),e.opacity=n[3]}a.baseColorTexture!==void 0&&i.push(r.assignTexture(e,"map",a.baseColorTexture,at))}return Promise.all(i)}},H_=class{constructor(e){this.parser=e,this.name=We.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,t){let r=this.parser.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();let i=r.extensions[this.name].emissiveStrength;return i!==void 0&&(t.emissiveIntensity=i),Promise.resolve()}},k_=class{constructor(e){this.parser=e,this.name=We.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){let t=this.parser.json.materials[e];return!t.extensions||!t.extensions[this.name]?null:sr}extendMaterialParams(e,t){let r=this.parser,i=r.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let a=[],n=i.extensions[this.name];if(n.clearcoatFactor!==void 0&&(t.clearcoat=n.clearcoatFactor),n.clearcoatTexture!==void 0&&a.push(r.assignTexture(t,"clearcoatMap",n.clearcoatTexture)),n.clearcoatRoughnessFactor!==void 0&&(t.clearcoatRoughness=n.clearcoatRoughnessFactor),n.clearcoatRoughnessTexture!==void 0&&a.push(r.assignTexture(t,"clearcoatRoughnessMap",n.clearcoatRoughnessTexture)),n.clearcoatNormalTexture!==void 0&&(a.push(r.assignTexture(t,"clearcoatNormalMap",n.clearcoatNormalTexture)),n.clearcoatNormalTexture.scale!==void 0)){let s=n.clearcoatNormalTexture.scale;t.clearcoatNormalScale=new Fe(s,s)}return Promise.all(a)}},V_=class{constructor(e){this.parser=e,this.name=We.KHR_MATERIALS_DISPERSION}getMaterialType(e){let t=this.parser.json.materials[e];return!t.extensions||!t.extensions[this.name]?null:sr}extendMaterialParams(e,t){let r=this.parser.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();let i=r.extensions[this.name];return t.dispersion=i.dispersion!==void 0?i.dispersion:0,Promise.resolve()}},G_=class{constructor(e){this.parser=e,this.name=We.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){let t=this.parser.json.materials[e];return!t.extensions||!t.extensions[this.name]?null:sr}extendMaterialParams(e,t){let r=this.parser,i=r.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let a=[],n=i.extensions[this.name];return n.iridescenceFactor!==void 0&&(t.iridescence=n.iridescenceFactor),n.iridescenceTexture!==void 0&&a.push(r.assignTexture(t,"iridescenceMap",n.iridescenceTexture)),n.iridescenceIor!==void 0&&(t.iridescenceIOR=n.iridescenceIor),t.iridescenceThicknessRange===void 0&&(t.iridescenceThicknessRange=[100,400]),n.iridescenceThicknessMinimum!==void 0&&(t.iridescenceThicknessRange[0]=n.iridescenceThicknessMinimum),n.iridescenceThicknessMaximum!==void 0&&(t.iridescenceThicknessRange[1]=n.iridescenceThicknessMaximum),n.iridescenceThicknessTexture!==void 0&&a.push(r.assignTexture(t,"iridescenceThicknessMap",n.iridescenceThicknessTexture)),Promise.all(a)}},W_=class{constructor(e){this.parser=e,this.name=We.KHR_MATERIALS_SHEEN}getMaterialType(e){let t=this.parser.json.materials[e];return!t.extensions||!t.extensions[this.name]?null:sr}extendMaterialParams(e,t){let r=this.parser,i=r.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let a=[];t.sheenColor=new Ne(0,0,0),t.sheenRoughness=0,t.sheen=1;let n=i.extensions[this.name];if(n.sheenColorFactor!==void 0){let s=n.sheenColorFactor;t.sheenColor.setRGB(s[0],s[1],s[2],At)}return n.sheenRoughnessFactor!==void 0&&(t.sheenRoughness=n.sheenRoughnessFactor),n.sheenColorTexture!==void 0&&a.push(r.assignTexture(t,"sheenColorMap",n.sheenColorTexture,at)),n.sheenRoughnessTexture!==void 0&&a.push(r.assignTexture(t,"sheenRoughnessMap",n.sheenRoughnessTexture)),Promise.all(a)}},X_=class{constructor(e){this.parser=e,this.name=We.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){let t=this.parser.json.materials[e];return!t.extensions||!t.extensions[this.name]?null:sr}extendMaterialParams(e,t){let r=this.parser,i=r.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let a=[],n=i.extensions[this.name];return n.transmissionFactor!==void 0&&(t.transmission=n.transmissionFactor),n.transmissionTexture!==void 0&&a.push(r.assignTexture(t,"transmissionMap",n.transmissionTexture)),Promise.all(a)}},j_=class{constructor(e){this.parser=e,this.name=We.KHR_MATERIALS_VOLUME}getMaterialType(e){let t=this.parser.json.materials[e];return!t.extensions||!t.extensions[this.name]?null:sr}extendMaterialParams(e,t){let r=this.parser,i=r.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let a=[],n=i.extensions[this.name];t.thickness=n.thicknessFactor!==void 0?n.thicknessFactor:0,n.thicknessTexture!==void 0&&a.push(r.assignTexture(t,"thicknessMap",n.thicknessTexture)),t.attenuationDistance=n.attenuationDistance||1/0;let s=n.attenuationColor||[1,1,1];return t.attenuationColor=new Ne().setRGB(s[0],s[1],s[2],At),Promise.all(a)}},Y_=class{constructor(e){this.parser=e,this.name=We.KHR_MATERIALS_IOR}getMaterialType(e){let t=this.parser.json.materials[e];return!t.extensions||!t.extensions[this.name]?null:sr}extendMaterialParams(e,t){let r=this.parser.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();let i=r.extensions[this.name];return t.ior=i.ior!==void 0?i.ior:1.5,Promise.resolve()}},q_=class{constructor(e){this.parser=e,this.name=We.KHR_MATERIALS_SPECULAR}getMaterialType(e){let t=this.parser.json.materials[e];return!t.extensions||!t.extensions[this.name]?null:sr}extendMaterialParams(e,t){let r=this.parser,i=r.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let a=[],n=i.extensions[this.name];t.specularIntensity=n.specularFactor!==void 0?n.specularFactor:1,n.specularTexture!==void 0&&a.push(r.assignTexture(t,"specularIntensityMap",n.specularTexture));let s=n.specularColorFactor||[1,1,1];return t.specularColor=new Ne().setRGB(s[0],s[1],s[2],At),n.specularColorTexture!==void 0&&a.push(r.assignTexture(t,"specularColorMap",n.specularColorTexture,at)),Promise.all(a)}},K_=class{constructor(e){this.parser=e,this.name=We.EXT_MATERIALS_BUMP}getMaterialType(e){let t=this.parser.json.materials[e];return!t.extensions||!t.extensions[this.name]?null:sr}extendMaterialParams(e,t){let r=this.parser,i=r.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let a=[],n=i.extensions[this.name];return t.bumpScale=n.bumpFactor!==void 0?n.bumpFactor:1,n.bumpTexture!==void 0&&a.push(r.assignTexture(t,"bumpMap",n.bumpTexture)),Promise.all(a)}},Z_=class{constructor(e){this.parser=e,this.name=We.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){let t=this.parser.json.materials[e];return!t.extensions||!t.extensions[this.name]?null:sr}extendMaterialParams(e,t){let r=this.parser,i=r.json.materials[e];if(!i.extensions||!i.extensions[this.name])return Promise.resolve();let a=[],n=i.extensions[this.name];return n.anisotropyStrength!==void 0&&(t.anisotropy=n.anisotropyStrength),n.anisotropyRotation!==void 0&&(t.anisotropyRotation=n.anisotropyRotation),n.anisotropyTexture!==void 0&&a.push(r.assignTexture(t,"anisotropyMap",n.anisotropyTexture)),Promise.all(a)}},$_=class{constructor(e){this.parser=e,this.name=We.KHR_TEXTURE_BASISU}loadTexture(e){let t=this.parser,r=t.json,i=r.textures[e];if(!i.extensions||!i.extensions[this.name])return null;let a=i.extensions[this.name],n=t.options.ktx2Loader;if(!n){if(r.extensionsRequired&&r.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");return null}return t.loadTextureImage(e,a.source,n)}},J_=class{constructor(e){this.parser=e,this.name=We.EXT_TEXTURE_WEBP,this.isSupported=null}loadTexture(e){let t=this.name,r=this.parser,i=r.json,a=i.textures[e];if(!a.extensions||!a.extensions[t])return null;let n=a.extensions[t],s=i.images[n.source],o=r.textureLoader;if(s.uri){let l=r.options.manager.getHandler(s.uri);l!==null&&(o=l)}return this.detectSupport().then(function(l){if(l)return r.loadTextureImage(e,n.source,o);if(i.extensionsRequired&&i.extensionsRequired.indexOf(t)>=0)throw new Error("THREE.GLTFLoader: WebP required by asset but unsupported.");return r.loadTexture(e)})}detectSupport(){return this.isSupported||(this.isSupported=new Promise(function(e){let t=new Image;t.src="data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA",t.onload=t.onerror=function(){e(t.height===1)}})),this.isSupported}},Q_=class{constructor(e){this.parser=e,this.name=We.EXT_TEXTURE_AVIF,this.isSupported=null}loadTexture(e){let t=this.name,r=this.parser,i=r.json,a=i.textures[e];if(!a.extensions||!a.extensions[t])return null;let n=a.extensions[t],s=i.images[n.source],o=r.textureLoader;if(s.uri){let l=r.options.manager.getHandler(s.uri);l!==null&&(o=l)}return this.detectSupport().then(function(l){if(l)return r.loadTextureImage(e,n.source,o);if(i.extensionsRequired&&i.extensionsRequired.indexOf(t)>=0)throw new Error("THREE.GLTFLoader: AVIF required by asset but unsupported.");return r.loadTexture(e)})}detectSupport(){return this.isSupported||(this.isSupported=new Promise(function(e){let t=new Image;t.src="data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAABcAAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAEAAAABAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQAMAAAAABNjb2xybmNseAACAAIABoAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAAB9tZGF0EgAKCBgABogQEDQgMgkQAAAAB8dSLfI=",t.onload=t.onerror=function(){e(t.height===1)}})),this.isSupported}},e0=class{constructor(e){this.name=We.EXT_MESHOPT_COMPRESSION,this.parser=e}loadBufferView(e){let t=this.parser.json,r=t.bufferViews[e];if(r.extensions&&r.extensions[this.name]){let i=r.extensions[this.name],a=this.parser.getDependency("buffer",i.buffer),n=this.parser.options.meshoptDecoder;if(!n||!n.supported){if(t.extensionsRequired&&t.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");return null}return a.then(function(s){let o=i.byteOffset||0,l=i.byteLength||0,u=i.count,h=i.byteStride,c=new Uint8Array(s,o,l);return n.decodeGltfBufferAsync?n.decodeGltfBufferAsync(u,h,c,i.mode,i.filter).then(function(d){return d.buffer}):n.ready.then(function(){let d=new ArrayBuffer(u*h);return n.decodeGltfBuffer(new Uint8Array(d),u,h,c,i.mode,i.filter),d})})}else return null}},t0=class{constructor(e){this.name=We.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){let t=this.parser.json,r=t.nodes[e];if(!r.extensions||!r.extensions[this.name]||r.mesh===void 0)return null;let i=t.meshes[r.mesh];for(let o of i.primitives)if(o.mode!==Wt.TRIANGLES&&o.mode!==Wt.TRIANGLE_STRIP&&o.mode!==Wt.TRIANGLE_FAN&&o.mode!==void 0)return null;let a=r.extensions[this.name].attributes,n=[],s={};for(let o in a)n.push(this.parser.getDependency("accessor",a[o]).then(l=>(s[o]=l,s[o])));return n.length<1?null:(n.push(this.parser.createNodeMesh(e)),Promise.all(n).then(o=>{let l=o.pop(),u=l.isGroup?l.children:[l],h=o[0].count,c=[];for(let d of u){let m=new Ge,_=new L,g=new Cr,f=new L(1,1,1),p=new a_(d.geometry,d.material,h);for(let x=0;x<h;x++)s.TRANSLATION&&_.fromBufferAttribute(s.TRANSLATION,x),s.ROTATION&&g.fromBufferAttribute(s.ROTATION,x),s.SCALE&&f.fromBufferAttribute(s.SCALE,x),p.setMatrixAt(x,m.compose(_,g,f));for(let x in s)if(x==="_COLOR_0"){let v=s[x];p.instanceColor=new oo(v.array,v.itemSize,v.normalized)}else x!=="TRANSLATION"&&x!=="ROTATION"&&x!=="SCALE"&&d.geometry.setAttribute(x,s[x]);ct.prototype.copy.call(p,d),this.parser.assignFinalMaterial(p),c.push(p)}return l.isGroup?(l.clear(),l.add(...c),l):c[0]}))}},Wu="glTF",va=12,Xu={JSON:1313821514,BIN:5130562},r0=class{constructor(e){this.name=We.KHR_BINARY_GLTF,this.content=null,this.body=null;let t=new DataView(e,0,va),r=new TextDecoder;if(this.header={magic:r.decode(new Uint8Array(e.slice(0,4))),version:t.getUint32(4,!0),length:t.getUint32(8,!0)},this.header.magic!==Wu)throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");if(this.header.version<2)throw new Error("THREE.GLTFLoader: Legacy binary file detected.");let i=this.header.length-va,a=new DataView(e,va),n=0;for(;n<i;){let s=a.getUint32(n,!0);n+=4;let o=a.getUint32(n,!0);if(n+=4,o===Xu.JSON){let l=new Uint8Array(e,va+n,s);this.content=r.decode(l)}else if(o===Xu.BIN){let l=va+n;this.body=e.slice(l,l+s)}n+=s}if(this.content===null)throw new Error("THREE.GLTFLoader: JSON content not found.")}},i0=class{constructor(e,t){if(!t)throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=We.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=t,this.dracoLoader.preload()}decodePrimitive(e,t){let r=this.json,i=this.dracoLoader,a=e.extensions[this.name].bufferView,n=e.extensions[this.name].attributes,s={},o={},l={};for(let u in n){let h=So[u]||u.toLowerCase();s[h]=n[u]}for(let u in e.attributes){let h=So[u]||u.toLowerCase();if(n[u]!==void 0){let c=r.accessors[e.attributes[u]],d=Wi[c.componentType];l[h]=d.name,o[h]=c.normalized===!0}}return t.getDependency("bufferView",a).then(function(u){return new Promise(function(h,c){i.decodeDracoFile(u,function(d){for(let m in d.attributes){let _=d.attributes[m],g=o[m];g!==void 0&&(_.normalized=g)}h(d)},s,l,At,c)})})}},a0=class{constructor(){this.name=We.KHR_TEXTURE_TRANSFORM}extendTexture(e,t){return(t.texCoord===void 0||t.texCoord===e.channel)&&t.offset===void 0&&t.rotation===void 0&&t.scale===void 0||(e=e.clone(),t.texCoord!==void 0&&(e.channel=t.texCoord),t.offset!==void 0&&e.offset.fromArray(t.offset),t.rotation!==void 0&&(e.rotation=t.rotation),t.scale!==void 0&&e.repeat.fromArray(t.scale),e.needsUpdate=!0),e}},n0=class{constructor(){this.name=We.KHR_MESH_QUANTIZATION}},ju=class extends ma{constructor(e,t,r,i){super(e,t,r,i)}copySampleValue_(e){let t=this.resultBuffer,r=this.sampleValues,i=this.valueSize,a=e*i*3+i;for(let n=0;n!==i;n++)t[n]=r[a+n];return t}interpolate_(e,t,r,i){let a=this.resultBuffer,n=this.sampleValues,s=this.valueSize,o=s*2,l=s*3,u=i-t,h=(r-t)/u,c=h*h,d=c*h,m=e*l,_=m-l,g=-2*d+3*c,f=d-c,p=1-g,x=f-c+h;for(let v=0;v!==s;v++){let E=n[_+v+s],I=n[_+v+o]*u,w=n[m+v+s],R=n[m+v]*u;a[v]=p*E+x*I+g*w+f*R}return a}},s0=new Cr,o0=class extends ju{interpolate_(e,t,r,i){let a=super.interpolate_(e,t,r,i);return s0.fromArray(a).normalize().toArray(a),a}},Wt={FLOAT:5126,FLOAT_MAT3:35675,FLOAT_MAT4:35676,FLOAT_VEC2:35664,FLOAT_VEC3:35665,FLOAT_VEC4:35666,LINEAR:9729,REPEAT:10497,SAMPLER_2D:35678,POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6,UNSIGNED_BYTE:5121,UNSIGNED_SHORT:5123},Wi={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},Yu={9728:wt,9729:_t,9984:Fo,9985:Aa,9986:qi,9987:jt},qu={33071:Ar,33648:wa,10497:li},Mo={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},So={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},zr={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},l0={CUBICSPLINE:void 0,LINEAR:Ji,STEP:$i},To={OPAQUE:"OPAQUE",MASK:"MASK",BLEND:"BLEND"};function u0(e){return e.DefaultMaterial===void 0&&(e.DefaultMaterial=new tr({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:hr})),e.DefaultMaterial}function ei(e,t,r){for(let i in r.extensions)e[i]===void 0&&(t.userData.gltfExtensions=t.userData.gltfExtensions||{},t.userData.gltfExtensions[i]=r.extensions[i])}function Mr(e,t){t.extras!==void 0&&(typeof t.extras=="object"?Object.assign(e.userData,t.extras):console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+t.extras))}function h0(e,t,r){let i=!1,a=!1,n=!1;for(let u=0,h=t.length;u<h;u++){let c=t[u];if(c.POSITION!==void 0&&(i=!0),c.NORMAL!==void 0&&(a=!0),c.COLOR_0!==void 0&&(n=!0),i&&a&&n)break}if(!i&&!a&&!n)return Promise.resolve(e);let s=[],o=[],l=[];for(let u=0,h=t.length;u<h;u++){let c=t[u];if(i){let d=c.POSITION!==void 0?r.getDependency("accessor",c.POSITION):e.attributes.position;s.push(d)}if(a){let d=c.NORMAL!==void 0?r.getDependency("accessor",c.NORMAL):e.attributes.normal;o.push(d)}if(n){let d=c.COLOR_0!==void 0?r.getDependency("accessor",c.COLOR_0):e.attributes.color;l.push(d)}}return Promise.all([Promise.all(s),Promise.all(o),Promise.all(l)]).then(function(u){let h=u[0],c=u[1],d=u[2];return i&&(e.morphAttributes.position=h),a&&(e.morphAttributes.normal=c),n&&(e.morphAttributes.color=d),e.morphTargetsRelative=!0,e})}function c0(e,t){if(e.updateMorphTargets(),t.weights!==void 0)for(let r=0,i=t.weights.length;r<i;r++)e.morphTargetInfluences[r]=t.weights[r];if(t.extras&&Array.isArray(t.extras.targetNames)){let r=t.extras.targetNames;if(e.morphTargetInfluences.length===r.length){e.morphTargetDictionary={};for(let i=0,a=r.length;i<a;i++)e.morphTargetDictionary[r[i]]=i}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}function d0(e){let t,r=e.extensions&&e.extensions[We.KHR_DRACO_MESH_COMPRESSION];if(r?t="draco:"+r.bufferView+":"+r.indices+":"+Eo(r.attributes):t=e.indices+":"+Eo(e.attributes)+":"+e.mode,e.targets!==void 0)for(let i=0,a=e.targets.length;i<a;i++)t+=":"+Eo(e.targets[i]);return t}function Eo(e){let t="",r=Object.keys(e).sort();for(let i=0,a=r.length;i<a;i++)t+=r[i]+":"+e[r[i]]+";";return t}function bo(e){switch(e){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}function p0(e){return e.search(/\.jpe?g($|\?)/i)>0||e.search(/^data\:image\/jpeg/)===0?"image/jpeg":e.search(/\.webp($|\?)/i)>0||e.search(/^data\:image\/webp/)===0?"image/webp":e.search(/\.ktx2($|\?)/i)>0||e.search(/^data\:image\/ktx2/)===0?"image/ktx2":"image/png"}var f0=new Ge,m0=class{constructor(e={},t={}){this.json=e,this.extensions={},this.plugins={},this.options=t,this.cache=new F_,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let r=!1,i=-1,a=!1,n=-1;if(typeof navigator<"u"){let s=navigator.userAgent;r=/^((?!chrome|android).)*safari/i.test(s)===!0;let o=s.match(/Version\/(\d+)/);i=r&&o?parseInt(o[1],10):-1,a=s.indexOf("Firefox")>-1,n=a?s.match(/Firefox\/([0-9]+)\./)[1]:-1}typeof createImageBitmap>"u"||r&&i<17||a&&n<98?this.textureLoader=new mo(this.options.manager):this.textureLoader=new A_(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new yn(this.options.manager),this.fileLoader.setResponseType("arraybuffer"),this.options.crossOrigin==="use-credentials"&&this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,t){let r=this,i=this.json,a=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(n){return n._markDefs&&n._markDefs()}),Promise.all(this._invokeAll(function(n){return n.beforeRoot&&n.beforeRoot()})).then(function(){return Promise.all([r.getDependencies("scene"),r.getDependencies("animation"),r.getDependencies("camera")])}).then(function(n){let s={scene:n[0][i.scene||0],scenes:n[0],animations:n[1],cameras:n[2],asset:i.asset,parser:r,userData:{}};return ei(a,s,i),Mr(s,i),Promise.all(r._invokeAll(function(o){return o.afterRoot&&o.afterRoot(s)})).then(function(){for(let o of s.scenes)o.updateMatrixWorld();e(s)})}).catch(t)}_markDefs(){let e=this.json.nodes||[],t=this.json.skins||[],r=this.json.meshes||[];for(let i=0,a=t.length;i<a;i++){let n=t[i].joints;for(let s=0,o=n.length;s<o;s++)e[n[s]].isBone=!0}for(let i=0,a=e.length;i<a;i++){let n=e[i];n.mesh!==void 0&&(this._addNodeRef(this.meshCache,n.mesh),n.skin!==void 0&&(r[n.mesh].isSkinnedMesh=!0)),n.camera!==void 0&&this._addNodeRef(this.cameraCache,n.camera)}}_addNodeRef(e,t){t!==void 0&&(e.refs[t]===void 0&&(e.refs[t]=e.uses[t]=0),e.refs[t]++)}_getNodeRef(e,t,r){if(e.refs[t]<=1)return r;let i=r.clone(),a=(n,s)=>{let o=this.associations.get(n);o!=null&&this.associations.set(s,o);for(let[l,u]of n.children.entries())a(u,s.children[l])};return a(r,i),i.name+="_instance_"+e.uses[t]++,i}_invokeOne(e){let t=Object.values(this.plugins);t.push(this);for(let r=0;r<t.length;r++){let i=e(t[r]);if(i)return i}return null}_invokeAll(e){let t=Object.values(this.plugins);t.unshift(this);let r=[];for(let i=0;i<t.length;i++){let a=e(t[i]);a&&r.push(a)}return r}getDependency(e,t){let r=e+":"+t,i=this.cache.get(r);if(!i){switch(e){case"scene":i=this.loadScene(t);break;case"node":i=this._invokeOne(function(a){return a.loadNode&&a.loadNode(t)});break;case"mesh":i=this._invokeOne(function(a){return a.loadMesh&&a.loadMesh(t)});break;case"accessor":i=this.loadAccessor(t);break;case"bufferView":i=this._invokeOne(function(a){return a.loadBufferView&&a.loadBufferView(t)});break;case"buffer":i=this.loadBuffer(t);break;case"material":i=this._invokeOne(function(a){return a.loadMaterial&&a.loadMaterial(t)});break;case"texture":i=this._invokeOne(function(a){return a.loadTexture&&a.loadTexture(t)});break;case"skin":i=this.loadSkin(t);break;case"animation":i=this._invokeOne(function(a){return a.loadAnimation&&a.loadAnimation(t)});break;case"camera":i=this.loadCamera(t);break;default:if(i=this._invokeOne(function(a){return a!=this&&a.getDependency&&a.getDependency(e,t)}),!i)throw new Error("Unknown type: "+e);break}this.cache.add(r,i)}return i}getDependencies(e){let t=this.cache.get(e);if(!t){let r=this,i=this.json[e+(e==="mesh"?"es":"s")]||[];t=Promise.all(i.map(function(a,n){return r.getDependency(e,n)})),this.cache.add(e,t)}return t}loadBuffer(e){let t=this.json.buffers[e],r=this.fileLoader;if(t.type&&t.type!=="arraybuffer")throw new Error("THREE.GLTFLoader: "+t.type+" buffer type is not supported.");if(t.uri===void 0&&e===0)return Promise.resolve(this.extensions[We.KHR_BINARY_GLTF].body);let i=this.options;return new Promise(function(a,n){r.load(_a.resolveURL(t.uri,i.path),a,void 0,function(){n(new Error('THREE.GLTFLoader: Failed to load buffer "'+t.uri+'".'))})})}loadBufferView(e){let t=this.json.bufferViews[e];return this.getDependency("buffer",t.buffer).then(function(r){let i=t.byteLength||0,a=t.byteOffset||0;return r.slice(a,a+i)})}loadAccessor(e){let t=this,r=this.json,i=this.json.accessors[e];if(i.bufferView===void 0&&i.sparse===void 0){let n=Mo[i.type],s=Wi[i.componentType],o=i.normalized===!0,l=new s(i.count*n);return Promise.resolve(new vt(l,n,o))}let a=[];return i.bufferView!==void 0?a.push(this.getDependency("bufferView",i.bufferView)):a.push(null),i.sparse!==void 0&&(a.push(this.getDependency("bufferView",i.sparse.indices.bufferView)),a.push(this.getDependency("bufferView",i.sparse.values.bufferView))),Promise.all(a).then(function(n){let s=n[0],o=Mo[i.type],l=Wi[i.componentType],u=l.BYTES_PER_ELEMENT,h=u*o,c=i.byteOffset||0,d=i.bufferView!==void 0?r.bufferViews[i.bufferView].byteStride:void 0,m=i.normalized===!0,_,g;if(d&&d!==h){let f=Math.floor(c/d),p="InterleavedBuffer:"+i.bufferView+":"+i.componentType+":"+f+":"+i.count,x=t.cache.get(p);x||(_=new l(s,f*d,i.count*d/u),x=new hu(_,d/u),t.cache.add(p,x)),g=new ro(x,o,c%d/u,m)}else s===null?_=new l(i.count*o):_=new l(s,c,i.count*o),g=new vt(_,o,m);if(i.sparse!==void 0){let f=Mo.SCALAR,p=Wi[i.sparse.indices.componentType],x=i.sparse.indices.byteOffset||0,v=i.sparse.values.byteOffset||0,E=new p(n[1],x,i.sparse.count*f),I=new l(n[2],v,i.sparse.count*o);s!==null&&(g=new vt(g.array.slice(),g.itemSize,g.normalized)),g.normalized=!1;for(let w=0,R=E.length;w<R;w++){let U=E[w];if(g.setX(U,I[w*o]),o>=2&&g.setY(U,I[w*o+1]),o>=3&&g.setZ(U,I[w*o+2]),o>=4&&g.setW(U,I[w*o+3]),o>=5)throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}g.normalized=m}return g})}loadTexture(e){let t=this.json,r=this.options,i=t.textures[e].source,a=t.images[i],n=this.textureLoader;if(a.uri){let s=r.manager.getHandler(a.uri);s!==null&&(n=s)}return this.loadTextureImage(e,i,n)}loadTextureImage(e,t,r){let i=this,a=this.json,n=a.textures[e],s=a.images[t],o=(s.uri||s.bufferView)+":"+n.sampler;if(this.textureCache[o])return this.textureCache[o];let l=this.loadImageSource(t,r).then(function(u){u.flipY=!1,u.name=n.name||s.name||"",u.name===""&&typeof s.uri=="string"&&s.uri.startsWith("data:image/")===!1&&(u.name=s.uri);let h=(a.samplers||{})[n.sampler]||{};return u.magFilter=Yu[h.magFilter]||_t,u.minFilter=Yu[h.minFilter]||jt,u.wrapS=qu[h.wrapS]||li,u.wrapT=qu[h.wrapT]||li,u.generateMipmaps=!u.isCompressedTexture&&u.minFilter!==wt&&u.minFilter!==_t,i.associations.set(u,{textures:e}),u}).catch(function(){return null});return this.textureCache[o]=l,l}loadImageSource(e,t){let r=this,i=this.json,a=this.options;if(this.sourceCache[e]!==void 0)return this.sourceCache[e].then(h=>h.clone());let n=i.images[e],s=self.URL||self.webkitURL,o=n.uri||"",l=!1;if(n.bufferView!==void 0)o=r.getDependency("bufferView",n.bufferView).then(function(h){l=!0;let c=new Blob([h],{type:n.mimeType});return o=s.createObjectURL(c),o});else if(n.uri===void 0)throw new Error("THREE.GLTFLoader: Image "+e+" is missing URI and bufferView");let u=Promise.resolve(o).then(function(h){return new Promise(function(c,d){let m=c;t.isImageBitmapLoader===!0&&(m=function(_){let g=new Et(_);g.needsUpdate=!0,c(g)}),t.load(_a.resolveURL(h,a.path),m,void 0,d)})}).then(function(h){return l===!0&&s.revokeObjectURL(o),Mr(h,n),h.userData.mimeType=n.mimeType||p0(n.uri),h}).catch(function(h){throw console.error("THREE.GLTFLoader: Couldn't load texture",o),h});return this.sourceCache[e]=u,u}assignTexture(e,t,r,i){let a=this;return this.getDependency("texture",r.index).then(function(n){if(!n)return null;if(r.texCoord!==void 0&&r.texCoord>0&&(n=n.clone(),n.channel=r.texCoord),a.extensions[We.KHR_TEXTURE_TRANSFORM]){let s=r.extensions!==void 0?r.extensions[We.KHR_TEXTURE_TRANSFORM]:void 0;if(s){let o=a.associations.get(n);n=a.extensions[We.KHR_TEXTURE_TRANSFORM].extendTexture(n,s),a.associations.set(n,o)}}return i!==void 0&&(n.colorSpace=i),e[t]=n,n})}assignFinalMaterial(e){let t=e.geometry,r=e.material,i=t.attributes.tangent===void 0,a=t.attributes.color!==void 0,n=t.attributes.normal===void 0;if(e.isPoints){let s="PointsMaterial:"+r.uuid,o=this.cache.get(s);o||(o=new co,er.prototype.copy.call(o,r),o.color.copy(r.color),o.map=r.map,o.sizeAttenuation=!1,this.cache.add(s,o)),r=o}else if(e.isLine){let s="LineBasicMaterial:"+r.uuid,o=this.cache.get(s);o||(o=new lo,er.prototype.copy.call(o,r),o.color.copy(r.color),o.map=r.map,this.cache.add(s,o)),r=o}if(i||a||n){let s="ClonedMaterial:"+r.uuid+":";i&&(s+="derivative-tangents:"),a&&(s+="vertex-colors:"),n&&(s+="flat-shading:");let o=this.cache.get(s);o||(o=r.clone(),a&&(o.vertexColors=!0),n&&(o.flatShading=!0),i&&(o.normalScale&&(o.normalScale.y*=-1),o.clearcoatNormalScale&&(o.clearcoatNormalScale.y*=-1)),this.cache.add(s,o),this.associations.set(o,this.associations.get(r))),r=o}e.material=r}getMaterialType(){return tr}loadMaterial(e){let t=this,r=this.json,i=this.extensions,a=r.materials[e],n,s={},o=a.extensions||{},l=[];if(o[We.KHR_MATERIALS_UNLIT]){let h=i[We.KHR_MATERIALS_UNLIT];n=h.getMaterialType(),l.push(h.extendParams(s,a,t))}else{let h=a.pbrMetallicRoughness||{};if(s.color=new Ne(1,1,1),s.opacity=1,Array.isArray(h.baseColorFactor)){let c=h.baseColorFactor;s.color.setRGB(c[0],c[1],c[2],At),s.opacity=c[3]}h.baseColorTexture!==void 0&&l.push(t.assignTexture(s,"map",h.baseColorTexture,at)),s.metalness=h.metallicFactor!==void 0?h.metallicFactor:1,s.roughness=h.roughnessFactor!==void 0?h.roughnessFactor:1,h.metallicRoughnessTexture!==void 0&&(l.push(t.assignTexture(s,"metalnessMap",h.metallicRoughnessTexture)),l.push(t.assignTexture(s,"roughnessMap",h.metallicRoughnessTexture))),n=this._invokeOne(function(c){return c.getMaterialType&&c.getMaterialType(e)}),l.push(Promise.all(this._invokeAll(function(c){return c.extendMaterialParams&&c.extendMaterialParams(e,s)})))}a.doubleSided===!0&&(s.side=Ot);let u=a.alphaMode||To.OPAQUE;if(u===To.BLEND?(s.transparent=!0,s.depthWrite=!1):(s.transparent=!1,u===To.MASK&&(s.alphaTest=a.alphaCutoff!==void 0?a.alphaCutoff:.5)),a.normalTexture!==void 0&&n!==Vt&&(l.push(t.assignTexture(s,"normalMap",a.normalTexture)),s.normalScale=new Fe(1,1),a.normalTexture.scale!==void 0)){let h=a.normalTexture.scale;s.normalScale.set(h,h)}if(a.occlusionTexture!==void 0&&n!==Vt&&(l.push(t.assignTexture(s,"aoMap",a.occlusionTexture)),a.occlusionTexture.strength!==void 0&&(s.aoMapIntensity=a.occlusionTexture.strength)),a.emissiveFactor!==void 0&&n!==Vt){let h=a.emissiveFactor;s.emissive=new Ne().setRGB(h[0],h[1],h[2],At)}return a.emissiveTexture!==void 0&&n!==Vt&&l.push(t.assignTexture(s,"emissiveMap",a.emissiveTexture,at)),Promise.all(l).then(function(){let h=new n(s);return a.name&&(h.name=a.name),Mr(h,a),t.associations.set(h,{materials:e}),a.extensions&&ei(i,h,a),h})}createUniqueName(e){let t=ht.sanitizeNodeName(e||"");return t in this.nodeNamesUsed?t+"_"+ ++this.nodeNamesUsed[t]:(this.nodeNamesUsed[t]=0,t)}loadGeometries(e){let t=this,r=this.extensions,i=this.primitiveCache;function a(s){return r[We.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(s,t).then(function(o){return Ku(o,s,t)})}let n=[];for(let s=0,o=e.length;s<o;s++){let l=e[s],u=d0(l),h=i[u];if(h)n.push(h.promise);else{let c;l.extensions&&l.extensions[We.KHR_DRACO_MESH_COMPRESSION]?c=a(l):c=Ku(new Rt,l,t),i[u]={primitive:l,promise:c},n.push(c)}}return Promise.all(n)}loadMesh(e){let t=this,r=this.json,i=this.extensions,a=r.meshes[e],n=a.primitives,s=[];for(let o=0,l=n.length;o<l;o++){let u=n[o].material===void 0?u0(this.cache):this.getDependency("material",n[o].material);s.push(u)}return s.push(t.loadGeometries(n)),Promise.all(s).then(function(o){let l=o.slice(0,o.length-1),u=o[o.length-1],h=[];for(let d=0,m=u.length;d<m;d++){let _=u[d],g=n[d],f,p=l[d];if(g.mode===Wt.TRIANGLES||g.mode===Wt.TRIANGLE_STRIP||g.mode===Wt.TRIANGLE_FAN||g.mode===void 0)f=a.isSkinnedMesh===!0?new e_(_,p):new ut(_,p),f.isSkinnedMesh===!0&&f.normalizeSkinWeights(),g.mode===Wt.TRIANGLE_STRIP?f.geometry=Vu(f.geometry,Zo):g.mode===Wt.TRIANGLE_FAN&&(f.geometry=Vu(f.geometry,Ms));else if(g.mode===Wt.LINES)f=new Au(_,p);else if(g.mode===Wt.LINE_STRIP)f=new ho(_,p);else if(g.mode===Wt.LINE_LOOP)f=new n_(_,p);else if(g.mode===Wt.POINTS)f=new Cu(_,p);else throw new Error("THREE.GLTFLoader: Primitive mode unsupported: "+g.mode);Object.keys(f.geometry.morphAttributes).length>0&&c0(f,a),f.name=t.createUniqueName(a.name||"mesh_"+e),Mr(f,a),g.extensions&&ei(i,f,g),t.assignFinalMaterial(f),h.push(f)}for(let d=0,m=h.length;d<m;d++)t.associations.set(h[d],{meshes:e,primitives:d});if(h.length===1)return a.extensions&&ei(i,h[0],a),h[0];let c=new nr;a.extensions&&ei(i,c,a),t.associations.set(c,{meshes:e});for(let d=0,m=h.length;d<m;d++)c.add(h[d]);return c})}loadCamera(e){let t,r=this.json.cameras[e],i=r[r.type];if(!i){console.warn("THREE.GLTFLoader: Missing camera parameters.");return}return r.type==="perspective"?t=new Lt(Es.radToDeg(i.yfov),i.aspectRatio||1,i.znear||1,i.zfar||2e6):r.type==="orthographic"&&(t=new tn(-i.xmag,i.xmag,i.ymag,-i.ymag,i.znear,i.zfar)),r.name&&(t.name=this.createUniqueName(r.name)),Mr(t,r),Promise.resolve(t)}loadSkin(e){let t=this.json.skins[e],r=[];for(let i=0,a=t.joints.length;i<a;i++)r.push(this._loadNodeShallow(t.joints[i]));return t.inverseBindMatrices!==void 0?r.push(this.getDependency("accessor",t.inverseBindMatrices)):r.push(null),Promise.all(r).then(function(i){let a=i.pop(),n=i,s=[],o=[];for(let l=0,u=n.length;l<u;l++){let h=n[l];if(h){s.push(h);let c=new Ge;a!==null&&c.fromArray(a.array,l*16),o.push(c)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',t.joints[l])}return new r_(s,o)})}loadAnimation(e){let t=this.json,r=this,i=t.animations[e],a=i.name?i.name:"animation_"+e,n=[],s=[],o=[],l=[],u=[];for(let h=0,c=i.channels.length;h<c;h++){let d=i.channels[h],m=i.samplers[d.sampler],_=d.target,g=_.node,f=i.parameters!==void 0?i.parameters[m.input]:m.input,p=i.parameters!==void 0?i.parameters[m.output]:m.output;_.node!==void 0&&(n.push(this.getDependency("node",g)),s.push(this.getDependency("accessor",f)),o.push(this.getDependency("accessor",p)),l.push(m),u.push(_))}return Promise.all([Promise.all(n),Promise.all(s),Promise.all(o),Promise.all(l),Promise.all(u)]).then(function(h){let c=h[0],d=h[1],m=h[2],_=h[3],g=h[4],f=[];for(let p=0,x=c.length;p<x;p++){let v=c[p],E=d[p],I=m[p],w=_[p],R=g[p];if(v===void 0)continue;v.updateMatrix&&v.updateMatrix();let U=r._createAnimationTracks(v,E,I,w,R);if(U)for(let M=0;M<U.length;M++)f.push(U[M])}return new m_(a,void 0,f)})}createNodeMesh(e){let t=this.json,r=this,i=t.nodes[e];return i.mesh===void 0?null:r.getDependency("mesh",i.mesh).then(function(a){let n=r._getNodeRef(r.meshCache,i.mesh,a);return i.weights!==void 0&&n.traverse(function(s){if(s.isMesh)for(let o=0,l=i.weights.length;o<l;o++)s.morphTargetInfluences[o]=i.weights[o]}),n})}loadNode(e){let t=this.json,r=this,i=t.nodes[e],a=r._loadNodeShallow(e),n=[],s=i.children||[];for(let l=0,u=s.length;l<u;l++)n.push(r.getDependency("node",s[l]));let o=i.skin===void 0?Promise.resolve(null):r.getDependency("skin",i.skin);return Promise.all([a,Promise.all(n),o]).then(function(l){let u=l[0],h=l[1],c=l[2];c!==null&&u.traverse(function(d){d.isSkinnedMesh&&d.bind(c,f0)});for(let d=0,m=h.length;d<m;d++)u.add(h[d]);return u})}_loadNodeShallow(e){let t=this.json,r=this.extensions,i=this;if(this.nodeCache[e]!==void 0)return this.nodeCache[e];let a=t.nodes[e],n=a.name?i.createUniqueName(a.name):"",s=[],o=i._invokeOne(function(l){return l.createNodeMesh&&l.createNodeMesh(e)});return o&&s.push(o),a.camera!==void 0&&s.push(i.getDependency("camera",a.camera).then(function(l){return i._getNodeRef(i.cameraCache,a.camera,l)})),i._invokeAll(function(l){return l.createNodeAttachment&&l.createNodeAttachment(e)}).forEach(function(l){s.push(l)}),this.nodeCache[e]=Promise.all(s).then(function(l){let u;if(a.isBone===!0?u=new xu:l.length>1?u=new nr:l.length===1?u=l[0]:u=new ct,u!==l[0])for(let h=0,c=l.length;h<c;h++)u.add(l[h]);if(a.name&&(u.userData.name=a.name,u.name=n),Mr(u,a),a.extensions&&ei(r,u,a),a.matrix!==void 0){let h=new Ge;h.fromArray(a.matrix),u.applyMatrix4(h)}else a.translation!==void 0&&u.position.fromArray(a.translation),a.rotation!==void 0&&u.quaternion.fromArray(a.rotation),a.scale!==void 0&&u.scale.fromArray(a.scale);return i.associations.has(u)||i.associations.set(u,{}),i.associations.get(u).nodes=e,u}),this.nodeCache[e]}loadScene(e){let t=this.extensions,r=this.json.scenes[e],i=this,a=new nr;r.name&&(a.name=i.createUniqueName(r.name)),Mr(a,r),r.extensions&&ei(t,a,r);let n=r.nodes||[],s=[];for(let o=0,l=n.length;o<l;o++)s.push(i.getDependency("node",n[o]));return Promise.all(s).then(function(o){for(let u=0,h=o.length;u<h;u++)a.add(o[u]);let l=u=>{let h=new Map;for(let[c,d]of i.associations)(c instanceof er||c instanceof Et)&&h.set(c,d);return u.traverse(c=>{let d=i.associations.get(c);d!=null&&h.set(c,d)}),h};return i.associations=l(a),a})}_createAnimationTracks(e,t,r,i,a){let n=[],s=e.name?e.name:e.uuid,o=[];zr[a.path]===zr.weights?e.traverse(function(c){c.morphTargetInfluences&&o.push(c.name?c.name:c.uuid)}):o.push(s);let l;switch(zr[a.path]){case zr.weights:l=zi;break;case zr.rotation:l=Hi;break;case zr.position:case zr.scale:l=Vi;break;default:r.itemSize===1?l=zi:l=Vi;break}let u=i.interpolation!==void 0?l0[i.interpolation]:Ji,h=this._getArrayFromAccessor(r);for(let c=0,d=o.length;c<d;c++){let m=new l(o[c]+"."+zr[a.path],t.array,h,u);i.interpolation==="CUBICSPLINE"&&this._createCubicSplineTrackInterpolant(m),n.push(m)}return n}_getArrayFromAccessor(e){let t=e.array;if(e.normalized){let r=bo(t.constructor),i=new Float32Array(t.length);for(let a=0,n=t.length;a<n;a++)i[a]=t[a]*r;t=i}return t}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(t){let r=this instanceof Hi?o0:ju;return new r(this.times,this.values,this.getValueSize()/3,t)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}};function g0(e,t,r){let i=t.attributes,a=new Zt;if(i.POSITION!==void 0){let o=r.json.accessors[i.POSITION],l=o.min,u=o.max;if(l!==void 0&&u!==void 0){if(a.set(new L(l[0],l[1],l[2]),new L(u[0],u[1],u[2])),o.normalized){let h=bo(Wi[o.componentType]);a.min.multiplyScalar(h),a.max.multiplyScalar(h)}}else{console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");return}}else return;let n=t.targets;if(n!==void 0){let o=new L,l=new L;for(let u=0,h=n.length;u<h;u++){let c=n[u];if(c.POSITION!==void 0){let d=r.json.accessors[c.POSITION],m=d.min,_=d.max;if(m!==void 0&&_!==void 0){if(l.setX(Math.max(Math.abs(m[0]),Math.abs(_[0]))),l.setY(Math.max(Math.abs(m[1]),Math.abs(_[1]))),l.setZ(Math.max(Math.abs(m[2]),Math.abs(_[2]))),d.normalized){let g=bo(Wi[d.componentType]);l.multiplyScalar(g)}o.max(l)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}a.expandByVector(o)}e.boundingBox=a;let s=new ir;a.getCenter(s.center),s.radius=a.min.distanceTo(a.max)/2,e.boundingSphere=s}function Ku(e,t,r){let i=t.attributes,a=[];function n(s,o){return r.getDependency("accessor",s).then(function(l){e.setAttribute(o,l)})}for(let s in i){let o=So[s]||s.toLowerCase();o in e.attributes||a.push(n(i[s],o))}if(t.indices!==void 0&&!e.index){let s=r.getDependency("accessor",t.indices).then(function(o){e.setIndex(o)});a.push(s)}return Ye.workingColorSpace!==At&&"COLOR_0"in i&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${Ye.workingColorSpace}" not supported.`),Mr(e,t),g0(e,t,r),Promise.all(a).then(function(){return t.targets!==void 0?h0(e,t.targets,r):e})}var _0="wx8c4e2f6a9d1b7e53",Zu="https://appassets.androidplatform.net/"+_0+"/main";function $u(e){return typeof e!="string"?e:e.startsWith("pkg:/assets/")?Zu+"/assets/"+e.slice(12):e.startsWith("assets/")?Zu+"/"+e:e}function v0(){if(typeof globalThis.wx>"u"||!globalThis.wx||globalThis.__starDriftBridgeInstalled)return;globalThis.__starDriftBridgeInstalled=!0;let e=globalThis;typeof e.self>"u"&&(e.self=e),typeof e.window>"u"&&(e.window=e),typeof e.navigator>"u"&&(e.navigator={userAgent:"dimina-quickjs"}),typeof e.TextDecoder>"u"&&(e.TextDecoder=function(){},e.TextDecoder.prototype.decode=function(){return""}),typeof e.document>"u"&&(e.document={createElementNS(i,a){if(a==="img"){let n=wx.createImage(),s={get width(){return n.width},get height(){return n.height},addEventListener(o,l){o==="load"?n.onload=()=>{Oe("img LOAD fired:",n.src),l()}:o==="error"&&(n.onerror=()=>{Oe("img ERROR fired:",n.src),l()})},removeEventListener(o,l){o==="load"&&n.onload===l&&(n.onload=null),o==="error"&&n.onerror===l&&(n.onerror=null)}};return Object.defineProperty(s,"src",{set(o){Oe("img.src set:",o),n.src=$u(o)},get(){return n.src}}),s}if(a==="canvas")return wx.createCanvas();throw new Error("createElementNS unsupported tag: "+a)}});let t=yn.prototype.load;yn.prototype.load=function(i,a,n,s){if(typeof i=="string"&&i.startsWith("pkg:/")){let o=i.slice(5);try{let l=wx.getFileSystemManager().readFileSync(o);return Oe("FileLoader read:",o,"->",l&&l.byteLength||-1,"bytes"),a&&a(l),l}catch(l){if(Oe("FileLoader READ FAILED:",o,"|",l&&l.message),s)s(l);else throw l}}if(typeof i=="string"&&i.startsWith("data:application/octet-stream;base64,"))try{let o=U0(i),l=o.buffer;return Oe("FileLoader data URI ->",o.length,"bytes"),a&&a(l),l}catch(o){if(Oe("FileLoader data URI decode FAILED:",o&&o.message),s)s(o);else throw o}return t.call(this,i,a,n,s)};let r=mo.prototype.load;mo.prototype.load=function(i,a,n,s){Oe("TextureLoader:",i);let o=a&&function(u){Oe("TextureLoader OK:",i,u&&u.image&&u.image.width?u.image.width+"x"+u.image.height:""),o&&o(u)},l=s&&function(u){Oe("TextureLoader ERROR:",i,u&&(u.message||u)),s&&s(u)};return r.call(this,i,o,n,l)}}v0();var Dt={space:"#0a1220",keyLight:"#d5e6ff",fillLight:"#8fb4d8",hemiSky:"#31456b",hemiGround:"#0a0f18",rimLight:"#6fb0ff",asteroidIce:"#7fa3c0",asteroidRock:"#8a6440",crystal:"#26e0c2",engine:"#1e8dff",flame:"#2fc8ff",flameCore:"#e8fbff",dustNear:"#9fd4ff",dustFar:"#6f9fd0"},Ju=new L(0,1.25,6.4),wo=new L(0,.5,-18),Qu=.3,x0=60,y0=1.2,M0=1.15,S0=2.15,T0=1.9,E0=1.2,b0=.42,w0=6,A0=!0;function Oe(...e){A0&&console.log("[stardrift]",...e)}function R0(){let e=new Uint8Array(131072),t=[{u:.25,v:.4,r:.22,c:[23,112,124],a:.18},{u:.29,v:.42,r:.11,c:[37,165,176],a:.13},{u:.21,v:.34,r:.06,c:[63,210,207],a:.1},{u:.74,v:.64,r:.23,c:[124,45,104],a:.17},{u:.7,v:.59,r:.11,c:[176,68,140],a:.12},{u:.79,v:.71,r:.06,c:[216,107,168],a:.09},{u:.58,v:.24,r:.15,c:[143,106,42],a:.13},{u:.54,v:.2,r:.07,c:[201,160,74],a:.1},{u:.12,v:.74,r:.15,c:[44,74,143],a:.14},{u:.43,v:.8,r:.13,c:[29,90,143],a:.1},{u:.88,v:.22,r:.13,c:[90,58,143],a:.12}];for(let i=0;i<128;i++){let a=i/127,n=4,s=7,o=12;if(a>.42){let l=Math.min(1,(a-.42)/.3);n+=6*l,s+=11*l,o+=19*l}if(a>.72){let l=Math.min(1,(a-.72)/.28);n-=3*l,s-=6*l,o-=10*l}for(let l=0;l<256;l++){let u=l/256,h=n,c=s,d=o;for(let f of t){let p=u-f.u;p-=Math.round(p);let x=(a-f.v)*.62,v=(p*2*(p*2)+x*x)/(f.r*f.r);if(v<1){let E=(1-v)*(1-v)*f.a;h=h*(1-E)+f.c[0]*E,c=c*(1-E)+f.c[1]*E,d=d*(1-E)+f.c[2]*E}}let m=a-.52+(u-.5)*.18,_=Math.exp(-(m*m)/.012);h+=150*_*.09,c+=170*_*.09,d+=200*_*.09;let g=(i*256+l)*4;e[g]=Math.min(255,h|0),e[g+1]=Math.min(255,c|0),e[g+2]=Math.min(255,d|0),e[g+3]=255}}let r=new ca(e,256,128);return r.colorSpace=at,r.magFilter=_t,r.minFilter=jt,r.generateMipmaps=!0,r.needsUpdate=!0,Oe("equirect DataTexture","256x128","ready"),r}function C0(){try{let e=L0(512,512),t=e&&e.getContext("2d");if(!t){Oe("canvas probe: no 2d ctx");return}Oe("canvas probe: size after 512 set =",e.width,"x",e.height,"| linearGrad:",typeof t.createLinearGradient,"| radialGrad:",typeof t.createRadialGradient,"| getImageData:",typeof t.getImageData);let r=t.createLinearGradient(0,0,0,512);r.addColorStop(0,"#205080"),r.addColorStop(1,"#050810"),t.fillStyle=r,t.fillRect(0,0,512,512);try{let i=t.getImageData(256,60,1,1).data;Oe("canvas probe: gradient pixel rgba =",i[0],i[1],i[2],i[3],"(\u671F\u671B\u224832,80,128,255\uFF1B\u51680=2d\u6865\u9ED1)")}catch(i){Oe("canvas probe: getImageData threw:",i&&i.message)}}catch(e){Oe("canvas probe threw:",e&&e.message)}}function L0(e,t){if(typeof document<"u"&&document.createElement){let r=document.createElement("canvas");return r.width=e,r.height=t,r}if(typeof wx<"u"&&wx&&typeof wx.createCanvas=="function"){let r=wx.createCanvas();return r.width=e,r.height=t,r}return null}function eh(e="120,240,220"){let t=document.createElementNS("http://www.w3.org/1999/xhtml","canvas");t.width=128,t.height=128;let r=t.getContext("2d"),i=r.createRadialGradient(64,64,0,64,64,64);i.addColorStop(0,`rgba(${e},0.9)`),i.addColorStop(.3,`rgba(${e},0.38)`),i.addColorStop(.65,`rgba(${e},0.10)`),i.addColorStop(1,`rgba(${e},0)`),r.fillStyle=i,r.fillRect(0,0,128,128);let a=new fo(t);return a.colorSpace=at,a}function th(e,t){let r=document.createElementNS("http://www.w3.org/1999/xhtml","canvas");r.width=128,r.height=128;let i=r.getContext("2d"),a=64,n=i.createRadialGradient(a,a,0,a,a,34);n.addColorStop(0,`rgba(${e},0.95)`),n.addColorStop(.4,`rgba(${t},0.30)`),n.addColorStop(1,`rgba(${t},0)`),i.fillStyle=n,i.fillRect(0,0,128,128);for(let[o,l]of[[60,3.2],[38,2]]){let u=i.createLinearGradient(a-o,a,a+o,a);u.addColorStop(0,`rgba(${t},0)`),u.addColorStop(.5,`rgba(${e},0.9)`),u.addColorStop(1,`rgba(${t},0)`),i.fillStyle=u,i.fillRect(a-o,a-l/2,o*2,l);let h=i.createLinearGradient(a,a-o,a,a+o);h.addColorStop(0,`rgba(${t},0)`),h.addColorStop(.5,`rgba(${e},0.9)`),h.addColorStop(1,`rgba(${t},0)`),i.fillStyle=h,i.fillRect(a-l/2,a-o,l,o*2)}let s=new fo(r);return s.colorSpace=at,s}function P0(){let e=new Uint8Array(131072),t=[[184,144,96],[138,100,56],[110,76,48],[168,128,78],[94,64,40],[148,104,74],[122,86,56],[176,142,94],[78,54,32],[132,96,62],[116,82,46],[170,135,88]],r=4242,i=()=>(r=r*1103515245+12345&2147483647,r/2147483647),a=[];for(let s=0;s<90;s++)a.push({y:i(),w:i()<.5?[240,226,164]:[74,52,32],x0:i(),len:.12+i()*.6,a:.1+i()*.14});for(let s=0;s<128;s++){let o=s/127,l=o*(t.length-1),u=Math.min(t.length-2,l|0),h=l-u,c=t[u][0]+(t[u+1][0]-t[u][0])*h,d=t[u][1]+(t[u+1][1]-t[u][1])*h,m=t[u][2]+(t[u+1][2]-t[u][2])*h,_=Math.min(1,Math.abs(o-.5)*2.4);for(let g=0;g<256;g++){let f=g/256,p=c,x=d,v=m;for(let I of a)if(Math.abs(o-I.y)<.012){let w=f-I.x0;w-=Math.round(w),w>=0&&w<I.len&&(p+=(I.w[0]-p)*I.a,x+=(I.w[1]-x)*I.a,v+=(I.w[2]-v)*I.a)}p*=1-_*.5,x*=1-_*.5,v*=1-_*.5;let E=(s*256+g)*4;e[E]=p|0,e[E+1]=x|0,e[E+2]=v|0,e[E+3]=255}}let n=new ca(e,256,128);return n.colorSpace=at,n.magFilter=_t,n.minFilter=jt,n.generateMipmaps=!0,n.needsUpdate=!0,Oe("planet DataTexture","256x128","ready"),n}function I0(){let e=new Uint8Array(65536),t=[[.7,.8,[196,168,120],.72],[.82,.89,[160,138,96],.5],[.905,.945,[214,196,158],.62],[.958,.985,[150,130,95],.4]];for(let i=0;i<128;i++)for(let a=0;a<128;a++){let n=(a+.5)/128-.5,s=(i+.5)/128-.5,o=Math.sqrt(n*n+s*s)*2,l=0,u=0,h=0,c=0;for(let[m,_,g,f]of t)if(o>=m&&o<=_){l=g[0],u=g[1],h=g[2],c=f*255;break}let d=(i*128+a)*4;e[d]=l,e[d+1]=u,e[d+2]=h,e[d+3]=c}let r=new ca(e,128,128);return r.colorSpace=at,r.magFilter=_t,r.minFilter=_t,r.generateMipmaps=!1,r.needsUpdate=!0,Oe("ring DataTexture","128x128","ready"),r}var Hr="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";function D0(e){let t=e instanceof Uint8Array?e:new Uint8Array(e),r=[],i=t.length;for(let a=0;a<i;a+=3){let n=t[a],s=a+1<i,o=a+2<i,l=s?t[a+1]:0,u=o?t[a+2]:0;r.push(Hr[n>>2]+Hr[(n&3)<<4|l>>4]+(s?Hr[(l&15)<<2|u>>6]:"=")+(o?Hr[u&63]:"="))}return r.join("")}function U0(e){let t=e.slice(e.indexOf(",")+1).replace(/=+$/,""),r=t.length,i=new Uint8Array(Math.floor(r*3/4)),a=0;for(let n=0;n<r;n+=4){let s=Hr.indexOf(t[n]),o=Hr.indexOf(t[n+1]),l=n+2<r?Hr.indexOf(t[n+2]):-1,u=n+3<r?Hr.indexOf(t[n+3]):-1;i[a++]=s<<2|o>>4,l>=0&&(i[a++]=o<<4|l>>2),u>=0&&(i[a++]=l<<6|u)}return i.subarray(0,a)}function Ao(e,t,r,i,a){let n=a||0,s=null,o=null;try{s=t==="utf8"?wx.getFileSystemManager().readFileSync(e,"utf8"):wx.getFileSystemManager().readFileSync(e);let l=s&&(s.byteLength||s.length)||0;l<=0&&(o=new Error("readFileSync returned -1/empty ("+l+")"),s=null)}catch(l){o=l}if(s){Oe("readFileSync OK:",e,"->",s.byteLength||s.length,"bytes",n?"(retry "+n+")":""),r(s);return}n+1<3?(Oe("readFileSync retry in 300ms:",e,"| attempt",n+1,"|",o&&o.message),setTimeout(()=>Ao(e,t,r,i,n+1),300)):(Oe("readFileSync FAILED after 3 tries:",e,"|",o&&o.message),i(o||new Error("readFileSync failed")))}function N0(e={}){let t=e.canvas,r=e.cssW,i=e.cssH;if(!t||!r||!i)throw new TypeError("createRenderer \u9700\u8981 { canvas, cssW, cssH }");let a=new $g({canvas:t,antialias:!0}),n=Math.min(e.pixelRatio||2,3,4096/Math.max(r,i));a.setPixelRatio(n),a.setSize(r,i,!1),a.toneMapping=Uo,a.toneMappingExposure=y0;let s=new uu,o=R0();o.mapping=Ea,o.colorSpace=at,s.environment=o,"environmentIntensity"in s&&(s.environmentIntensity=M0),s.background=o,s.fog=new Jg(Dt.space,26,64),C0();let l=r/i,u=new Lt(x0,l,.1,300);u.position.copy(Ju),u.lookAt(wo);let h=new Sn(Dt.keyLight,4);h.position.set(3.5,7,8),s.add(h);let c=new Sn(Dt.fillLight,1);c.position.set(-6,3,7),s.add(c),s.add(new S_(Dt.hemiSky,Dt.hemiGround,1.1));let d=new Sn(Dt.rimLight,2.4);d.position.set(-5,-2,-9),s.add(d);function m(N,j,B,Q,se,Me,C){let k=new Float32Array(N*3),b=new Float32Array(N*3),V=N*977,J=()=>(V=V*1103515245+12345&2147483647,V/2147483647),ie=new Ne;for(let fe=0;fe<N;fe++)k[fe*3]=(J()-.5)*Q,k[fe*3+1]=(J()-.5)*se,k[fe*3+2]=j-J()*(j-B),ie.setHSL(.52+J()*.16,.2+J()*.35,.5+J()*.45),b[fe*3]=ie.r,b[fe*3+1]=ie.g,b[fe*3+2]=ie.b;let Se=new Rt;return Se.setAttribute("position",new vt(k,3)),Se.setAttribute("color",new vt(b,3)),new Cu(Se,new co({size:Me,vertexColors:!0,transparent:!0,opacity:C,blending:cr,depthWrite:!1,sizeAttenuation:!0,fog:!1}))}s.add(m(380,-95,-34,70,44,.07,.75)),s.add(m(240,-40,-8,50,32,.11,.9));let _=th("255,245,225","255,205,140"),g=th("225,245,255","130,200,255"),f=99,p=()=>(f=f*1103515245+12345&2147483647,f/2147483647);for(let N=0;N<w0;N++){let j=p()<.45,B=new ao(new on({map:j?_:g,transparent:!0,opacity:.7,blending:cr,depthWrite:!1,fog:!1}));B.position.set((p()-.5)*30,1.5+p()*8,-36-p()*22),B.scale.setScalar(.4+p()*.4),s.add(B)}let x=new nr;x.add(new ut(new Uu(3.2,48,32),new tr({map:P0(),roughness:.92,metalness:.02,fog:!1})));let v=new ut(new l_(4.3,7,64),new Vt({map:I0(),transparent:!0,side:Ot,depthWrite:!1,fog:!1,opacity:.9}));v.rotation.x=Math.PI/2-.32,v.rotation.y=.28,x.add(v),x.position.set(-5.8,5.6,-36),x.rotation.y=.6,s.add(x);function E(N,j,B,Q,se,Me,C,k){let b=new Float32Array(N*2*3),V=new Float32Array(N*2*3),J=new Float32Array(N),ie=N*311,Se=()=>(ie=ie*1103515245+12345&2147483647,ie/2147483647),fe=new Ne(k),De=fe.clone().multiplyScalar(.12);for(let je=0;je<N;je++){let Ut=Se()*Math.PI*2,zt=j+Se()*(B-j),Sr=Math.cos(Ut)*zt,Tr=Math.sin(Ut)*zt*.62,xa=se-Se()*(se-Me);J[je]=.35+Se()*.6,b[je*6]=Sr,b[je*6+1]=Tr,b[je*6+2]=xa,b[je*6+3]=Sr,b[je*6+4]=Tr,b[je*6+5]=xa-J[je],V[je*6]=fe.r,V[je*6+1]=fe.g,V[je*6+2]=fe.b,V[je*6+3]=De.r,V[je*6+4]=De.g,V[je*6+5]=De.b}let Te=new Rt;Te.setAttribute("position",new vt(b,3)),Te.setAttribute("color",new vt(V,3));let rt=new Au(Te,new lo({vertexColors:!0,transparent:!0,opacity:b0,blending:cr,depthWrite:!1,fog:!1}));return rt.userData={speedMul:C,ringR0:j,ringR1:B,spreadY:Q,zNear:se,zFar:Me,posAttr:Te.attributes.position,lens:J},rt}let I=E(85,1.3,4.6,3.6,3.5,-52,T0,Dt.dustNear),w=E(60,1.8,6.5,4.8,2.5,-62,E0,Dt.dustFar);s.add(I,w);let R=[I,w];function U(N,j,B){let{speedMul:Q,ringR0:se,ringR1:Me,zNear:C,zFar:k,posAttr:b,lens:V}=N.userData,J=b.array,ie=Math.max(j,6)*Q,Se=C-k;for(let fe=0;fe<J.length;fe+=6){let De=fe/6;if(J[fe+2]+=ie*B,J[fe+2]>C){J[fe+2]-=Se+V[De];let Te=Math.random()*Math.PI*2,rt=se+Math.random()*(Me-se);J[fe]=Math.cos(Te)*rt,J[fe+1]=Math.sin(Te)*rt*.62}J[fe+3]=J[fe],J[fe+4]=J[fe+1],J[fe+5]=J[fe+2]-V[De]}b.needsUpdate=!0}let M=[],T=[new tr({color:Dt.asteroidIce,roughness:.85,metalness:.06,flatShading:!0}),new tr({color:Dt.asteroidRock,roughness:.62,metalness:.38,flatShading:!0})];for(let N=0;N<6;N++){let j=new s_(1,2),B=j.attributes.position,Q=N*823+7,se=()=>(Q=Q*1103515245+12345&2147483647,Q/2147483647),Me=[];for(let k=0;k<5;k++){let b=new L(se()*2-1,se()*2-1,se()*2-1).normalize();Me.push({v:b,f:1.6+se()*2.2,amp:.1+se()*.22})}let C=new Map;for(let k=0;k<B.count;k++){let b=B.getX(k),V=B.getY(k),J=B.getZ(k),ie=`${b.toFixed(3)},${V.toFixed(3)},${J.toFixed(3)}`,Se=C.get(ie);if(Se===void 0){let fe=Math.sqrt(b*b+V*V+J*J)||1,De=.82+se()*.36;for(let Te of Me){let rt=(b*Te.v.x+V*Te.v.y+J*Te.v.z)/fe;De+=Math.sin(rt*Te.f*Math.PI)*Te.amp*.32}Se=Math.max(.45,De),C.set(ie,Se)}B.setXYZ(k,b*Se,V*Se,J*Se)}j.computeVertexNormals(),M.push(j)}let P=[],z=[];function q(N){let j=P.pop();return j||(j=new ut(M[N%M.length],T[(N+1)%2]),j.castShadow=!1,s.add(j)),j.visible=!0,j}function K(){for(let N of z)N.visible=!1;P.push(...z),z.length=0}let Y=new o_(.4,0),W=new tr({color:"#0d4a44",emissive:Dt.crystal,emissiveIntensity:1.9,metalness:.15,roughness:.15}),ae=eh("74,255,221"),Z=[],te=[];function de(){let N=Z.pop();if(!N){N=new ut(Y,W),N.scale.set(1,1.7,1);let j=new ao(new on({map:ae,color:"#4affdd",transparent:!0,opacity:.4,blending:cr,depthWrite:!1,fog:!1}));j.scale.setScalar(.4*5.2),N.add(j),s.add(N)}return N.visible=!0,N}function Pe(){for(let N of te)N.visible=!1;Z.push(...te),te.length=0}let ve=new nr;s.add(ve);let $=[],oe=[],ge=!1,Ee=new Zt,he=new L,Ce=new L;function Ke(N){let j="none";N.traverse(De=>{if(De.isMesh&&(De.geometry.computeVertexNormals(),De.material=new tr({map:De.material.map||null,roughnessMap:De.material.map||null,color:"#e6edf3",metalness:.5,roughness:.55}),De.material.map)){De.material.map.anisotropy=4,De.material.roughnessMap.anisotropy=4;let Te=De.material.map.image;Te&&Te.width&&(j=Te.width+"x"+Te.height)}}),Oe("ship loaded; mesh tex dims:",j),Ee.setFromObject(N),Ee.getSize(he),Ee.getCenter(Ce);let B=S0/he.z;N.scale.setScalar(B),N.rotation.y=Math.PI,N.position.set(-Ce.x*B,-Ce.y*B,-Ce.z*B),ve.add(N);let Q=he.x/2*B,se=he.z/2*B,Me=new tr({color:"#12233a",emissive:Dt.engine,emissiveIntensity:2.4,metalness:.6,roughness:.3}),C=new Vt({color:Dt.flame,transparent:!0,opacity:.44,blending:cr,depthWrite:!1,side:Ot,fog:!1}),k=new Vt({color:Dt.flameCore,transparent:!0,opacity:.8,blending:cr,depthWrite:!1,side:Ot,fog:!1}),b=eh("80,200,255"),V=new Pu(.1,.08,.09,12),J=new Iu(.11,1.5,12,1,!0),ie=new Iu(.05,1,8,1,!0);for(let De of[-.3,.3]){let Te=new ut(V,Me);Te.rotation.x=Math.PI/2,Te.position.set(De,.02,se-.4),ve.add(Te);let rt=new ut(J,C);rt.rotation.x=Math.PI/2,rt.position.set(De,.02,se-.6),ve.add(rt);let je=new ut(ie,k);je.rotation.x=Math.PI/2,je.position.set(De,.02,se-.45),ve.add(je);let Ut=new ao(new on({map:b,color:"#57d8ff",transparent:!0,opacity:.65,blending:cr,depthWrite:!1,fog:!1}));Ut.position.set(De,.02,se-.42),Ut.scale.setScalar(.6),ve.add(Ut),oe.push({glow:Ut,flame:rt})}let Se=new Uu(.035,8,8);for(let[De,Te,rt]of[[-Q*.96,"#ff4048",0],[Q*.96,"#41ff78",Math.PI]]){let je=new ut(Se,new Vt({color:Te,fog:!1}));je.position.set(De,.06,se-.62),ve.add(je),$.push({mesh:je,phase:rt})}let fe=new ku("#39c6ff",2.6,4.5,2);fe.position.set(0,0,se+.1),ve.add(fe),Oe("ship mounted: scale",B.toFixed(3),"| pos",N.position.x.toFixed(2),N.position.y.toFixed(2),N.position.z.toFixed(2),"| texDims",j)}function Xe(N){let j=(N.images||[]).length,B=(N.textures||[]).length;delete N.images,delete N.textures;for(let Q of N.materials||[])Q.pbrMetallicRoughness&&(delete Q.pbrMetallicRoughness.baseColorTexture,delete Q.pbrMetallicRoughness.metallicRoughnessTexture),delete Q.normalTexture,delete Q.occlusionTexture,delete Q.emissiveTexture;return{materials:(N.materials||[]).length,images:j,textures:B}}function qe(N){try{let j=wx.createImage();j.onload=()=>{try{let B=new Et(j);B.colorSpace=at,B.flipY=!1,B.needsUpdate=!0;let Q=0;N.traverse(se=>{se.isMesh&&se.material&&(se.material.map=B,se.material.roughnessMap=null,Q++)}),Oe("livery attached to",Q,"mesh(es)")}catch(B){Oe("livery attach threw:",B&&B.message)}},j.onerror=()=>Oe("livery image ERROR \u2014 ship stays untextured (lights still show it)"),j.src=$u("pkg:/assets/omen-texture.png")}catch(j){Oe("attachLivery threw:",j&&j.message)}}function mt(){let N=new nr,j=new tr({color:"#9fb4c8",metalness:.8,roughness:.4}),B=new tr({color:"#2a3542",metalness:.7,roughness:.35}),Q=(se,Me,C,k,b,V,J)=>{let ie=new ut(new Ja(se,Me,C),J);ie.position.set(k,b,V),N.add(ie)};return Q(.5,.28,1.5,0,0,0,j),Q(.26,.2,.6,0,.16,-.5,B),Q(1.9,.08,.5,0,0,.35,j),Q(.1,.3,.4,-.9,.1,.45,B),Q(.1,.3,.4,.9,.1,.45,B),N}let O=null;function pt(){Oe("SHIP FALLBACK installed (procedural)");let N=mt();O=N,ve.add(N),ge=!0}function Je(){let N=Number(e.forceShipChain||globalThis.__STAR_DRIFT_FORCE_SHIP_CHAIN__||0);Oe("loadShip start; forcedChain =",N||"auto");let j=(k,b)=>{Oe("ship ONLOAD:",b,"| children:",k.children.length),O&&(Oe("late real ship arrives -> remove fallback"),ve.remove(O),O=null),Ke(k)},B=(k,b)=>{Oe("SHIP LOAD FAIL:",k,"|",b&&(b.message||String(b)),"| stack:",b&&b.stack?String(b.stack).slice(0,300):""),ge||pt()},Q=setTimeout(()=>{ge||(Oe("SHIP WATCHDOG fired (10s, likely texture promise hang) -> fallback"),pt())},1e4),se=(k,b)=>{clearTimeout(Q);try{let V=new Zt().setFromObject(k),J=new L;V.getSize(J),Oe("ship parse OK:",b,"| children:",k.children.length,"| bbox:",J.x.toFixed(2),J.y.toFixed(2),J.z.toFixed(2)),j(k,b)}catch(V){Oe("ship finish threw:",V&&V.message,"| stack:",V&&V.stack?String(V.stack).slice(0,300):""),ge||pt()}},Me=k=>b=>{clearTimeout(Q),B(k,b)},C=N===0||N===1?globalThis.__STAR_DRIFT_SHIP_DATA__:null;if(C){Oe("ship chain 1: injected data URI (harness)");try{new Gu().parse(JSON.stringify(C),"",k=>se(k.scene,"chain1"),Me("chain1-parse"))}catch(k){B("chain1-sync",k)}return}if(N===0||N===2)if(typeof globalThis.wx<"u"&&globalThis.wx&&globalThis.wx.getFileSystemManager){Oe("ship chain 2: inline (utf8 gltf + strip textures + bin data URI)"),Ao("assets/omen.gltf","utf8",k=>{let b;try{b=JSON.parse(k)}catch(J){B("chain2-json",J);return}let V=Xe(b);Oe("strip done: materials",V.materials,"| removed images",V.images,"| removed textures",V.textures),Ao("assets/omen.bin",void 0,J=>{let ie=D0(J);b.buffers[0].uri="data:application/octet-stream;base64,"+ie,Oe("bin inline: bytes",J.byteLength,"| b64 len",ie.length);let Se=Date.now();try{new Gu().parse(JSON.stringify(b),"",fe=>{Oe("inline parse OK in",Date.now()-Se,"ms"),typeof globalThis.wx<"u"&&globalThis.wx&&qe(fe.scene),clearTimeout(Q),se(fe.scene,"chain2-inline")},fe=>{Oe("inline parse onError:",fe&&(fe.message||fe)),B("chain2-parse-async",fe)})}catch(fe){Oe("inline parse SYNC THROW:",fe&&(fe.stack||fe.message)),B("chain2-parse-sync",fe)}},J=>B("chain2-bin",J))},k=>B("chain2-gltf",k));return}else Oe("chain2 skipped: no wx.getFileSystemManager");else Oe("chain2 skipped: forced =",N);Oe("ship chain 3: procedural fallback"),Ke(mt())}Je();function Qe(){try{if(typeof wx<"u"&&wx&&typeof wx.createCanvas=="function"){let N=wx.createCanvas();if(N&&N!==t&&typeof N.getContext=="function")return N}}catch{}try{if(typeof document<"u"&&document.createElement)return document.createElementNS("http://www.w3.org/1999/xhtml","canvas")}catch{}return null}function ye(){let N=Qe();if(!N)return null;N.width=Math.round(r*2),N.height=Math.round(i*2);let j=N.getContext&&N.getContext("2d");if(!j)return null;let B=new fo(N);"colorSpace"in B&&(B.colorSpace=at),B.minFilter=_t,B.magFilter=_t,B.generateMipmaps=!1;let Q=new uu,se=new tn(-1,1,1,-1,.1,2);return se.position.z=1,Q.add(new ut(new js(2,2),new Vt({map:B,transparent:!0,depthTest:!1,depthWrite:!1}))),{cv:N,ctx:j,tex:B,scene:Q,cam:se,lastKey:null}}let Ze=ye();function we(N,j,B,Q,se,Me){N.beginPath(),N.moveTo(j+Me,B),N.arcTo(j+Q,B,j+Q,B+se,Me),N.arcTo(j+Q,B+se,j,B+se,Me),N.arcTo(j,B+se,j,B,Me),N.arcTo(j,B,j+Q,B,Me),N.closePath()}function Ie(N,j,B,Q,se,Me,C,k,b,V,J,ie){N.globalAlpha=V??1,N.font=se,N.fillStyle=Me,N.textAlign=C,N.textBaseline="alphabetic",N.letterSpacing=ie||"0px",N.shadowColor=J||"rgba(4,8,16,.6)",N.shadowBlur=k,N.shadowOffsetY=b,N.fillText(j,B,Q),N.shadowColor="transparent",N.shadowBlur=0,N.shadowOffsetY=0,N.letterSpacing="0px",N.globalAlpha=1}function A(N,j,B,Q,se){N.strokeStyle=Q,N.lineWidth=se;let Me=j,C=r-j,k=j,b=i-j;N.beginPath(),N.moveTo(Me,k+B),N.lineTo(Me,k),N.lineTo(Me+B,k),N.moveTo(C-B,k),N.lineTo(C,k),N.lineTo(C,k+B),N.moveTo(C,b-B),N.lineTo(C,b),N.lineTo(C-B,b),N.moveTo(Me+B,b),N.lineTo(Me,b),N.lineTo(Me,b-B),N.stroke()}let y='"PingFang SC", "Helvetica Neue", sans-serif';function H(N,j,B){if(!Ze)return;let Q=r,se=i,Me=j.phase==="dead"&&j.deadMs>=(N.deadLockMs!=null?N.deadLockMs:600),C=Math.floor(B/450)%2===0,k=[j.phase,j.score,j.best,Me?1:0,C?1:0,j.deathReason].join("|");if(k===Ze.lastKey)return;Ze.lastKey=k;let b=Ze.ctx;b.setTransform(2,0,0,2,0,0),b.clearRect(0,0,Q,se);let V="#8fe3ff";if(A(b,16,26,"rgba(127,231,255,.42)",1.5),j.phase==="ready"){Ie(b,"S  T  A  R     D  R  I  F  T",Q/2,262,`700 15px ${y}`,"rgba(160,225,255,.95)","center",8,3,null,"rgba(120,200,255,.5)"),b.font=`900 68px ${y}`,b.textAlign="center",b.shadowColor="rgba(90,190,255,.55)",b.shadowBlur=26,b.fillStyle="rgba(210,240,255,.4)",b.fillText("\u661F\u9645\u7A7F\u884C",Q/2,352),b.shadowColor="rgba(4,8,16,.65)",b.shadowBlur=10,b.shadowOffsetY=6,b.fillStyle="#ffffff",b.fillText("\u661F\u9645\u7A7F\u884C",Q/2,352),b.shadowColor="transparent",b.shadowBlur=0,b.shadowOffsetY=0,b.textAlign="left";let J="\u70B9\u6309\u5F00\u59CB";b.font=`600 21px ${y}`,b.letterSpacing="2px";let ie=b.measureText(J).width;b.letterSpacing="0px";let Se=ie+64,fe=(Q-Se)/2,De=430,Te=56;b.fillStyle="rgba(8,14,24,.45)",we(b,fe,De,Se,Te,28),b.fill(),b.shadowColor="rgba(80,200,255,.6)",b.shadowBlur=14,b.strokeStyle="rgba(150,230,255,.95)",b.lineWidth=2.5,we(b,fe,De,Se,Te,28),b.stroke(),b.shadowColor="transparent",b.shadowBlur=0,Ie(b,J,Q/2,De+36,`600 21px ${y}`,"#ffffff","center",6,2,null,"rgba(120,220,255,.5)","2px")}else{j.phase==="dead"&&(b.fillStyle="rgba(10,14,22,.28)",b.fillRect(0,0,Q,se));let J=typeof N.distance=="number"&&isFinite(N.distance)?N.distance:j.score,ie=String(Math.max(0,Math.floor(J)));Ie(b,"DIST",30,56,`600 12px ${y}`,"rgba(143,227,255,.9)","left",4,2,null,null,"3px"),b.font=`800 46px ${y}`;let Se=b.measureText(ie).width;b.letterSpacing="1px",b.shadowColor="rgba(120,225,255,.65)",b.shadowBlur=16,b.fillStyle="rgba(210,245,255,.55)",b.fillText(ie,30,102),b.shadowColor="rgba(4,8,16,.6)",b.shadowBlur=5,b.shadowOffsetY=3,b.fillStyle="#ffffff",b.fillText(ie,30,102),b.shadowColor="transparent",b.shadowBlur=0,b.shadowOffsetY=0,b.letterSpacing="0px",Ie(b,"m",30+Se+14,102,`600 19px ${y}`,"rgba(143,227,255,.8)","left",4,2),Ie(b,"BEST",Q-30,56,`600 12px ${y}`,"rgba(143,227,255,.9)","right",4,2,null,null,"3px"),Ie(b,"m",Q-30,96,`600 15px ${y}`,"rgba(143,227,255,.8)","right",4,2),b.font=`800 30px ${y}`,b.shadowColor="rgba(120,225,255,.55)",b.shadowBlur=12,b.fillStyle="#ffffff",b.textAlign="right",b.fillText(String(j.best),Q-48,96),b.shadowColor="transparent",b.shadowBlur=0,b.textAlign="left";let fe=Math.max(0,Math.round((j.score-J)/50)),De=Q-30-46,Te=130;if(b.save(),b.translate(De,Te-7),b.rotate(Math.PI/4),b.fillStyle="rgba(46,242,207,.28)",b.strokeStyle="rgba(127,255,235,.95)",b.lineWidth=1.6,b.shadowColor="rgba(46,242,207,.9)",b.shadowBlur=9,we(b,-7,-7,14,14,2.5),b.fill(),b.stroke(),b.restore(),Ie(b,"\xD7 "+fe,Q-30,Te,`700 20px ${y}`,"#a5ffec","right",8,2,null,"rgba(46,242,207,.6)"),j.phase==="playing"){let rt="\u62D6\u62FD\u8EB2\u907F \xB7 \u6536\u96C6\u6676\u4F53";b.font=`500 15px ${y}`,b.letterSpacing="1px";let je=b.measureText(rt).width;b.letterSpacing="0px";let Ut=je+44,zt=40,Sr=(Q-Ut)/2,Tr=se-62;b.fillStyle="rgba(8,14,24,.55)",we(b,Sr,Tr,Ut,zt,20),b.fill(),b.strokeStyle="rgba(127,231,255,.55)",b.lineWidth=1.2,we(b,Sr,Tr,Ut,zt,20),b.stroke(),Ie(b,rt,Q/2,Tr+26,`500 15px ${y}`,"#eaf6ff","center",4,2,null,null,"1px")}else if(Me){let rt=j.deathReason==="asteroid"?"\u649E\u4E0A\u5C0F\u884C\u661F \xB7 \u70B9\u6309\u91CD\u5F00":"\u70B9\u6309\u91CD\u5F00";Ie(b,rt,Q/2,se/2+60,`600 17px ${y}`,"#ffffff","center",8,3,C?1:.35,"rgba(120,220,255,.5)","2px")}}Ze.tex.needsUpdate=!0}let re=0,ne=null,ee=-1,Le=new L,pe=new L;function xe(N,j){K();for(let B=0;B<N.asteroids.length;B++){let Q=N.asteroids[B],se=q(B);se.position.set(Q.x,0,Q.z),se.scale.setScalar(Q.r),se.rotation.y+=Q.spin*j,se.rotation.x+=Q.spin*.6*j,z.push(se)}Pe();for(let B of N.crystals){let Q=de();Q.position.set(B.x,.15+Math.sin(me*.002+B.x*2)*.06,B.z),Q.rotation.y=me*.0025+B.x,te.push(Q)}}function Be(N,j,B){let Q=N.player;ve.position.set(Q.x,Math.sin(B*.0016)*.06,0);let se=Q.x-Q.targetX,Me=se*.35,C=se*.4+.06;N.phase==="dead"?(Me=Math.min(.9,ee*2.4),C=ee*1.6+.06,ee>=0&&(ee+=j)):N.phase==="ready"&&(Me=0,C=.06);let k=1-Math.exp(-(j||.016)*10);ve.rotation.z+=(Es.clamp(Me,-.45,.45)-ve.rotation.z)*k,ve.rotation.y+=(Es.clamp(C,-1.5,1.5)-ve.rotation.y)*k,ve.rotation.x+=(Math.sin(B*9e-4)*.025-ve.rotation.x)*k;for(let{mesh:b,phase:V}of $)b.visible=Math.sin(B*.0042+V)>-.2;for(let b of oe)b.glow.material.opacity=.55+Math.sin(B*.0093)*.15,b.glow.scale.setScalar(.62+Math.sin(B*.0117)*.1)}function ue(N,j){Le.set(N.player.x*Qu,1.25+Math.sin(N.player.x*.5)*.04,Ju.z);let B=1-Math.exp(-(j||.016)*6);u.position.x+=(Le.x-u.position.x)*B,u.position.y+=(Le.y-u.position.y)*B,pe.set(N.player.x*Qu,wo.y,wo.z),u.lookAt(pe)}let me=0;return{renderer:a,render(N,j){let B=N.getState(),Q=re?Math.min(Math.max((j-re)/1e3,0),.1):.016;me=j||0,B.phase!==ne&&(ne==="dead"&&(K(),Pe()),B.phase==="dead"?ee=0:ee=-1,Ze&&(Ze.lastKey=null)),xe(B,Q),Be(B,Q,me),ue(B,Q),U(I,B.speed||18,Q),U(w,B.speed||18,Q),H(N,B,j||0),re=j||0,ne=B.phase,a.render(s,u),Ze&&(a.autoClear=!1,a.render(Ze.scene,Ze.cam),a.autoClear=!0)},setThemeMode(N){return N}}}var O0="wx8c4e2f6a9d1b7e53",rh=O0+":stardrift_best_v1",ti=null;function ih(e){let t=typeof e=="number"?e:parseInt(e,10);return!isFinite(t)||t<0?0:Math.floor(t)}function ah(){if(ti!==null)return ti;try{ti=ih(wx.getStorageSync(rh))}catch{ti=0}return ti}function F0(e){let t=ih(e);ti=Math.max(ah(),t);try{wx.setStorageSync(rh,t)}catch{}return ti}var Xt="[stardrift]",B0=600,z0=12;function Tn(e){console.error(Xt+" FATAL:",e);try{wx.showToast({title:String(e).slice(0,24),icon:"none"})}catch{}}function En(e,t){try{wx[e](t)}catch(r){console.error(Xt+" "+e+" unavailable:",r)}}function H0(){let e={};try{e=wx.getSystemInfoSync()||{}}catch(x){console.error(Xt+" getSystemInfoSync:",x)}let t=e.windowWidth>0?Math.floor(e.windowWidth):390,r=e.windowHeight>0?Math.floor(e.windowHeight):844,i=e.pixelRatio>0?e.pixelRatio:2,a=null;try{a=wx.createCanvas()}catch(x){console.error(Xt+" createCanvas:",x)}if(!a){Tn("canvas \u4E0D\u53EF\u7528");return}let n=null,s=e&&e.theme==="dark"?"dark":"light";console.log(Xt+" theme init: "+s);try{wx.onThemeChange(x=>{s=x&&x.theme==="dark"?"dark":"light",console.log(Xt+" theme -> "+s);try{n&&typeof n.setThemeMode=="function"&&n.setThemeMode(s)}catch{}})}catch{}try{n=N0({canvas:a,cssW:t,cssH:r,pixelRatio:i,themeMode:s})}catch(x){Tn("renderer \u521D\u59CB\u5316\u5931\u8D25: "+(x&&x.message));return}let o=null;try{o=Dh({halfRange:4})}catch(x){Tn("engine \u521D\u59CB\u5316\u5931\u8D25: "+(x&&x.message));return}let l=ah();o.best=l;let u=0,h=!1,c=0,d=0,m=0;En("onTouchStart",x=>{let v=x&&x.changedTouches&&x.changedTouches[0];v&&(h=!0,c=m=v.clientX,d=v.clientY)}),En("onTouchMove",x=>{if(!h)return;let v=x&&x.changedTouches&&x.changedTouches[0];if(!v)return;let E=v.clientX-m;if(m=v.clientX,o.phase!=="dead")try{o.drag(E)}catch(I){console.error(Xt+" drag:",I)}}),En("onTouchEnd",x=>{h=!1;let v=x&&x.changedTouches&&x.changedTouches[0];if(!v)return;let E=Math.abs(v.clientX-c)+Math.abs(v.clientY-d);try{if(o.phase==="dead"){Date.now()-u>B0&&(o.reset(),u=0);return}E<=z0&&o.tap()}catch(I){console.error(Xt+" input:",I)}}),En("onTouchCancel",()=>{h=!1});let _=o.phase;function g(){if(_!=="dead"&&o.phase==="dead"){u=Date.now();try{wx.vibrateShort({type:"heavy"})}catch{}console.error(Xt+" dead: "+(o.deathReason||"unknown")+" score="+o.score),o.score>l&&(l=F0(o.score),o.best=l)}_=o.phase}let f=-1;function p(x){(typeof x!="number"||!isFinite(x))&&(x=Date.now()),(f<0||x<f)&&(f=x);let v=Math.min(x-f,50)/1e3;f=x;try{o.tick(v),g(),n.render(o,x)}catch(E){console.error(Xt+" frame:",E&&(E.stack||E.message))}a.requestAnimationFrame(p)}try{n.render(o,0)}catch(x){console.error(Xt+" first frame:",x&&(x.stack||x.message))}a.requestAnimationFrame(p),console.log(Xt+" start "+t+"x"+r+" pr="+i+" best="+l)}try{H0()}catch(e){Tn(e&&(e.stack||e.message))}/*! Bundled license information:

three/build/three.module.js:
  (**
   * @license
   * Copyright 2010-2024 Three.js Authors
   * SPDX-License-Identifier: MIT
   *)
*/});
